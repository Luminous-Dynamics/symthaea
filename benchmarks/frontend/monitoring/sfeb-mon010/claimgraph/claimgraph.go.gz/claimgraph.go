// Package claimgraph provides an append-only, bitemporal source/claim lineage
// prototype. It is not a SCITT verifier or a source-truth oracle: publisher
// signatures, retrieval evidence, and decision profiles must be verified by
// external adapters before events are appended.
package claimgraph

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
)

type EventKind string

const (
	SourcePublished      EventKind = "source_published"
	ArtifactDeclared     EventKind = "artifact_declared"
	SourceSuperseded     EventKind = "source_superseded"
	SourceRetracted      EventKind = "source_retracted"
	SourceDisputed       EventKind = "source_disputed"
	SourceUnavailable    EventKind = "source_unavailable"
	SourceStatusRestored EventKind = "source_status_restored"
)

type ArtifactKind string

const (
	ClaimArtifact          ArtifactKind = "claim"
	TransformationArtifact ArtifactKind = "transformation"
	DecisionArtifact       ArtifactKind = "decision"
	MeasurementArtifact    ArtifactKind = "measurement"
	PendingActionArtifact  ArtifactKind = "pending_action"
	ExecutedActionArtifact ArtifactKind = "executed_action"
)

type SourceAssertion struct {
	ID              string
	IssuerID        string
	Profile         string
	DocumentID      string
	Edition         string
	StatementDigest string
	ArtifactDigest  string
	Subject         string
	Value           string
	Unit            string
	Numerator       string
	Denominator     string
	Population      string
	Geography       string
	Period          string
	Methodology     string
	ApplicableFrom  int64
	ApplicableUntil int64 // zero means open-ended
	PublishedAt     int64
	ObservedAt      int64
}

type Artifact struct {
	ID            string
	Kind          ArtifactKind
	PayloadDigest string
	DependsOn     []string
	CreatedAt     int64
	Stage         string
	Immutable     bool // executed actions are historical records, not rewrite targets
}

type Event struct {
	Sequence     uint64
	RecordedAt   int64
	EventID      string
	Kind         EventKind
	Source       *SourceAssertion
	Artifact     *Artifact
	SourceID     string
	RelatedID    string
	Reason       string
	PreviousHash string
	EventHash    string
}

type Receipt struct {
	Sequence     uint64 `json:"sequence"`
	PreviousHash string `json:"previous_hash"`
	EventHash    string `json:"event_hash"`
}

type SourceStatus string

const (
	Current       SourceStatus = "current"
	Superseded    SourceStatus = "superseded"
	Retracted     SourceStatus = "retracted"
	Disputed      SourceStatus = "disputed"
	Unavailable   SourceStatus = "unavailable"
	Indeterminate SourceStatus = "indeterminate"
	NotYetValid   SourceStatus = "not_yet_valid"
	NotRecorded   SourceStatus = "not_recorded"
	Expired       SourceStatus = "expired"
)

type HistoricalStatus struct {
	AssertionID       string       `json:"assertion_id"`
	Status            SourceStatus `json:"status"`
	AsOfRecordedAt    int64        `json:"as_of_recorded_at"`
	ApplicableAt      int64        `json:"applicable_at"`
	SupersededBy      string       `json:"superseded_by,omitempty"`
	Reason            string       `json:"reason,omitempty"`
	HistoricalVerdict string       `json:"historical_verdict"`
}

type ImpactKind string

const (
	RevalidateClaim          ImpactKind = "revalidate_claim"
	RecomputeTransformation  ImpactKind = "recompute_transformation"
	ReconsiderDecision       ImpactKind = "reconsider_decision"
	ReviewMeasurement        ImpactKind = "review_measurement"
	ReauthorizePendingAction ImpactKind = "reauthorize_pending_action"
	HistoricalActionReview   ImpactKind = "historical_action_risk_review"
)

type Impact struct {
	ArtifactID              string     `json:"artifact_id"`
	Kind                    ImpactKind `json:"kind"`
	Depth                   int        `json:"dependency_depth"`
	CorrectionEventSequence uint64     `json:"correction_event_sequence"`
	HistoricalRecordMutable bool       `json:"historical_record_mutable"`
	Action                  string     `json:"required_action"`
}

type Ledger struct {
	events       []Event
	sources      map[string]SourceAssertion
	artifacts    map[string]Artifact
	dependents   map[string]map[string]struct{}
	eventIDs     map[string]struct{}
	sourceStatus map[string][]statusEvent
	headHash     string
	lastRecorded int64
}

type statusEvent struct {
	Sequence  uint64
	Recorded  int64
	Status    SourceStatus
	RelatedID string
	Reason    string
}

func NewLedger() *Ledger {
	return &Ledger{
		sources:      make(map[string]SourceAssertion),
		artifacts:    make(map[string]Artifact),
		dependents:   make(map[string]map[string]struct{}),
		eventIDs:     make(map[string]struct{}),
		sourceStatus: make(map[string][]statusEvent),
	}
}

func (l *Ledger) Events() []Event {
	out := make([]Event, len(l.events))
	copy(out, l.events)
	for i := range out {
		if out[i].Source != nil {
			source := *out[i].Source
			out[i].Source = &source
		}
		if out[i].Artifact != nil {
			artifact := *out[i].Artifact
			artifact.DependsOn = append([]string(nil), artifact.DependsOn...)
			out[i].Artifact = &artifact
		}
	}
	return out
}

func (l *Ledger) HeadHash() string { return l.headHash }

func (l *Ledger) PublishSource(eventID string, recordedAt int64, assertion SourceAssertion) (Receipt, error) {
	if err := validateSource(assertion); err != nil {
		return Receipt{}, err
	}
	if assertion.PublishedAt > recordedAt || assertion.ObservedAt > recordedAt || assertion.ObservedAt < assertion.PublishedAt {
		return Receipt{}, errors.New("source publication/retrieval time is inconsistent with event record time")
	}
	if _, exists := l.sources[assertion.ID]; exists {
		return Receipt{}, fmt.Errorf("source assertion %q already exists; versions require distinct IDs", assertion.ID)
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourcePublished, Source: &assertion}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.sources[assertion.ID] = assertion
	l.sourceStatus[assertion.ID] = append(l.sourceStatus[assertion.ID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: Current})
	return r, nil
}

func (l *Ledger) AddArtifact(eventID string, recordedAt int64, artifact Artifact) (Receipt, error) {
	if err := validateArtifact(artifact); err != nil {
		return Receipt{}, err
	}
	if artifact.CreatedAt > recordedAt {
		return Receipt{}, errors.New("artifact creation time is after its record time")
	}
	if _, exists := l.artifacts[artifact.ID]; exists {
		return Receipt{}, fmt.Errorf("artifact %q already exists", artifact.ID)
	}
	seen := make(map[string]struct{}, len(artifact.DependsOn))
	for _, dep := range artifact.DependsOn {
		if _, dup := seen[dep]; dup {
			return Receipt{}, fmt.Errorf("artifact %q has duplicate dependency %q", artifact.ID, dep)
		}
		seen[dep] = struct{}{}
		if !l.nodeExists(dep) {
			return Receipt{}, fmt.Errorf("artifact %q references unknown dependency %q", artifact.ID, dep)
		}
	}
	artifact.DependsOn = append([]string(nil), artifact.DependsOn...)
	sort.Strings(artifact.DependsOn)
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: ArtifactDeclared, Artifact: &artifact}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.artifacts[artifact.ID] = artifact
	for _, dep := range artifact.DependsOn {
		if l.dependents[dep] == nil {
			l.dependents[dep] = make(map[string]struct{})
		}
		l.dependents[dep][artifact.ID] = struct{}{}
	}
	return r, nil
}

func (l *Ledger) Supersede(eventID string, recordedAt int64, oldID, newID, reason string) (Receipt, error) {
	if _, ok := l.sources[oldID]; !ok {
		return Receipt{}, fmt.Errorf("unknown source assertion %q", oldID)
	}
	if _, ok := l.sources[newID]; !ok {
		return Receipt{}, fmt.Errorf("unknown successor assertion %q", newID)
	}
	if oldID == newID {
		return Receipt{}, errors.New("source assertion cannot supersede itself")
	}
	oldSource, newSource := l.sources[oldID], l.sources[newID]
	if oldSource.IssuerID != newSource.IssuerID {
		return Receipt{}, errors.New("supersession must be issued by the same publisher identity")
	}
	if !sameFigureIdentity(oldSource, newSource) {
		return Receipt{}, errors.New("supersession changed figure semantics; use an explicitly linked restatement profile")
	}
	if newSource.PublishedAt < oldSource.PublishedAt {
		return Receipt{}, errors.New("successor publication time precedes prior assertion")
	}
	if status, _ := l.currentPublisherStatus(newID); status == Superseded || status == Retracted {
		return Receipt{}, fmt.Errorf("successor assertion %q is not the current publisher version", newID)
	}
	if status, _ := l.currentPublisherStatus(oldID); status == Superseded || status == Retracted {
		return Receipt{}, fmt.Errorf("source assertion %q already has terminal publisher status %q", oldID, status)
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourceSuperseded, SourceID: oldID, RelatedID: newID, Reason: reason}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.sourceStatus[oldID] = append(l.sourceStatus[oldID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: Superseded, RelatedID: newID, Reason: reason})
	return r, nil
}

func (l *Ledger) Retract(eventID string, recordedAt int64, sourceID, reason string) (Receipt, error) {
	if _, ok := l.sources[sourceID]; !ok {
		return Receipt{}, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	if strings.TrimSpace(reason) == "" {
		return Receipt{}, errors.New("retraction reason is required")
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourceRetracted, SourceID: sourceID, Reason: reason}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.sourceStatus[sourceID] = append(l.sourceStatus[sourceID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: Retracted, Reason: reason})
	return r, nil
}

func (l *Ledger) Dispute(eventID string, recordedAt int64, sourceID, independentEvidenceID, reason string) (Receipt, error) {
	if _, ok := l.sources[sourceID]; !ok {
		return Receipt{}, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	independentArtifact, isArtifact := l.artifacts[independentEvidenceID]
	if !isArtifact || independentArtifact.Kind != MeasurementArtifact {
		return Receipt{}, errors.New("dispute evidence must be a separately declared measurement artifact")
	}
	if l.dependsTransitivelyOn(independentEvidenceID, sourceID) {
		return Receipt{}, errors.New("dispute evidence depends on the disputed source and is not independent")
	}
	if strings.TrimSpace(reason) == "" {
		return Receipt{}, errors.New("dispute reason is required")
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourceDisputed, SourceID: sourceID, RelatedID: independentEvidenceID, Reason: reason}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.sourceStatus[sourceID] = append(l.sourceStatus[sourceID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: Disputed, RelatedID: independentEvidenceID, Reason: reason})
	return r, nil
}

func (l *Ledger) MarkUnavailable(eventID string, recordedAt int64, sourceID, reason string) (Receipt, error) {
	if _, ok := l.sources[sourceID]; !ok {
		return Receipt{}, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	if strings.TrimSpace(reason) == "" {
		return Receipt{}, errors.New("unavailability reason is required")
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourceUnavailable, SourceID: sourceID, Reason: reason}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	l.sourceStatus[sourceID] = append(l.sourceStatus[sourceID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: Unavailable, Reason: reason})
	return r, nil
}

func (l *Ledger) RestoreAvailability(eventID string, recordedAt int64, sourceID string) (Receipt, error) {
	if _, ok := l.sources[sourceID]; !ok {
		return Receipt{}, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	if len(l.sourceStatus[sourceID]) == 0 || l.sourceStatus[sourceID][len(l.sourceStatus[sourceID])-1].Status != Unavailable {
		return Receipt{}, errors.New("source availability is not marked unavailable")
	}
	e := Event{EventID: eventID, RecordedAt: recordedAt, Kind: SourceStatusRestored, SourceID: sourceID}
	r, err := l.append(e)
	if err != nil {
		return Receipt{}, err
	}
	restored := Current
	var related, reason string
	for i := len(l.sourceStatus[sourceID]) - 1; i >= 0; i-- {
		prior := l.sourceStatus[sourceID][i]
		if prior.Status != Unavailable {
			restored, related, reason = prior.Status, prior.RelatedID, prior.Reason
			break
		}
	}
	l.sourceStatus[sourceID] = append(l.sourceStatus[sourceID], statusEvent{Sequence: r.Sequence, Recorded: recordedAt, Status: restored, RelatedID: related, Reason: reason})
	return r, nil
}

// Evaluate separates record time from applicable/source time. Corrections
// recorded after asOfRecordedAt are deliberately invisible to a historical
// decision evaluation, but visible to a current evaluation.
func (l *Ledger) Evaluate(sourceID string, asOfRecordedAt, applicableAt int64) (HistoricalStatus, error) {
	src, ok := l.sources[sourceID]
	if !ok {
		return HistoricalStatus{}, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	status := NotRecorded
	var successor, reason string
	seen := false
	for _, ev := range l.sourceStatus[sourceID] {
		if ev.Recorded > asOfRecordedAt {
			break
		}
		status, successor, reason = ev.Status, ev.RelatedID, ev.Reason
		seen = true
	}
	if !seen {
		return HistoricalStatus{AssertionID: sourceID, Status: NotRecorded, AsOfRecordedAt: asOfRecordedAt, ApplicableAt: applicableAt, HistoricalVerdict: string(NotRecorded)}, nil
	}
	if status == Current {
		switch {
		case applicableAt < src.ApplicableFrom:
			status = NotYetValid
		case src.ApplicableUntil > 0 && applicableAt >= src.ApplicableUntil:
			status = Expired
		}
	}
	verdict := "valid_at_time"
	if status != Current {
		verdict = string(status)
	}
	return HistoricalStatus{AssertionID: sourceID, Status: status, AsOfRecordedAt: asOfRecordedAt, ApplicableAt: applicableAt, SupersededBy: successor, Reason: reason, HistoricalVerdict: verdict}, nil
}

func (l *Ledger) CurrentStatus(sourceID string, now int64) (HistoricalStatus, error) {
	return l.Evaluate(sourceID, l.lastRecorded, now)
}

// ImpactClosure traverses dependencies from a corrected source to every
// downstream claim, transform, decision and action. Executed actions retain
// immutable historical records and receive a current-risk review finding.
func (l *Ledger) ImpactClosure(sourceID string, correctionSequence uint64) ([]Impact, error) {
	if _, ok := l.sources[sourceID]; !ok {
		return nil, fmt.Errorf("unknown source assertion %q", sourceID)
	}
	if correctionSequence == 0 || correctionSequence > uint64(len(l.events)) {
		return nil, errors.New("correction sequence is outside the event log")
	}
	event := l.events[correctionSequence-1]
	if event.Kind != SourceSuperseded && event.Kind != SourceRetracted && event.Kind != SourceDisputed {
		return nil, errors.New("impact closure requires supersession, retraction or dispute event")
	}
	if event.SourceID != sourceID {
		return nil, errors.New("correction sequence refers to a different source")
	}
	type queueItem struct {
		id    string
		depth int
	}
	queue := []queueItem{{sourceID, 0}}
	seen := map[string]struct{}{sourceID: {}}
	out := make([]Impact, 0)
	for len(queue) > 0 {
		item := queue[0]
		queue = queue[1:]
		children := make([]string, 0, len(l.dependents[item.id]))
		for child := range l.dependents[item.id] {
			children = append(children, child)
		}
		sort.Strings(children)
		for _, child := range children {
			if _, exists := seen[child]; exists {
				continue
			}
			seen[child] = struct{}{}
			artifact := l.artifacts[child]
			impact := Impact{ArtifactID: child, Depth: item.depth + 1, CorrectionEventSequence: correctionSequence, HistoricalRecordMutable: false}
			switch artifact.Kind {
			case ClaimArtifact:
				impact.Kind, impact.Action = RevalidateClaim, "re-evaluate current-use eligibility; preserve historical claim"
			case TransformationArtifact:
				impact.Kind, impact.Action = RecomputeTransformation, "recompute from non-superseded inputs; preserve old output"
			case DecisionArtifact:
				impact.Kind, impact.Action = ReconsiderDecision, "reconsider using current evidence; retain original decision record"
			case MeasurementArtifact:
				impact.Kind, impact.Action = ReviewMeasurement, "reassess measurement comparability; preserve raw observation"
			case PendingActionArtifact:
				impact.Kind, impact.Action = ReauthorizePendingAction, "hold pending execution until exact action authority is revalidated"
			case ExecutedActionArtifact:
				impact.Kind, impact.Action = HistoricalActionReview, "do not rewrite execution; assess present risk and any compensating action separately"
			default:
				return nil, fmt.Errorf("unsupported artifact kind %q", artifact.Kind)
			}
			out = append(out, impact)
			queue = append(queue, queueItem{child, item.depth + 1})
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Depth != out[j].Depth {
			return out[i].Depth < out[j].Depth
		}
		if out[i].Kind != out[j].Kind {
			return out[i].Kind < out[j].Kind
		}
		return out[i].ArtifactID < out[j].ArtifactID
	})
	return out, nil
}

func (l *Ledger) VerifyHistory() error {
	prev := ""
	lastRecorded := int64(0)
	for i, e := range l.events {
		if e.Sequence != uint64(i+1) {
			return fmt.Errorf("event %d has non-contiguous sequence %d", i, e.Sequence)
		}
		if e.RecordedAt < lastRecorded {
			return fmt.Errorf("event %d has regressing record time", e.Sequence)
		}
		if e.PreviousHash != prev {
			return fmt.Errorf("event %d previous hash mismatch", e.Sequence)
		}
		want := eventDigest(e)
		if want != e.EventHash {
			return fmt.Errorf("event %d digest mismatch", e.Sequence)
		}
		prev, lastRecorded = e.EventHash, e.RecordedAt
	}
	if prev != l.headHash {
		return errors.New("ledger head hash mismatch")
	}
	return nil
}

func (l *Ledger) append(e Event) (Receipt, error) {
	if strings.TrimSpace(e.EventID) == "" {
		return Receipt{}, errors.New("event ID is required")
	}
	if _, exists := l.eventIDs[e.EventID]; exists {
		return Receipt{}, fmt.Errorf("duplicate event ID %q", e.EventID)
	}
	if e.RecordedAt <= 0 || e.RecordedAt < l.lastRecorded {
		return Receipt{}, errors.New("recorded-at time must be positive and non-regressing")
	}
	e.Sequence = uint64(len(l.events) + 1)
	e.PreviousHash = l.headHash
	e.EventHash = eventDigest(e)
	l.events = append(l.events, e)
	l.eventIDs[e.EventID] = struct{}{}
	l.headHash = e.EventHash
	l.lastRecorded = e.RecordedAt
	return Receipt{Sequence: e.Sequence, PreviousHash: e.PreviousHash, EventHash: e.EventHash}, nil
}

func (l *Ledger) currentPublisherStatus(sourceID string) (SourceStatus, statusEvent) {
	status := Current
	var latest statusEvent
	for _, ev := range l.sourceStatus[sourceID] {
		if ev.Status == Unavailable {
			continue
		}
		status, latest = ev.Status, ev
	}
	return status, latest
}

func (l *Ledger) dependsTransitivelyOn(nodeID, ancestorID string) bool {
	seen := make(map[string]struct{})
	queue := []string{nodeID}
	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]
		if _, ok := seen[current]; ok {
			continue
		}
		seen[current] = struct{}{}
		artifact, ok := l.artifacts[current]
		if !ok {
			continue
		}
		for _, dependency := range artifact.DependsOn {
			if dependency == ancestorID {
				return true
			}
			queue = append(queue, dependency)
		}
	}
	return false
}

func sameFigureIdentity(a, b SourceAssertion) bool {
	return a.Subject == b.Subject && a.Unit == b.Unit && a.Numerator == b.Numerator &&
		a.Denominator == b.Denominator && a.Population == b.Population &&
		a.Geography == b.Geography && a.Period == b.Period
}

func (l *Ledger) nodeExists(id string) bool {
	if _, ok := l.sources[id]; ok {
		return true
	}
	_, ok := l.artifacts[id]
	return ok
}

func validateSource(s SourceAssertion) error {
	for name, value := range map[string]string{"id": s.ID, "issuer": s.IssuerID, "profile": s.Profile, "document": s.DocumentID, "edition": s.Edition, "subject": s.Subject, "value": s.Value, "unit": s.Unit, "population": s.Population, "geography": s.Geography, "period": s.Period} {
		if strings.TrimSpace(value) == "" {
			return fmt.Errorf("source %s is required", name)
		}
	}
	if !validDigest(s.StatementDigest) || !validDigest(s.ArtifactDigest) {
		return errors.New("source statement and artifact digests must be canonical SHA-256 hex")
	}
	if s.PublishedAt <= 0 || s.ObservedAt <= 0 || s.ApplicableFrom <= 0 || (s.ApplicableUntil > 0 && s.ApplicableUntil <= s.ApplicableFrom) {
		return errors.New("source timestamps or applicable interval are invalid")
	}
	return nil
}

func validateArtifact(a Artifact) error {
	if strings.TrimSpace(a.ID) == "" {
		return errors.New("artifact ID is required")
	}
	switch a.Kind {
	case ClaimArtifact, TransformationArtifact, DecisionArtifact, MeasurementArtifact, PendingActionArtifact, ExecutedActionArtifact:
	default:
		return fmt.Errorf("unsupported artifact kind %q", a.Kind)
	}
	if !validDigest(a.PayloadDigest) {
		return errors.New("artifact payload digest must be canonical SHA-256 hex")
	}
	if a.CreatedAt <= 0 {
		return errors.New("artifact creation time must be positive")
	}
	if a.Kind == ExecutedActionArtifact && !a.Immutable {
		return errors.New("executed action artifact must be immutable")
	}
	return nil
}

func eventDigest(e Event) string {
	var b bytes.Buffer
	b.WriteString("SFEB-MON010-EVIDENCE-EVENT-V1\x00")
	_ = binary.Write(&b, binary.BigEndian, e.Sequence)
	_ = binary.Write(&b, binary.BigEndian, e.RecordedAt)
	writeString(&b, e.EventID)
	writeString(&b, string(e.Kind))
	writeString(&b, e.SourceID)
	writeString(&b, e.RelatedID)
	writeString(&b, e.Reason)
	writeString(&b, e.PreviousHash)
	if e.Source != nil {
		writeSource(&b, *e.Source)
	}
	if e.Artifact != nil {
		writeArtifact(&b, *e.Artifact)
	}
	sum := sha256.Sum256(b.Bytes())
	return hex.EncodeToString(sum[:])
}

func writeSource(b *bytes.Buffer, s SourceAssertion) {
	for _, v := range []string{s.ID, s.IssuerID, s.Profile, s.DocumentID, s.Edition, s.StatementDigest, s.ArtifactDigest, s.Subject, s.Value, s.Unit, s.Numerator, s.Denominator, s.Population, s.Geography, s.Period, s.Methodology} {
		writeString(b, v)
	}
	for _, v := range []int64{s.ApplicableFrom, s.ApplicableUntil, s.PublishedAt, s.ObservedAt} {
		_ = binary.Write(b, binary.BigEndian, v)
	}
}

func writeArtifact(b *bytes.Buffer, a Artifact) {
	writeString(b, a.ID)
	writeString(b, string(a.Kind))
	writeString(b, a.PayloadDigest)
	_ = binary.Write(b, binary.BigEndian, a.CreatedAt)
	writeString(b, a.Stage)
	if a.Immutable {
		b.WriteByte(1)
	} else {
		b.WriteByte(0)
	}
	deps := append([]string(nil), a.DependsOn...)
	sort.Strings(deps)
	_ = binary.Write(b, binary.BigEndian, uint32(len(deps)))
	for _, dep := range deps {
		writeString(b, dep)
	}
}

func writeString(b *bytes.Buffer, s string) {
	_ = binary.Write(b, binary.BigEndian, uint32(len(s)))
	b.WriteString(s)
}

func validDigest(s string) bool {
	if len(s) != 64 || s != strings.ToLower(s) || strings.TrimSpace(s) != s {
		return false
	}
	b, err := hex.DecodeString(s)
	return err == nil && len(b) == sha256.Size
}
