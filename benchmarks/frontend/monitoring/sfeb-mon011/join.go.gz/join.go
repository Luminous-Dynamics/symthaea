// Package join verifies cross-layer causal bindings between authenticated,
// normalized source, decision, action, sink and observation records.
// It is not a signature, COSE, SCITT, publisher-truth or destination verifier.
package join

import (
	"fmt"
	"regexp"
	"strings"
	"time"
)

type Status string

const (
	Qualified     Status = "qualified"
	Indeterminate Status = "indeterminate"
	Contradicted  Status = "contradicted"
	Stale         Status = "stale"
	Unauthorized  Status = "unauthorized"
)

type SourceStatus string

const (
	SourceCurrent     SourceStatus = "current"
	SourceRestored    SourceStatus = "restored"
	SourceSuperseded  SourceStatus = "superseded"
	SourceRetracted   SourceStatus = "retracted"
	SourceDisputed    SourceStatus = "disputed"
	SourceUnavailable SourceStatus = "unavailable"
)

type Evidence struct {
	ID            string
	Digest        string
	Authenticated bool // Set only after the relevant external verifier has run.
	TrustDomain   string
	At            string // RFC3339Nano, with explicit UTC offset.
}

type SourceClaim struct {
	Evidence
	Issuer          string
	Profile         string
	Edition         string
	StatementDigest string
	Status          SourceStatus
}

type Decision struct {
	Evidence
	SourceID             string
	SourceEvidenceDigest string
	StatementDigest      string
	Principal            string
	Tenant               string
	Resource             string
	MutationPath         string
	OperationID          string
	RequestDigest        string
	ApprovalDigest       string
	PolicyDigest         string
	AuthorityState       string // Must be "authorized"; measurement capsules are authority-free.
}

type AuthorityEvidence struct {
	Evidence
	Principal             string
	Tenant                string
	Resource              string
	MutationPath          string
	PolicyDigest          string
	ValidFrom             string
	ExpiresAt             string
	RevocationStatusKnown bool
	RevocationCheckedAt   string
	RevokedAt             string // Empty means no revocation was present in the authenticated snapshot.
}

type Intent struct {
	Evidence
	DecisionID     string
	DecisionDigest string
	Principal      string
	Tenant         string
	Resource       string
	MutationPath   string
	OperationID    string
	RequestDigest  string
	ApprovalDigest string
}

type SinkCommit struct {
	Evidence
	IntentID                string
	IntentDigest            string
	Principal               string
	Tenant                  string
	Resource                string
	MutationPath            string
	OperationID             string
	RequestDigest           string
	PolicyDigest            string
	AuthorityEvidenceDigest string
	Authority               *AuthorityEvidence
	StateRevision           uint64
	StateDigest             string
}

type Observation struct {
	Evidence
	SinkID        string
	SinkDigest    string
	ObserverID    string
	Principal     string
	Tenant        string
	Resource      string
	OperationID   string
	StateRevision uint64
	StateDigest   string
}

type Bundle struct {
	Source      *SourceClaim
	Decision    *Decision
	Intent      *Intent
	Sink        *SinkCommit
	Observation *Observation
}

type Policy struct {
	AsOf                        time.Time
	MaxObservationAge           time.Duration
	MaxAuthorityEvidenceAge     time.Duration
	RequireIndependentRead      bool
	RequireIndependentAuthority bool
}

type Finding struct {
	Code   string
	Layer  string
	Detail string
}

type Result struct {
	Status   Status
	Findings []Finding
}

var digestPattern = regexp.MustCompile(`^[0-9a-f]{64}$`)

func add(out *Result, status Status, code, layer, detail string) {
	out.Findings = append(out.Findings, Finding{Code: code, Layer: layer, Detail: detail})
	switch status {
	case Contradicted:
		out.Status = Contradicted
	case Unauthorized:
		if out.Status != Contradicted {
			out.Status = Unauthorized
		}
	case Stale:
		if out.Status != Contradicted && out.Status != Unauthorized {
			out.Status = Stale
		}
	case Indeterminate:
		if out.Status == Qualified {
			out.Status = Indeterminate
		}
	}
}

func nonEmpty(v string) bool { return strings.TrimSpace(v) != "" }

func validateEvidence(out *Result, layer string, e Evidence) bool {
	ok := true
	if !nonEmpty(e.ID) {
		add(out, Indeterminate, "missing_id", layer, "evidence identifier is absent")
		ok = false
	}
	if !digestPattern.MatchString(e.Digest) {
		add(out, Indeterminate, "invalid_digest", layer, "evidence digest is not lowercase SHA-256 hex")
		ok = false
	}
	if !e.Authenticated {
		add(out, Indeterminate, "not_authenticated", layer, "external adapter has not authenticated this evidence")
		ok = false
	}
	if !nonEmpty(e.TrustDomain) {
		add(out, Indeterminate, "missing_trust_domain", layer, "trust domain is required for independence analysis")
		ok = false
	}
	if _, err := parseTime(e.At); err != nil {
		add(out, Indeterminate, "invalid_time", layer, err.Error())
		ok = false
	}
	return ok
}

func parseTime(v string) (time.Time, error) {
	if !nonEmpty(v) {
		return time.Time{}, fmt.Errorf("timestamp is missing")
	}
	t, err := time.Parse(time.RFC3339Nano, v)
	if err != nil {
		return time.Time{}, fmt.Errorf("timestamp must be RFC3339Nano with explicit offset: %w", err)
	}
	return t, nil
}

func requireEqual(out *Result, layer, field, want, got string) {
	if want != got {
		add(out, Contradicted, "join_mismatch", layer, fmt.Sprintf("%s does not bind: expected %q, got %q", field, want, got))
	}
}

func requireNonEmpty(out *Result, layer, field, value string) {
	if !nonEmpty(value) {
		add(out, Indeterminate, "missing_field", layer, field+" is required")
	}
}

func timeOrder(out *Result, earlierLayer, laterLayer string, earlier, later time.Time) {
	if later.Before(earlier) {
		add(out, Contradicted, "causal_time_inversion", laterLayer, earlierLayer+" occurs after this record")
	}
}

// Evaluate verifies the semantic joins among normalized records. All booleans
// indicating authentication/authority are assertions from adapters and must
// be backed by separately tested verifiers and destination controls.
func Evaluate(b Bundle, p Policy) Result {
	out := Result{Status: Qualified, Findings: []Finding{}}
	if p.AsOf.IsZero() {
		add(&out, Indeterminate, "missing_as_of", "policy", "evaluation requires an explicit as-of time")
	}
	if b.Source == nil || b.Decision == nil || b.Intent == nil || b.Sink == nil || b.Observation == nil {
		add(&out, Indeterminate, "incomplete_chain", "bundle", "source, decision, intent, sink commit and independent observation are all required")
		return out
	}
	s, d, i, k, o := b.Source, b.Decision, b.Intent, b.Sink, b.Observation
	for _, item := range []struct {
		layer string
		e     Evidence
	}{{"source", s.Evidence}, {"decision", d.Evidence}, {"intent", i.Evidence}, {"sink", k.Evidence}, {"observation", o.Evidence}} {
		validateEvidence(&out, item.layer, item.e)
	}

	requireNonEmpty(&out, "source", "issuer", s.Issuer)
	requireNonEmpty(&out, "source", "profile", s.Profile)
	requireNonEmpty(&out, "source", "edition", s.Edition)
	requireNonEmpty(&out, "source", "statement digest", s.StatementDigest)
	requireNonEmpty(&out, "decision", "approval digest", d.ApprovalDigest)
	requireNonEmpty(&out, "decision", "policy digest", d.PolicyDigest)
	requireNonEmpty(&out, "sink", "authority evidence digest", k.AuthorityEvidenceDigest)
	requireNonEmpty(&out, "observation", "observer identity", o.ObserverID)
	if !digestPattern.MatchString(s.StatementDigest) || !digestPattern.MatchString(d.ApprovalDigest) || !digestPattern.MatchString(d.PolicyDigest) || !digestPattern.MatchString(k.AuthorityEvidenceDigest) || !digestPattern.MatchString(k.StateDigest) || !digestPattern.MatchString(o.StateDigest) || !digestPattern.MatchString(d.RequestDigest) {
		add(&out, Indeterminate, "invalid_bound_digest", "bundle", "all statement, approval, policy, request, authority-evidence and state digests must be canonical lowercase SHA-256 hex")
	}

	if s.Status != SourceCurrent && s.Status != SourceRestored {
		add(&out, Stale, "source_not_current", "source", "source is not in a currently usable publisher state")
	}
	requireEqual(&out, "decision", "source evidence ID", s.ID, d.SourceID)
	requireEqual(&out, "decision", "source evidence digest", s.Digest, d.SourceEvidenceDigest)
	requireEqual(&out, "decision", "source statement digest", s.StatementDigest, d.StatementDigest)
	if d.AuthorityState != "authorized" {
		add(&out, Unauthorized, "decision_not_authorized", "decision", "decision authority state must be explicitly authorized; measurement evidence cannot grant authority")
	}

	requireEqual(&out, "intent", "decision ID", d.ID, i.DecisionID)
	requireEqual(&out, "intent", "decision digest", d.Digest, i.DecisionDigest)
	requireEqual(&out, "intent", "principal", d.Principal, i.Principal)
	requireEqual(&out, "intent", "tenant", d.Tenant, i.Tenant)
	requireEqual(&out, "intent", "resource", d.Resource, i.Resource)
	requireEqual(&out, "intent", "mutation path", d.MutationPath, i.MutationPath)
	requireEqual(&out, "intent", "operation ID", d.OperationID, i.OperationID)
	requireEqual(&out, "intent", "request digest", d.RequestDigest, i.RequestDigest)
	requireEqual(&out, "intent", "approval digest", d.ApprovalDigest, i.ApprovalDigest)

	requireEqual(&out, "sink", "intent ID", i.ID, k.IntentID)
	requireEqual(&out, "sink", "intent digest", i.Digest, k.IntentDigest)
	requireEqual(&out, "sink", "principal", i.Principal, k.Principal)
	requireEqual(&out, "sink", "tenant", i.Tenant, k.Tenant)
	requireEqual(&out, "sink", "resource", i.Resource, k.Resource)
	requireEqual(&out, "sink", "mutation path", i.MutationPath, k.MutationPath)
	requireEqual(&out, "sink", "operation ID", i.OperationID, k.OperationID)
	requireEqual(&out, "sink", "request digest", i.RequestDigest, k.RequestDigest)
	requireEqual(&out, "sink", "authority policy digest", d.PolicyDigest, k.PolicyDigest)
	if k.Authority == nil {
		add(&out, Indeterminate, "authority_evidence_missing", "sink", "authenticated authority evidence at commit is required")
	} else {
		a := k.Authority
		validateEvidence(&out, "authority", a.Evidence)
		requireEqual(&out, "authority", "authority evidence digest", k.AuthorityEvidenceDigest, a.Digest)
		requireEqual(&out, "authority", "principal", k.Principal, a.Principal)
		requireEqual(&out, "authority", "tenant", k.Tenant, a.Tenant)
		requireEqual(&out, "authority", "resource", k.Resource, a.Resource)
		requireEqual(&out, "authority", "mutation path", k.MutationPath, a.MutationPath)
		requireEqual(&out, "authority", "policy digest", k.PolicyDigest, a.PolicyDigest)
		if p.RequireIndependentAuthority && a.TrustDomain == k.TrustDomain {
			add(&out, Contradicted, "authority_not_independent", "authority", "authority evidence shares the sink trust domain")
		}
		if !a.RevocationStatusKnown {
			add(&out, Indeterminate, "revocation_status_unknown", "authority", "revocation state was not established at the mutation commit point")
		}
		validFrom, validFromErr := parseTime(a.ValidFrom)
		expiresAt, expiresAtErr := parseTime(a.ExpiresAt)
		revocationCheckedAt, revocationCheckErr := parseTime(a.RevocationCheckedAt)
		if validFromErr != nil || expiresAtErr != nil || revocationCheckErr != nil {
			add(&out, Indeterminate, "authority_validity_uncheckable", "authority", "validity interval and revocation check time must be explicit RFC3339 timestamps")
		} else if sinkAt, err := parseTime(k.At); err == nil {
			if authorityAt, err := parseTime(a.At); err == nil && authorityAt.After(sinkAt) {
				add(&out, Indeterminate, "authority_evidence_after_commit", "authority", "authority evidence was issued after the sink commit")
			}
			if sinkAt.Before(validFrom) || !sinkAt.Before(expiresAt) {
				add(&out, Unauthorized, "authority_outside_validity", "authority", "authority evidence was not valid at the sink commit time")
			}
			if revocationCheckedAt.After(sinkAt) {
				add(&out, Indeterminate, "revocation_checked_after_commit", "authority", "revocation evidence was obtained after the mutation commit")
			} else if p.MaxAuthorityEvidenceAge > 0 && sinkAt.Sub(revocationCheckedAt) > p.MaxAuthorityEvidenceAge {
				add(&out, Stale, "revocation_evidence_stale", "authority", "revocation snapshot exceeded its maximum age at commit")
			}
			if nonEmpty(a.RevokedAt) {
				revokedAt, err := parseTime(a.RevokedAt)
				if err != nil {
					add(&out, Indeterminate, "revocation_time_uncheckable", "authority", "revocation timestamp is malformed")
				} else if !sinkAt.Before(revokedAt) {
					add(&out, Unauthorized, "authority_revoked_at_commit", "authority", "authority had been revoked at or before the sink commit")
				}
			}
		}
	}

	requireEqual(&out, "observation", "sink ID", k.ID, o.SinkID)
	requireEqual(&out, "observation", "sink digest", k.Digest, o.SinkDigest)
	requireEqual(&out, "observation", "operation ID", k.OperationID, o.OperationID)
	requireEqual(&out, "observation", "tenant", k.Tenant, o.Tenant)
	requireEqual(&out, "observation", "resource", k.Resource, o.Resource)
	if k.StateRevision != o.StateRevision {
		add(&out, Contradicted, "state_revision_mismatch", "observation", fmt.Sprintf("sink revision %d differs from observed revision %d", k.StateRevision, o.StateRevision))
	}
	requireEqual(&out, "observation", "state digest", k.StateDigest, o.StateDigest)
	if p.RequireIndependentRead && k.TrustDomain == o.TrustDomain {
		add(&out, Contradicted, "observer_not_independent", "observation", "observer shares the sink trust domain")
	}

	sourceAt, sourceErr := parseTime(s.At)
	decisionAt, decisionErr := parseTime(d.At)
	intentAt, intentErr := parseTime(i.At)
	sinkAt, sinkErr := parseTime(k.At)
	observationAt, observationErr := parseTime(o.At)
	if sourceErr == nil && decisionErr == nil {
		timeOrder(&out, "source", "decision", sourceAt, decisionAt)
	}
	if decisionErr == nil && intentErr == nil {
		timeOrder(&out, "decision", "intent", decisionAt, intentAt)
	}
	if intentErr == nil && sinkErr == nil {
		timeOrder(&out, "intent", "sink", intentAt, sinkAt)
	}
	if sinkErr == nil && observationErr == nil {
		timeOrder(&out, "sink", "observation", sinkAt, observationAt)
	}
	if !p.AsOf.IsZero() && observationErr == nil {
		if observationAt.After(p.AsOf) {
			add(&out, Indeterminate, "observation_after_as_of", "observation", "observation is later than the evaluation as-of time")
		} else if p.MaxObservationAge > 0 && p.AsOf.Sub(observationAt) > p.MaxObservationAge {
			add(&out, Stale, "observation_stale", "observation", "observation exceeds the configured maximum age")
		}
	}
	return out
}
