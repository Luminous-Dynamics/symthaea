package join

import (
	"strings"
	"testing"
	"time"
)

const (
	d1 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	d2 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
	d3 = "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
	d4 = "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"
	d5 = "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
)

func sample() Bundle {
	return Bundle{
		Source:   &SourceClaim{Evidence: Evidence{ID: "src-1", Digest: d1, Authenticated: true, TrustDomain: "publisher", At: "2026-11-25T09:00:00Z"}, Issuer: "issuer-A", Profile: "figure-v1", Edition: "2026-11", StatementDigest: d2, Status: SourceCurrent},
		Decision: &Decision{Evidence: Evidence{ID: "dec-1", Digest: d3, Authenticated: true, TrustDomain: "decision-service", At: "2026-11-25T09:01:00Z"}, SourceID: "src-1", SourceEvidenceDigest: d1, StatementDigest: d2, Principal: "agent-7", Tenant: "tenant-A", Resource: "res-9", MutationPath: "/balance/credit", OperationID: "op-11", RequestDigest: d4, ApprovalDigest: d1, PolicyDigest: d2, AuthorityState: "authorized"},
		Intent:   &Intent{Evidence: Evidence{ID: "int-1", Digest: d2, Authenticated: true, TrustDomain: "agent", At: "2026-11-25T09:02:00Z"}, DecisionID: "dec-1", DecisionDigest: d3, Principal: "agent-7", Tenant: "tenant-A", Resource: "res-9", MutationPath: "/balance/credit", OperationID: "op-11", RequestDigest: d4, ApprovalDigest: d1},
		Sink: &SinkCommit{
			Evidence: Evidence{ID: "sink-1", Digest: d4, Authenticated: true, TrustDomain: "destination", At: "2026-11-25T09:03:00Z"},
			IntentID: "int-1", IntentDigest: d2, Principal: "agent-7", Tenant: "tenant-A", Resource: "res-9", MutationPath: "/balance/credit", OperationID: "op-11", RequestDigest: d4, PolicyDigest: d2,
			AuthorityEvidenceDigest: d5,
			Authority:               &AuthorityEvidence{Evidence: Evidence{ID: "auth-1", Digest: d5, Authenticated: true, TrustDomain: "policy-control", At: "2026-11-25T09:02:50Z"}, Principal: "agent-7", Tenant: "tenant-A", Resource: "res-9", MutationPath: "/balance/credit", PolicyDigest: d2, ValidFrom: "2026-11-25T08:00:00Z", ExpiresAt: "2026-11-25T10:00:00Z", RevocationStatusKnown: true, RevocationCheckedAt: "2026-11-25T09:02:50Z"},
			StateRevision:           12, StateDigest: d1,
		},
		Observation: &Observation{Evidence: Evidence{ID: "obs-1", Digest: d3, Authenticated: true, TrustDomain: "observer", At: "2026-11-25T09:04:00Z"}, SinkID: "sink-1", SinkDigest: d4, ObserverID: "observer-3", Principal: "observer-3", Tenant: "tenant-A", Resource: "res-9", OperationID: "op-11", StateRevision: 12, StateDigest: d1},
	}
}

func policy() Policy {
	return Policy{AsOf: time.Date(2026, 11, 25, 10, 0, 0, 0, time.UTC), MaxObservationAge: time.Hour, MaxAuthorityEvidenceAge: 5 * time.Minute, RequireIndependentRead: true, RequireIndependentAuthority: true}
}
func eval(b Bundle) Result { return Evaluate(b, policy()) }
func hasCode(r Result, code string) bool {
	for _, f := range r.Findings {
		if f.Code == code {
			return true
		}
	}
	return false
}

func TestValidCausalChainQualifies(t *testing.T) {
	if r := eval(sample()); r.Status != Qualified {
		t.Fatalf("got %+v", r)
	}
}
func TestMissingObservationIsIndeterminate(t *testing.T) {
	b := sample()
	b.Observation = nil
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "incomplete_chain") {
		t.Fatalf("got %+v", r)
	}
}
func TestUnauthenticatedSourceCannotQualify(t *testing.T) {
	b := sample()
	b.Source.Authenticated = false
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "not_authenticated") {
		t.Fatalf("got %+v", r)
	}
}
func TestSourceCorrectionBlocksCurrentUse(t *testing.T) {
	b := sample()
	b.Source.Status = SourceSuperseded
	if r := eval(b); r.Status != Stale || !hasCode(r, "source_not_current") {
		t.Fatalf("got %+v", r)
	}
}
func TestDecisionMustBindExactSourceDigest(t *testing.T) {
	b := sample()
	b.Decision.SourceEvidenceDigest = d2
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestDecisionMustBeExplicitlyAuthorized(t *testing.T) {
	b := sample()
	b.Decision.AuthorityState = "none"
	if r := eval(b); r.Status != Unauthorized || !hasCode(r, "decision_not_authorized") {
		t.Fatalf("got %+v", r)
	}
}
func TestMeasurementCannotSubstituteForAuthority(t *testing.T) {
	b := sample()
	b.Decision.AuthorityState = "measurement"
	if r := eval(b); r.Status != Unauthorized {
		t.Fatalf("got %+v", r)
	}
}
func TestIntentBindsDecisionAndApproval(t *testing.T) {
	b := sample()
	b.Intent.ApprovalDigest = d2
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "join_mismatch") {
		t.Fatalf("got %+v", r)
	}
}
func TestPrincipalCannotChangeAcrossDecisionAndIntent(t *testing.T) {
	b := sample()
	b.Intent.Principal = "other-agent"
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestMissingOperationIdentityIsIndeterminate(t *testing.T) {
	b := sample()
	b.Decision.OperationID = ""
	b.Intent.OperationID = ""
	b.Sink.OperationID = ""
	b.Observation.OperationID = ""
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "missing_field") {
		t.Fatalf("got %+v", r)
	}
}
func TestOperationIdentityCannotChangeAtSink(t *testing.T) {
	b := sample()
	b.Sink.OperationID = "op-replay"
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestSinkMustBindExactIntentDigest(t *testing.T) {
	b := sample()
	b.Sink.IntentDigest = d3
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestSinkMustHaveAuthorityEvidenceAtCommit(t *testing.T) {
	b := sample()
	b.Sink.Authority = nil
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "authority_evidence_missing") {
		t.Fatalf("got %+v", r)
	}
}
func TestAuthorityEvidenceMustBindPrincipalAndScope(t *testing.T) {
	b := sample()
	b.Sink.Authority.Principal = "other-agent"
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "join_mismatch") {
		t.Fatalf("got %+v", r)
	}
}
func TestAuthorityEvidenceMustBeValidAtCommit(t *testing.T) {
	b := sample()
	b.Sink.Authority.ExpiresAt = "2026-11-25T09:02:59Z"
	if r := eval(b); r.Status != Unauthorized || !hasCode(r, "authority_outside_validity") {
		t.Fatalf("got %+v", r)
	}
}
func TestRevokedAuthorityCannotAuthorizeCommit(t *testing.T) {
	b := sample()
	b.Sink.Authority.RevokedAt = "2026-11-25T09:02:59Z"
	if r := eval(b); r.Status != Unauthorized || !hasCode(r, "authority_revoked_at_commit") {
		t.Fatalf("got %+v", r)
	}
}
func TestUnknownRevocationStatusIsIndeterminate(t *testing.T) {
	b := sample()
	b.Sink.Authority.RevocationStatusKnown = false
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "revocation_status_unknown") {
		t.Fatalf("got %+v", r)
	}
}
func TestStaleRevocationEvidenceDoesNotQualify(t *testing.T) {
	b := sample()
	b.Sink.Authority.RevocationCheckedAt = "2026-11-25T08:00:00Z"
	b.Sink.Authority.At = "2026-11-25T08:00:00Z"
	if r := eval(b); r.Status != Stale || !hasCode(r, "revocation_evidence_stale") {
		t.Fatalf("got %+v", r)
	}
}

func TestAuthorityEvidenceIssuedAfterCommitIsIndeterminate(t *testing.T) {
	b := sample()
	b.Sink.Authority.At = "2026-11-25T09:03:01Z"
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "authority_evidence_after_commit") {
		t.Fatalf("got %+v", r)
	}
}
func TestAuthorityEvidenceMustBeIndependentFromSink(t *testing.T) {
	b := sample()
	b.Sink.Authority.TrustDomain = b.Sink.TrustDomain
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "authority_not_independent") {
		t.Fatalf("got %+v", r)
	}
}
func TestPolicyDigestCannotDriftAtCommit(t *testing.T) {
	b := sample()
	b.Sink.PolicyDigest = d4
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestObserverMustBeOutsideSinkTrustDomain(t *testing.T) {
	b := sample()
	b.Observation.TrustDomain = b.Sink.TrustDomain
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "observer_not_independent") {
		t.Fatalf("got %+v", r)
	}
}
func TestObservationMustReadExactSinkRevision(t *testing.T) {
	b := sample()
	b.Observation.StateRevision++
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "state_revision_mismatch") {
		t.Fatalf("got %+v", r)
	}
}
func TestObservationMustReadExactSinkDigest(t *testing.T) {
	b := sample()
	b.Observation.StateDigest = d2
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestCausalTimeInversionContradictsChain(t *testing.T) {
	b := sample()
	b.Observation.At = "2026-11-25T09:02:30Z"
	if r := eval(b); r.Status != Contradicted || !hasCode(r, "causal_time_inversion") {
		t.Fatalf("got %+v", r)
	}
}
func TestStaleObservationDoesNotQualify(t *testing.T) {
	b := sample()
	p := policy()
	p.AsOf = time.Date(2026, 11, 25, 12, 0, 0, 0, time.UTC)
	if r := Evaluate(b, p); r.Status != Stale || !hasCode(r, "observation_stale") {
		t.Fatalf("got %+v", r)
	}
}
func TestInvalidDigestFormatIsIndeterminate(t *testing.T) {
	b := sample()
	b.Sink.StateDigest = "not-a-digest"
	b.Observation.StateDigest = "not-a-digest"
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "invalid_bound_digest") {
		t.Fatalf("got %+v", r)
	}
}
func TestInvalidTimestampIsIndeterminate(t *testing.T) {
	b := sample()
	b.Decision.At = "yesterday"
	if r := eval(b); r.Status != Indeterminate || !hasCode(r, "invalid_time") {
		t.Fatalf("got %+v", r)
	}
}
func TestObservationAfterAsOfIsNotSuccess(t *testing.T) {
	b := sample()
	p := policy()
	p.AsOf = time.Date(2026, 11, 25, 9, 3, 30, 0, time.UTC)
	r := Evaluate(b, p)
	if r.Status != Indeterminate || !hasCode(r, "observation_after_as_of") {
		t.Fatalf("got %+v", r)
	}
}
func TestMissingAsOfIsIndeterminate(t *testing.T) {
	b := sample()
	p := Policy{RequireIndependentRead: true}
	if r := Evaluate(b, p); r.Status != Indeterminate || !hasCode(r, "missing_as_of") {
		t.Fatalf("got %+v", r)
	}
}
func TestMutationPathAndTenantRemainBound(t *testing.T) {
	b := sample()
	b.Sink.MutationPath = "/balance/debit"
	b.Observation.Tenant = "tenant-B"
	r := eval(b)
	if r.Status != Contradicted || !hasCode(r, "join_mismatch") {
		t.Fatalf("got %+v", r)
	}
}
func TestNoCrossDomainJoinByMatchingTraceIDAlone(t *testing.T) {
	b := sample()
	b.Observation.SinkDigest = d1
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestSourceDecisionAndSinkTimesAreOrdered(t *testing.T) {
	b := sample()
	b.Intent.At = "2026-11-25T09:00:30Z"
	if r := eval(b); r.Status != Contradicted {
		t.Fatalf("got %+v", r)
	}
}
func TestFindingDetailsAreBounded(t *testing.T) {
	b := sample()
	b.Decision.RequestDigest = strings.Repeat("x", 64)
	if r := eval(b); !hasCode(r, "invalid_bound_digest") {
		t.Fatalf("got %+v", r)
	}
}
