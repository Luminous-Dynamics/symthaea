// Package e2e is a byte-exact composition preflight for MON-009/010/011.
// It consumes records whose profile signatures and authority evidence were
// independently verified by adapters. It is not a signature or JCS verifier.
package e2e

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

type Artifact struct {
	ID                string
	Kind              string
	Bytes             []byte
	Digest            string
	SignatureVerified bool
	TrustDomain       string
}

func NewArtifact(id, kind, trustDomain string, signatureVerified bool, payload any) (Artifact, error) {
	b, err := json.Marshal(payload)
	if err != nil {
		return Artifact{}, err
	}
	return Artifact{ID: id, Kind: kind, Bytes: b, Digest: Digest(b), SignatureVerified: signatureVerified, TrustDomain: trustDomain}, nil
}

func Digest(b []byte) string {
	s := sha256.Sum256(b)
	return "sha256:" + hex.EncodeToString(s[:])
}

type Source struct {
	Record            Artifact
	Publisher         string
	Edition           string
	StatementDigest   string
	Subject           string
	Unit              string
	Population        string
	Geography         string
	Period            string
	MethodologyDigest string
	ValueDigest       string
	Numerator         string
	Denominator       string
	ValidFrom         time.Time
	ValidUntil        time.Time
	PublishedAt       time.Time
	RecordedAt        time.Time
	Status            string    // current, superseded, retracted, disputed, unavailable
	StatusEffectiveAt time.Time // valid-time: when the publisher says the status applies
	StatusChangedAt   time.Time // transaction/recorded-time: when the verifier learned this status
}

type ClaimPayload struct {
	ClaimID           string `json:"claim_id"`
	SourceDigest      string `json:"source_digest"`
	StatementDigest   string `json:"statement_digest"`
	Subject           string `json:"subject"`
	ValueDigest       string `json:"value_digest"`
	Unit              string `json:"unit"`
	Numerator         string `json:"numerator"`
	Denominator       string `json:"denominator"`
	Population        string `json:"population"`
	Geography         string `json:"geography"`
	Period            string `json:"period"`
	MethodologyDigest string `json:"methodology_digest"`
}

type TransformationPayload struct {
	TransformationID  string `json:"transformation_id"`
	SourceDigest      string `json:"source_digest"`
	ClaimDigest       string `json:"claim_digest"`
	MethodologyDigest string `json:"methodology_digest"`
	CodeDigest        string `json:"code_digest"`
	ConfigDigest      string `json:"config_digest"`
	InputDigest       string `json:"input_digest"`
	OutputDigest      string `json:"output_digest"`
}

type ReplayPayload struct {
	ReplayID             string    `json:"replay_id"`
	TransformationDigest string    `json:"transformation_digest"`
	CodeDigest           string    `json:"code_digest"`
	ConfigDigest         string    `json:"config_digest"`
	InputDigest          string    `json:"input_digest"`
	OutputDigest         string    `json:"output_digest"`
	EnvironmentDigest    string    `json:"environment_digest"`
	ReplayedAt           time.Time `json:"replayed_at"`
}

type DecisionPayload struct {
	DecisionID           string    `json:"decision_id"`
	SourceDigest         string    `json:"source_digest"`
	ClaimDigest          string    `json:"claim_digest"`
	TransformationDigest string    `json:"transformation_digest"`
	ReplayDigest         string    `json:"replay_digest"`
	PolicyDigest         string    `json:"policy_digest"`
	AuthoritySetDigest   string    `json:"authority_set_digest"`
	Result               string    `json:"result"` // allowed, held, denied
	Principal            string    `json:"principal"`
	Tenant               string    `json:"tenant"`
	Resource             string    `json:"resource"`
	MutationPath         string    `json:"mutation_path"`
	OperationID          string    `json:"operation_id"`
	RequestDigest        string    `json:"request_digest"`
	InstanceCommitment   string    `json:"instance_commitment"`
	DisplayCommitment    string    `json:"display_commitment"`
	DecidedAt            time.Time `json:"decided_at"`
}

type ApprovalPayload struct {
	ApprovalID         string    `json:"approval_id"`
	DecisionDigest     string    `json:"decision_digest"`
	InstanceCommitment string    `json:"instance_commitment"`
	DisplayCommitment  string    `json:"display_commitment"`
	BindingDigest      string    `json:"binding_digest"`
	Nonce              string    `json:"nonce"`
	Approver           string    `json:"approver"`
	Method             string    `json:"method"`
	Approved           bool      `json:"approved"`
	ApprovedAt         time.Time `json:"approved_at"`
}

type IntentPayload struct {
	IntentID           string    `json:"intent_id"`
	DecisionDigest     string    `json:"decision_digest"`
	ApprovalDigest     string    `json:"approval_digest"`
	Principal          string    `json:"principal"`
	Tenant             string    `json:"tenant"`
	Resource           string    `json:"resource"`
	MutationPath       string    `json:"mutation_path"`
	OperationID        string    `json:"operation_id"`
	RequestDigest      string    `json:"request_digest"`
	PolicyDigest       string    `json:"policy_digest"`
	InstanceCommitment string    `json:"instance_commitment"`
	CreatedAt          time.Time `json:"created_at"`
}

type AuthorityPayload struct {
	AuthorityID  string     `json:"authority_id"`
	Principal    string     `json:"principal"`
	Tenant       string     `json:"tenant"`
	Resource     string     `json:"resource"`
	MutationPath string     `json:"mutation_path"`
	PolicyDigest string     `json:"policy_digest"`
	NotBefore    time.Time  `json:"not_before"`
	ExpiresAt    time.Time  `json:"expires_at"`
	RevokedAt    *time.Time `json:"revoked_at,omitempty"`
}

type AuthorityCheckPayload struct {
	CheckID             string    `json:"check_id"`
	DecisionDigest      string    `json:"decision_digest"`
	IntentDigest        string    `json:"intent_digest"`
	AuthorityDigest     string    `json:"authority_digest"`
	AuthoritySetDigest  string    `json:"authority_set_digest"`
	Principal           string    `json:"principal"`
	Tenant              string    `json:"tenant"`
	Resource            string    `json:"resource"`
	MutationPath        string    `json:"mutation_path"`
	PolicyDigest        string    `json:"policy_digest"`
	Result              string    `json:"result"` // current or changed
	CheckedAt           time.Time `json:"checked_at"`
	RevocationCheckedAt time.Time `json:"revocation_checked_at"`
}

type SinkPayload struct {
	SinkEventID           string    `json:"sink_event_id"`
	IntentDigest          string    `json:"intent_digest"`
	AuthorityCheckDigest  string    `json:"authority_check_digest"`
	AuthoritySetDigest    string    `json:"authority_set_digest"`
	Principal             string    `json:"principal"`
	Tenant                string    `json:"tenant"`
	Resource              string    `json:"resource"`
	MutationPath          string    `json:"mutation_path"`
	OperationID           string    `json:"operation_id"`
	RequestDigest         string    `json:"request_digest"`
	PolicyDigest          string    `json:"policy_digest"`
	InstanceCommitment    string    `json:"instance_commitment"`
	RevisionBefore        uint64    `json:"revision_before"`
	RevisionAfter         uint64    `json:"revision_after"`
	StateBeforeCommitment string    `json:"state_before_commitment"`
	StateAfterCommitment  string    `json:"state_after_commitment"`
	CommittedAt           time.Time `json:"committed_at"`
}

type ObservationPayload struct {
	ObservationID   string    `json:"observation_id"`
	SinkDigest      string    `json:"sink_digest"`
	OperationID     string    `json:"operation_id"`
	Tenant          string    `json:"tenant"`
	Resource        string    `json:"resource"`
	Revision        uint64    `json:"revision"`
	StateCommitment string    `json:"state_commitment"`
	ReadOnly        bool      `json:"read_only"`
	ObservedAt      time.Time `json:"observed_at"`
}

type Trace struct {
	Source         Source
	Claim          Artifact
	Transformation Artifact
	Replay         Artifact
	Request        Artifact // exact request bytes; need not be signed, but must be digest-bound
	Decision       Artifact
	Approval       *Artifact // optional only for policy paths that do not require human approval
	Intent         Artifact
	Authority      Artifact
	AuthorityCheck Artifact
	Sink           *Artifact
	Observation    *Artifact
}

type Class string

const (
	Committed  Class = "committed"
	Refused    Class = "refused"
	Unresolved Class = "unresolved"
)

type Status string

const (
	Qualified     Status = "qualified"
	Indeterminate Status = "indeterminate"
	Contradicted  Status = "contradicted"
	Stale         Status = "stale"
	Unauthorized  Status = "unauthorized"
)

type Report struct {
	Status            Status   `json:"status"`
	Class             Class    `json:"class"`
	Reasons           []string `json:"reasons"`
	CurrentRiskReview bool     `json:"current_risk_review"`
}

type Policy struct {
	Now                   time.Time
	MaxAuthorityCheckAge  time.Duration
	MaxRevocationCheckAge time.Duration
	MaxReadbackAge        time.Duration
	RequireHumanApproval  bool
}

func invalid(reason string, status Status, class Class) Report {
	return Report{Status: status, Class: class, Reasons: []string{reason}}
}
func verifyArtifact(a Artifact, kind string) error {
	return verifyArtifactWithSignature(a, kind, true)
}
func verifyArtifactWithSignature(a Artifact, kind string, requireSignature bool) error {
	if a.ID == "" || a.Kind != kind || len(a.Bytes) == 0 {
		return fmt.Errorf("%s artifact missing or wrong kind", kind)
	}
	if a.Digest != Digest(a.Bytes) {
		return fmt.Errorf("%s digest does not match exact payload bytes", kind)
	}
	if requireSignature && !a.SignatureVerified {
		return fmt.Errorf("%s signature or profile authentication is not verified", kind)
	}
	if a.TrustDomain == "" {
		return fmt.Errorf("%s trust domain is unknown", kind)
	}
	return nil
}
func decode[T any](a Artifact, dst *T) error {
	if err := json.Unmarshal(a.Bytes, dst); err != nil {
		return fmt.Errorf("decode %s: %w", a.Kind, err)
	}
	return nil
}
func digestLooksValid(s string) bool {
	if len(s) != 71 || s[:7] != "sha256:" {
		return false
	}
	_, err := hex.DecodeString(s[7:])
	return err == nil
}

// Verify checks semantic joins across exact-byte artifacts. Authentication booleans
// are supplied by upstream profile adapters and are not verified by this package.
func Verify(t Trace, p Policy) Report {
	if p.Now.IsZero() {
		return invalid("verification time is required", Indeterminate, Unresolved)
	}
	if p.MaxAuthorityCheckAge <= 0 || p.MaxRevocationCheckAge <= 0 || p.MaxReadbackAge <= 0 {
		return invalid("all freshness bounds must be positive", Indeterminate, Unresolved)
	}
	if err := verifyArtifact(t.Source.Record, "source"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifactWithSignature(t.Claim, "claim", false); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifactWithSignature(t.Transformation, "transformation", false); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifact(t.Replay, "replay"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifactWithSignature(t.Request, "request", false); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifact(t.Decision, "decision"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifact(t.Intent, "intent"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	if err := verifyArtifact(t.Authority, "authority"); err != nil {
		return invalid(err.Error(), Unauthorized, Refused)
	}
	if err := verifyArtifact(t.AuthorityCheck, "authority_check"); err != nil {
		return invalid(err.Error(), Unauthorized, Refused)
	}

	var claim ClaimPayload
	var transform TransformationPayload
	var replay ReplayPayload
	var d DecisionPayload
	var i IntentPayload
	var a AuthorityPayload
	var ac AuthorityCheckPayload
	if err := decode(t.Claim, &claim); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if err := decode(t.Transformation, &transform); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if err := decode(t.Replay, &replay); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if err := decode(t.Decision, &d); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if err := decode(t.Intent, &i); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if err := decode(t.Authority, &a); err != nil {
		return invalid(err.Error(), Unauthorized, Refused)
	}
	if err := decode(t.AuthorityCheck, &ac); err != nil {
		return invalid(err.Error(), Unauthorized, Refused)
	}

	if t.Source.Publisher == "" || t.Source.Edition == "" || t.Source.Subject == "" || t.Source.Unit == "" || !digestLooksValid(t.Source.StatementDigest) || t.Source.StatementDigest != t.Source.Record.Digest || t.Source.RecordedAt.IsZero() || t.Source.PublishedAt.IsZero() {
		return invalid("source assertion identity or provenance is incomplete", Indeterminate, Unresolved)
	}
	if !t.Source.ValidFrom.IsZero() && d.DecidedAt.Before(t.Source.ValidFrom) || !t.Source.ValidUntil.IsZero() && d.DecidedAt.After(t.Source.ValidUntil) {
		return invalid("source assertion was outside its valid-time interval at decision", Stale, Unresolved)
	}
	if t.Source.RecordedAt.After(d.DecidedAt) || t.Source.PublishedAt.After(d.DecidedAt) {
		return invalid("source was not published and observed when the decision was made", Stale, Unresolved)
	}
	if d.DecidedAt.IsZero() || p.Now.Before(d.DecidedAt) {
		return invalid("decision time is missing or in the future", Indeterminate, Unresolved)
	}
	if claim.ClaimID == "" || claim.SourceDigest != t.Source.Record.Digest || claim.StatementDigest != t.Source.StatementDigest || claim.Subject != t.Source.Subject || claim.Unit != t.Source.Unit || claim.ValueDigest != t.Source.ValueDigest || claim.Numerator != t.Source.Numerator || claim.Denominator != t.Source.Denominator || claim.Population != t.Source.Population || claim.Geography != t.Source.Geography || claim.Period != t.Source.Period || claim.MethodologyDigest != t.Source.MethodologyDigest || !digestLooksValid(claim.ValueDigest) {
		return invalid("claim is not bound to exact source assertion semantics", Contradicted, Unresolved)
	}
	if transform.TransformationID == "" || transform.SourceDigest != t.Source.Record.Digest || transform.ClaimDigest != t.Claim.Digest || transform.MethodologyDigest != t.Source.MethodologyDigest || transform.InputDigest != t.Source.Record.Digest || transform.OutputDigest != claim.ValueDigest || !digestLooksValid(transform.CodeDigest) || !digestLooksValid(transform.ConfigDigest) {
		return invalid("transformation does not bind the exact source, claim, method, code, configuration and output", Contradicted, Unresolved)
	}
	if replay.ReplayID == "" || replay.TransformationDigest != t.Transformation.Digest || replay.CodeDigest != transform.CodeDigest || replay.ConfigDigest != transform.ConfigDigest || replay.InputDigest != transform.InputDigest || replay.OutputDigest != transform.OutputDigest || !digestLooksValid(replay.EnvironmentDigest) || replay.ReplayedAt.IsZero() || replay.ReplayedAt.After(d.DecidedAt) || t.Replay.TrustDomain == t.Transformation.TrustDomain {
		return invalid("independent replay does not reproduce the exact transformation inputs and output", Contradicted, Unresolved)
	}
	if d.SourceDigest != t.Source.Record.Digest || d.ClaimDigest != t.Claim.Digest || d.TransformationDigest != t.Transformation.Digest || d.ReplayDigest != t.Replay.Digest {
		return invalid("decision does not bind exact source, claim, transformation and independent replay records", Contradicted, Unresolved)
	}
	if t.Request.Digest != d.RequestDigest || t.Request.Digest != Digest(t.Request.Bytes) {
		return invalid("decision request digest does not bind exact request bytes", Contradicted, Unresolved)
	}
	if d.Result != "allowed" && d.Result != "held" {
		return invalid("decision did not allow or hold this action", Unauthorized, Refused)
	}
	if !digestLooksValid(d.PolicyDigest) || !digestLooksValid(d.AuthoritySetDigest) || !digestLooksValid(d.RequestDigest) || !digestLooksValid(d.InstanceCommitment) || !digestLooksValid(d.DisplayCommitment) {
		return invalid("decision lacks a valid policy, authority-set, request or instance commitment", Indeterminate, Unresolved)
	}

	if p.RequireHumanApproval || d.Result == "held" {
		if t.Approval == nil {
			return invalid("required approval statement is missing", Indeterminate, Unresolved)
		}
	}
	if t.Approval != nil {
		if err := verifyArtifact(*t.Approval, "approval"); err != nil {
			return invalid(err.Error(), Indeterminate, Unresolved)
		}
		var ap ApprovalPayload
		if err := decode(*t.Approval, &ap); err != nil {
			return invalid(err.Error(), Contradicted, Unresolved)
		}
		if ap.DecisionDigest != t.Decision.Digest || ap.InstanceCommitment != d.InstanceCommitment || ap.DisplayCommitment != d.DisplayCommitment || ap.BindingDigest == "" || ap.Nonce == "" || ap.Approver == "" {
			return invalid("approval does not bind the exact decision, action instance and displayed content", Contradicted, Unresolved)
		}
		if !ap.Approved {
			return invalid("approval was rejected or expired", Unauthorized, Refused)
		}
		if ap.ApprovedAt.Before(d.DecidedAt) || ap.ApprovedAt.After(p.Now) {
			return invalid("approval timestamp is outside the decision-to-verification interval", Contradicted, Unresolved)
		}
	}

	if i.DecisionDigest != t.Decision.Digest || i.Principal != d.Principal || i.Tenant != d.Tenant || i.Resource != d.Resource || i.MutationPath != d.MutationPath || i.OperationID != d.OperationID || i.RequestDigest != d.RequestDigest || i.PolicyDigest != d.PolicyDigest || i.InstanceCommitment != d.InstanceCommitment {
		return invalid("intent is not byte-exactly bound to the approved decision and scope", Contradicted, Unresolved)
	}
	if i.ApprovalDigest != "" {
		if t.Approval == nil || i.ApprovalDigest != t.Approval.Digest {
			return invalid("intent references a different approval record", Contradicted, Unresolved)
		}
	} else if p.RequireHumanApproval || d.Result == "held" {
		return invalid("intent omits the required approval digest", Contradicted, Unresolved)
	}
	if i.CreatedAt.Before(d.DecidedAt) || i.CreatedAt.After(p.Now) {
		return invalid("intent timestamp is outside the decision-to-verification interval", Contradicted, Unresolved)
	}

	if t.Authority.TrustDomain == "" || t.Authority.TrustDomain == t.Intent.TrustDomain {
		return invalid("authority credential is not independently administered from the agent/intent domain", Indeterminate, Unresolved)
	}
	if a.Principal != d.Principal || a.Tenant != d.Tenant || a.Resource != d.Resource || a.MutationPath != d.MutationPath || a.PolicyDigest != d.PolicyDigest {
		return invalid("authority credential does not match principal, scope and policy", Unauthorized, Refused)
	}
	if ac.DecisionDigest != t.Decision.Digest || ac.IntentDigest != t.Intent.Digest || ac.AuthorityDigest != t.Authority.Digest || ac.AuthoritySetDigest != d.AuthoritySetDigest {
		return invalid("commit-time authority check is not bound to decision, intent and exact authority set", Contradicted, Unresolved)
	}
	if ac.Principal != d.Principal || ac.Tenant != d.Tenant || ac.Resource != d.Resource || ac.MutationPath != d.MutationPath || ac.PolicyDigest != d.PolicyDigest {
		return invalid("commit-time authority check scope or policy differs", Unauthorized, Refused)
	}
	if ac.Result != "current" {
		return invalid("authority changed before commit; action must be refused", Unauthorized, Refused)
	}
	if ac.CheckedAt.Before(i.CreatedAt) || ac.CheckedAt.After(p.Now) {
		return invalid("authority check time is not after intent and before verification", Contradicted, Unresolved)
	}
	if ac.RevocationCheckedAt.Before(ac.CheckedAt) || ac.RevocationCheckedAt.After(p.Now) {
		return invalid("revocation state is unknown, future-dated or stale", Indeterminate, Unresolved)
	}
	if !a.NotBefore.IsZero() && ac.CheckedAt.Before(a.NotBefore) {
		return invalid("authority credential is not valid at commit-time check", Unauthorized, Refused)
	}
	if t.AuthorityCheck.TrustDomain == t.Intent.TrustDomain || t.AuthorityCheck.TrustDomain == t.Authority.TrustDomain {
		return invalid("authority re-check does not come from an independent control-plane domain", Indeterminate, Unresolved)
	}

	if t.Sink == nil {
		return invalid("no sink commit record; action remains unresolved", Indeterminate, Unresolved)
	}
	if err := verifyArtifact(*t.Sink, "sink"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	var s SinkPayload
	if err := decode(*t.Sink, &s); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if s.IntentDigest != t.Intent.Digest || s.AuthorityCheckDigest != t.AuthorityCheck.Digest || s.AuthoritySetDigest != d.AuthoritySetDigest || s.Principal != d.Principal || s.Tenant != d.Tenant || s.Resource != d.Resource || s.MutationPath != d.MutationPath || s.OperationID != d.OperationID || s.RequestDigest != d.RequestDigest || s.PolicyDigest != d.PolicyDigest || s.InstanceCommitment != d.InstanceCommitment {
		return invalid("sink commit is not joined to the exact intent, authority check, action and scope", Contradicted, Unresolved)
	}
	if s.RevisionAfter <= s.RevisionBefore || !digestLooksValid(s.StateBeforeCommitment) || !digestLooksValid(s.StateAfterCommitment) {
		return invalid("sink commit lacks a monotonic revision or valid before/after commitments", Contradicted, Unresolved)
	}
	if s.CommittedAt.Before(ac.CheckedAt) || s.CommittedAt.Before(i.CreatedAt) || s.CommittedAt.After(p.Now) {
		return invalid("sink commit time is outside the authorized intent window", Contradicted, Unresolved)
	}
	if s.CommittedAt.Sub(ac.CheckedAt) > p.MaxAuthorityCheckAge || s.CommittedAt.Sub(ac.RevocationCheckedAt) > p.MaxRevocationCheckAge {
		return invalid("authority or revocation evidence was not fresh at commit", Indeterminate, Unresolved)
	}
	if !a.NotBefore.IsZero() && s.CommittedAt.Before(a.NotBefore) || !a.ExpiresAt.IsZero() && !s.CommittedAt.Before(a.ExpiresAt) {
		return invalid("authority credential was not valid at sink commit", Unauthorized, Refused)
	}
	if a.RevokedAt != nil && !a.RevokedAt.After(s.CommittedAt) {
		return invalid("authority was revoked before sink commit", Unauthorized, Refused)
	}
	if t.Sink.TrustDomain == t.Intent.TrustDomain || t.Sink.TrustDomain == t.Authority.TrustDomain || t.Sink.TrustDomain == t.AuthorityCheck.TrustDomain {
		return invalid("sink shares a required-independent trust domain with an upstream authority or intent record", Indeterminate, Unresolved)
	}

	currentRiskReview := false
	historicalSourceStale := false
	if t.Source.Status != "" && t.Source.Status != "current" {
		if t.Source.StatusChangedAt.IsZero() || t.Source.StatusEffectiveAt.IsZero() {
			return invalid("non-current source status lacks separate effective-time and recorded-time evidence", Indeterminate, Unresolved)
		}
		// A correction not yet recorded by the audit cutoff is not yet known in
		// that as-of view. A known but future-effective correction also cannot
		// retroactively invalidate the state before its valid-time boundary.
		if !t.Source.StatusChangedAt.After(p.Now) && !t.Source.StatusEffectiveAt.After(p.Now) {
			currentRiskReview = true
			if !t.Source.StatusEffectiveAt.After(s.CommittedAt) {
				historicalSourceStale = true
			}
		}
	}

	if t.Observation == nil {
		return Report{Status: Indeterminate, Class: Unresolved, Reasons: []string{"sink commit exists but independent readback is missing"}, CurrentRiskReview: currentRiskReview}
	}
	if err := verifyArtifact(*t.Observation, "observation"); err != nil {
		return invalid(err.Error(), Indeterminate, Unresolved)
	}
	var o ObservationPayload
	if err := decode(*t.Observation, &o); err != nil {
		return invalid(err.Error(), Contradicted, Unresolved)
	}
	if o.SinkDigest != t.Sink.Digest || o.OperationID != d.OperationID || o.Tenant != d.Tenant || o.Resource != d.Resource || o.Revision != s.RevisionAfter || o.StateCommitment != s.StateAfterCommitment {
		return Report{Status: Contradicted, Class: Unresolved, Reasons: []string{"readback does not match exact sink commit, action identity or state revision/commitment"}, CurrentRiskReview: currentRiskReview}
	}
	if !o.ReadOnly {
		return invalid("outcome confirmation was not a read-only system-of-record observation", Indeterminate, Unresolved)
	}
	if o.ObservedAt.Before(s.CommittedAt) || o.ObservedAt.After(p.Now) {
		return invalid("observation time is before commit or in the future", Contradicted, Unresolved)
	}
	if o.ObservedAt.Sub(s.CommittedAt) > p.MaxReadbackAge {
		return invalid("system-of-record readback arrived outside the commit confirmation window", Stale, Unresolved)
	}
	if t.Observation.TrustDomain == t.Sink.TrustDomain {
		return invalid("observer and sink are in the same declared trust domain", Indeterminate, Unresolved)
	}

	if historicalSourceStale {
		return Report{Status: Stale, Class: Committed, Reasons: []string{"effect is independently confirmed, but a source correction recorded by this audit cutoff is effective at or before the commit time; preserve the historical action and escalate current-risk review"}, CurrentRiskReview: true}
	}
	return Report{Status: Qualified, Class: Committed, Reasons: []string{"exact source-to-claim-to-transformation-to-independent-replay-to-decision-to-approval-to-intent-to-commit-to-readback chain verified"}, CurrentRiskReview: currentRiskReview}
}

// ValidateExactBytes checks that a parsed payload is exactly the byte sequence
// that was hashed. It does not impose a cross-language canonical JSON profile.
func ValidateExactBytes(a Artifact) error {
	if len(a.Bytes) == 0 {
		return errors.New("empty payload")
	}
	if a.Digest != Digest(a.Bytes) {
		return errors.New("payload digest mismatch")
	}
	return nil
}

// SameBytes is used by adapters that keep an independent copy of signed bytes.
func SameBytes(a, b []byte) bool { return bytes.Equal(a, b) }
