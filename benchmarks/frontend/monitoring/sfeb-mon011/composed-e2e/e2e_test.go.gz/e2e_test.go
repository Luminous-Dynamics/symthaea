package e2e

import (
	"encoding/json"
	"testing"
	"time"
)

var baseTime = time.Date(2026, 11, 26, 8, 0, 0, 0, time.UTC)

func dt(seconds int) time.Time { return baseTime.Add(time.Duration(seconds) * time.Second) }
func mustArtifact(t *testing.T, id, kind, td string, payload any) Artifact {
	t.Helper()
	a, err := NewArtifact(id, kind, td, true, payload)
	if err != nil {
		t.Fatal(err)
	}
	return a
}
func digestOf(t *testing.T, x any) string {
	t.Helper()
	b, e := json.Marshal(x)
	if e != nil {
		t.Fatal(e)
	}
	return Digest(b)
}
func goodTrace(t *testing.T) (Trace, Policy) {
	t.Helper()
	sourceBytes := []byte(`{"figure":"grid_loss","edition":"2026-11","period":"2026-10","population":"NTCSA transmission","unit":"percent","value":4.2}`)
	source := Artifact{ID: "src-1", Kind: "source", Bytes: sourceBytes, Digest: Digest(sourceBytes), SignatureVerified: true, TrustDomain: "publisher-ledger"}
	request := []byte(`{"type":"set_dispatch_limit","resource":"feeder-7","target":82,"idempotency_key":"op-0007"}`)
	requestDigest := Digest(request)
	instance := Digest([]byte("oar-instance-commitment-for-op-0007"))
	display := Digest([]byte("displayed exact action: feeder-7 limit 82"))
	policy := Digest([]byte("policy-v4"))
	requestArtifact := Artifact{ID: "request-1", Kind: "request", Bytes: request, Digest: requestDigest, TrustDomain: "agent-harness"}
	valueDigest := Digest([]byte("normalized-grid-loss-value-4.2-percent"))
	sourceMethod := Digest([]byte("method-v2"))
	claimPayload := ClaimPayload{ClaimID: "claim-1", SourceDigest: source.Digest, StatementDigest: Digest(sourceBytes), Subject: "grid_loss", ValueDigest: valueDigest, Unit: "percent", Numerator: "4.2", Denominator: "100", Population: "NTCSA transmission", Geography: "South Africa", Period: "2026-10", MethodologyDigest: sourceMethod}
	claim := mustArtifact(t, "claim-1", "claim", "claimgraph-ledger", claimPayload)
	codeDigest := Digest([]byte("symthaea-transform-binary-v1"))
	configDigest := Digest([]byte("grid-loss-transform-config-v1"))
	transformPayload := TransformationPayload{TransformationID: "transform-1", SourceDigest: source.Digest, ClaimDigest: claim.Digest, MethodologyDigest: sourceMethod, CodeDigest: codeDigest, ConfigDigest: configDigest, InputDigest: source.Digest, OutputDigest: valueDigest}
	transformation := mustArtifact(t, "transform-1", "transformation", "analysis-pipeline", transformPayload)
	replayPayload := ReplayPayload{ReplayID: "replay-1", TransformationDigest: transformation.Digest, CodeDigest: codeDigest, ConfigDigest: configDigest, InputDigest: source.Digest, OutputDigest: valueDigest, EnvironmentDigest: Digest([]byte("nix-locked-env-linux-amd64")), ReplayedAt: dt(0)}
	replay := mustArtifact(t, "replay-1", "replay", "independent-replay-worker", replayPayload)
	authorityPayload := AuthorityPayload{AuthorityID: "auth-1", Principal: "agent-7", Tenant: "tenant-a", Resource: "feeder-7", MutationPath: "/dispatch/limit", PolicyDigest: policy, NotBefore: dt(0), ExpiresAt: dt(120)}
	authority := mustArtifact(t, "auth-credential-1", "authority", "identity-provider", authorityPayload)
	authoritySet := Digest([]byte(authority.Digest))
	d := DecisionPayload{DecisionID: "dec-1", SourceDigest: source.Digest, ClaimDigest: claim.Digest, TransformationDigest: transformation.Digest, ReplayDigest: replay.Digest, PolicyDigest: policy, AuthoritySetDigest: authoritySet, Result: "held", Principal: "agent-7", Tenant: "tenant-a", Resource: "feeder-7", MutationPath: "/dispatch/limit", OperationID: "op-0007", RequestDigest: requestDigest, InstanceCommitment: instance, DisplayCommitment: display, DecidedAt: dt(1)}
	decision := mustArtifact(t, "dec-1", "decision", "decision-service", d)
	ap := ApprovalPayload{ApprovalID: "approval-1", DecisionDigest: decision.Digest, InstanceCommitment: instance, DisplayCommitment: display, BindingDigest: Digest([]byte("passkey-bound-v2-approval")), Nonce: "nonce-0001", Approver: "operator-9", Method: "passkey", Approved: true, ApprovedAt: dt(2)}
	approval := mustArtifact(t, "approval-1", "approval", "approval-provider", ap)
	i := IntentPayload{IntentID: "intent-1", DecisionDigest: decision.Digest, ApprovalDigest: approval.Digest, Principal: d.Principal, Tenant: d.Tenant, Resource: d.Resource, MutationPath: d.MutationPath, OperationID: d.OperationID, RequestDigest: requestDigest, PolicyDigest: policy, InstanceCommitment: instance, CreatedAt: dt(3)}
	intent := mustArtifact(t, "intent-1", "intent", "agent-harness", i)
	// The authority check is signed/verified by an independently administered control-plane adapter.
	acp := AuthorityCheckPayload{CheckID: "auth-check-1", DecisionDigest: decision.Digest, IntentDigest: intent.Digest, AuthorityDigest: authority.Digest, AuthoritySetDigest: authoritySet, Principal: d.Principal, Tenant: d.Tenant, Resource: d.Resource, MutationPath: d.MutationPath, PolicyDigest: policy, Result: "current", CheckedAt: dt(4), RevocationCheckedAt: dt(4)}
	authorityCheck := mustArtifact(t, "auth-check-1", "authority_check", "policy-control-plane", acp)
	sp := SinkPayload{SinkEventID: "sink-event-1", IntentDigest: intent.Digest, AuthorityCheckDigest: authorityCheck.Digest, AuthoritySetDigest: authoritySet, Principal: d.Principal, Tenant: d.Tenant, Resource: d.Resource, MutationPath: d.MutationPath, OperationID: d.OperationID, RequestDigest: requestDigest, PolicyDigest: policy, InstanceCommitment: instance, RevisionBefore: 100, RevisionAfter: 101, StateBeforeCommitment: Digest([]byte("state-before-100")), StateAfterCommitment: Digest([]byte("state-after-101")), CommittedAt: dt(5)}
	sink := mustArtifact(t, "sink-event-1", "sink", "destination-db", sp)
	op := ObservationPayload{ObservationID: "obs-1", SinkDigest: sink.Digest, OperationID: d.OperationID, Tenant: d.Tenant, Resource: d.Resource, Revision: 101, StateCommitment: sp.StateAfterCommitment, ReadOnly: true, ObservedAt: dt(6)}
	observation := mustArtifact(t, "obs-1", "observation", "independent-readback", op)
	src := Source{Record: source, Publisher: "NTCSA", Edition: "2026-11", StatementDigest: Digest(sourceBytes), Subject: "grid_loss", Unit: "percent", Population: "NTCSA transmission", Geography: "South Africa", Period: "2026-10", MethodologyDigest: sourceMethod, ValueDigest: valueDigest, Numerator: "4.2", Denominator: "100", ValidFrom: dt(-86400), ValidUntil: dt(86400), PublishedAt: dt(0), RecordedAt: dt(0), Status: "current"}
	tr := Trace{Source: src, Claim: claim, Transformation: transformation, Replay: replay, Request: requestArtifact, Decision: decision, Approval: &approval, Intent: intent, Authority: authority, AuthorityCheck: authorityCheck, Sink: &sink, Observation: &observation}
	pol := Policy{Now: dt(7), MaxAuthorityCheckAge: 10 * time.Second, MaxRevocationCheckAge: 10 * time.Second, MaxReadbackAge: 10 * time.Second, RequireHumanApproval: true}
	return tr, pol
}
func expect(t *testing.T, tr Trace, p Policy, status Status, class Class) Report {
	t.Helper()
	r := Verify(tr, p)
	if r.Status != status || r.Class != class {
		t.Fatalf("got %+v, want %s/%s", r, status, class)
	}
	return r
}
func TestByteExactEndToEndTraceQualifies(t *testing.T) {
	tr, p := goodTrace(t)
	r := expect(t, tr, p, Qualified, Committed)
	if len(r.Reasons) == 0 {
		t.Fatal("missing evidence rationale")
	}
}
func TestSourceBytesTamperingFailsEvenWhenTraceIDsRemain(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Record.Bytes = append(tr.Source.Record.Bytes, []byte(" ")...)
	expect(t, tr, p, Indeterminate, Unresolved)
}
func TestDecisionCannotSubstituteSourceDigest(t *testing.T) {
	tr, p := goodTrace(t)
	var d DecisionPayload
	if e := decode(tr.Decision, &d); e != nil {
		t.Fatal(e)
	}
	d.SourceDigest = Digest([]byte("different source"))
	tr.Decision = mustArtifact(t, tr.Decision.ID, "decision", tr.Decision.TrustDomain, d)
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestApprovalMustBindExactlyWhatWasShown(t *testing.T) {
	tr, p := goodTrace(t)
	var ap ApprovalPayload
	_ = decode(*tr.Approval, &ap)
	ap.DisplayCommitment = Digest([]byte("different amount or target"))
	a := mustArtifact(t, tr.Approval.ID, "approval", tr.Approval.TrustDomain, ap)
	tr.Approval = &a
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestApprovalFlipRejectIsNotAccepted(t *testing.T) {
	tr, p := goodTrace(t)
	var ap ApprovalPayload
	_ = decode(*tr.Approval, &ap)
	ap.Approved = false
	a := mustArtifact(t, tr.Approval.ID, "approval", tr.Approval.TrustDomain, ap)
	tr.Approval = &a
	expect(t, tr, p, Unauthorized, Refused)
}
func TestIntentCannotChangePrincipalOrOperation(t *testing.T) {
	tr, p := goodTrace(t)
	var i IntentPayload
	_ = decode(tr.Intent, &i)
	i.Principal = "agent-attacker"
	tr.Intent = mustArtifact(t, tr.Intent.ID, "intent", tr.Intent.TrustDomain, i)
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestAuthorityMustBeValidAtCommit(t *testing.T) {
	tr, p := goodTrace(t)
	var a AuthorityPayload
	_ = decode(tr.Authority, &a)
	a.ExpiresAt = dt(3)
	tr.Authority = mustArtifact(t, tr.Authority.ID, "authority", tr.Authority.TrustDomain, a)
	var check AuthorityCheckPayload
	_ = decode(tr.AuthorityCheck, &check)
	check.AuthorityDigest = tr.Authority.Digest
	tr.AuthorityCheck = mustArtifact(t, tr.AuthorityCheck.ID, "authority_check", tr.AuthorityCheck.TrustDomain, check)
	var sink SinkPayload
	_ = decode(*tr.Sink, &sink)
	sink.AuthorityCheckDigest = tr.AuthorityCheck.Digest
	s := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, sink)
	tr.Sink = &s
	var o ObservationPayload
	_ = decode(*tr.Observation, &o)
	o.SinkDigest = s.Digest
	obs := mustArtifact(t, tr.Observation.ID, "observation", tr.Observation.TrustDomain, o)
	tr.Observation = &obs
	expect(t, tr, p, Unauthorized, Refused)
}
func TestRevocationBeforeCommitFailsClosed(t *testing.T) {
	tr, p := goodTrace(t)
	rev := dt(4)
	var a AuthorityPayload
	_ = decode(tr.Authority, &a)
	a.RevokedAt = &rev
	tr.Authority = mustArtifact(t, tr.Authority.ID, "authority", tr.Authority.TrustDomain, a)
	var check AuthorityCheckPayload
	_ = decode(tr.AuthorityCheck, &check)
	check.AuthorityDigest = tr.Authority.Digest
	tr.AuthorityCheck = mustArtifact(t, tr.AuthorityCheck.ID, "authority_check", tr.AuthorityCheck.TrustDomain, check)
	var sink SinkPayload
	_ = decode(*tr.Sink, &sink)
	sink.AuthorityCheckDigest = tr.AuthorityCheck.Digest
	s := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, sink)
	tr.Sink = &s
	var o ObservationPayload
	_ = decode(*tr.Observation, &o)
	o.SinkDigest = s.Digest
	obs := mustArtifact(t, tr.Observation.ID, "observation", tr.Observation.TrustDomain, o)
	tr.Observation = &obs
	expect(t, tr, p, Unauthorized, Refused)
}
func TestAuthoritySetMismatchFails(t *testing.T) {
	tr, p := goodTrace(t)
	var ac AuthorityCheckPayload
	_ = decode(tr.AuthorityCheck, &ac)
	ac.AuthoritySetDigest = Digest([]byte("different authority set"))
	tr.AuthorityCheck = mustArtifact(t, tr.AuthorityCheck.ID, "authority_check", tr.AuthorityCheck.TrustDomain, ac)
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestUnknownRevocationStateIsIndeterminate(t *testing.T) {
	tr, p := goodTrace(t)
	var ac AuthorityCheckPayload
	_ = decode(tr.AuthorityCheck, &ac)
	ac.RevocationCheckedAt = dt(-5)
	tr.AuthorityCheck = mustArtifact(t, tr.AuthorityCheck.ID, "authority_check", tr.AuthorityCheck.TrustDomain, ac)
	var s SinkPayload
	_ = decode(*tr.Sink, &s)
	s.AuthorityCheckDigest = tr.AuthorityCheck.Digest
	sink := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, s)
	tr.Sink = &sink
	var o ObservationPayload
	_ = decode(*tr.Observation, &o)
	o.SinkDigest = sink.Digest
	obs := mustArtifact(t, tr.Observation.ID, "observation", tr.Observation.TrustDomain, o)
	tr.Observation = &obs
	expect(t, tr, p, Indeterminate, Unresolved)
}
func TestSharedAuthorityAndSinkDomainIsNotIndependent(t *testing.T) {
	tr, p := goodTrace(t)
	tr.AuthorityCheck.TrustDomain = tr.Sink.TrustDomain
	expect(t, tr, p, Indeterminate, Unresolved)
}
func TestSinkMustBindIntentExactly(t *testing.T) {
	tr, p := goodTrace(t)
	var s SinkPayload
	_ = decode(*tr.Sink, &s)
	s.IntentDigest = Digest([]byte("other intent"))
	sink := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, s)
	tr.Sink = &sink
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestReadbackMustMatchExactStateAndRevision(t *testing.T) {
	tr, p := goodTrace(t)
	var o ObservationPayload
	_ = decode(*tr.Observation, &o)
	o.StateCommitment = Digest([]byte("wrong state"))
	obs := mustArtifact(t, tr.Observation.ID, "observation", tr.Observation.TrustDomain, o)
	tr.Observation = &obs
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestObserverCannotBeSink(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Observation.TrustDomain = tr.Sink.TrustDomain
	expect(t, tr, p, Indeterminate, Unresolved)
}
func TestMissingObservationRemainsUnresolved(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Observation = nil
	expect(t, tr, p, Indeterminate, Unresolved)
}
func TestStaleReadbackIsNotCommitConfirmation(t *testing.T) {
	tr, p := goodTrace(t)
	p.Now = dt(100)
	var o ObservationPayload
	_ = decode(*tr.Observation, &o)
	o.ObservedAt = dt(50) // 45 seconds after commit; exceeds the 10-second confirmation window.
	obs := mustArtifact(t, tr.Observation.ID, "observation", tr.Observation.TrustDomain, o)
	tr.Observation = &obs
	expect(t, tr, p, Stale, Unresolved)
}
func TestSourceCorrectionBeforeCommitRequiresReauthorization(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Status = "superseded"
	tr.Source.StatusEffectiveAt = dt(4)
	tr.Source.StatusChangedAt = dt(4)
	expect(t, tr, p, Stale, Committed)
}
func TestLaterSourceCorrectionDoesNotRewriteHistoricalCommit(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Status = "superseded"
	tr.Source.StatusEffectiveAt = dt(9)
	tr.Source.StatusChangedAt = dt(9)
	p.Now = dt(10)
	r := expect(t, tr, p, Qualified, Committed)
	if !r.CurrentRiskReview {
		t.Fatal("expected separate current-risk review for later correction")
	}
}
func TestFutureOrUnrecordedSourceCannotSupportDecision(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.RecordedAt = dt(2)
	expect(t, tr, p, Stale, Unresolved)
}
func TestCommitBeforeAuthorityCheckIsRejected(t *testing.T) {
	tr, p := goodTrace(t)
	var s SinkPayload
	_ = decode(*tr.Sink, &s)
	s.CommittedAt = dt(3)
	sink := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, s)
	tr.Sink = &sink
	expect(t, tr, p, Contradicted, Unresolved)
}
func TestActionInstanceCommitmentRemainsBoundAcrossSinkAndReadback(t *testing.T) {
	tr, p := goodTrace(t)
	var s SinkPayload
	_ = decode(*tr.Sink, &s)
	s.InstanceCommitment = Digest([]byte("different action"))
	sink := mustArtifact(t, tr.Sink.ID, "sink", tr.Sink.TrustDomain, s)
	tr.Sink = &sink
	expect(t, tr, p, Contradicted, Unresolved)
}

func TestLaterAuditDoesNotInvalidateTimelyHistoricalReadback(t *testing.T) {
	tr, p := goodTrace(t)
	p.Now = dt(100000)
	expect(t, tr, p, Qualified, Committed)
}

func TestClaimCannotChangeUnitOrPopulation(t *testing.T) {
	tr, p := goodTrace(t)
	var claim ClaimPayload
	_ = decode(tr.Claim, &claim)
	claim.Unit = "megawatt-hours"
	tr.Claim = mustArtifact(t, tr.Claim.ID, "claim", tr.Claim.TrustDomain, claim)
	expect(t, tr, p, Contradicted, Unresolved)
}

func TestDecisionMustBindTransformationAndReplay(t *testing.T) {
	tr, p := goodTrace(t)
	var d DecisionPayload
	_ = decode(tr.Decision, &d)
	d.TransformationDigest = Digest([]byte("different transformation"))
	tr.Decision = mustArtifact(t, tr.Decision.ID, "decision", tr.Decision.TrustDomain, d)
	expect(t, tr, p, Contradicted, Unresolved)
}

func TestIndependentReplayMustMatchExactOutput(t *testing.T) {
	tr, p := goodTrace(t)
	var replay ReplayPayload
	_ = decode(tr.Replay, &replay)
	replay.OutputDigest = Digest([]byte("different replay result"))
	tr.Replay = mustArtifact(t, tr.Replay.ID, "replay", tr.Replay.TrustDomain, replay)
	expect(t, tr, p, Contradicted, Unresolved)
}

func TestRequestDigestBindsExactRequestBytes(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Request.Bytes = append(tr.Request.Bytes, []byte(" ")...)
	tr.Request.Digest = Digest(tr.Request.Bytes)
	expect(t, tr, p, Contradicted, Unresolved)
}

func TestLateRecordedRetroactiveCorrectionChallengesButDoesNotRewriteCommittedEffect(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Status = "superseded"
	tr.Source.StatusEffectiveAt = dt(4) // valid-time before the sink commit
	tr.Source.StatusChangedAt = dt(9)   // learned only after the commit
	p.Now = dt(10)
	r := expect(t, tr, p, Stale, Committed)
	if !r.CurrentRiskReview {
		t.Fatal("retroactive correction must trigger current-risk review")
	}
}

func TestCorrectionNotYetRecordedAtAuditCutoffDoesNotChangeAsOfView(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Status = "superseded"
	tr.Source.StatusEffectiveAt = dt(4)
	tr.Source.StatusChangedAt = dt(15)
	p.Now = dt(10)
	r := expect(t, tr, p, Qualified, Committed)
	if r.CurrentRiskReview {
		t.Fatal("correction not yet recorded at the audit cutoff must not affect that as-of view")
	}
}

func TestCorrectionEffectiveAfterCommitTriggersRiskReviewWithoutInvalidatingAction(t *testing.T) {
	tr, p := goodTrace(t)
	tr.Source.Status = "superseded"
	tr.Source.StatusEffectiveAt = dt(9)
	tr.Source.StatusChangedAt = dt(8)
	p.Now = dt(10)
	r := expect(t, tr, p, Qualified, Committed)
	if !r.CurrentRiskReview {
		t.Fatal("later-effective correction should trigger current-risk review")
	}
}

func TestClaimValueDigestMustMatchSourceBoundValue(t *testing.T) {
	tr, p := goodTrace(t)
	var claim ClaimPayload
	_ = decode(tr.Claim, &claim)
	claim.ValueDigest = Digest([]byte("substituted-figure"))
	tr.Claim = mustArtifact(t, tr.Claim.ID, "claim", tr.Claim.TrustDomain, claim)
	expect(t, tr, p, Contradicted, Unresolved)
}
