#!/usr/bin/env node
// SFEB MON-004 PostgreSQL claim/fence reference model v1.
// Pure in-memory bounded model. It is NOT PostgreSQL execution or a concurrent
// memory-model proof. The purpose is to expose contract counterexamples before
// spending time on the real database adapter.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const fail = (code, message) => Object.assign(new Error(message), { code });
const makeRow = ({tenant='tenant-A',objective='objective-1',aggregate='aggregate-A',sequence=1,actionKey=`action-${sequence}`,id=`event-${sequence}`,requestDigest=digest({tenant,objective,aggregate,sequence,actionKey})}={}) => ({tenant,objective,aggregate,sequence,actionKey,id,requestDigest,status:'pending',remoteOutcome:'not_attempted',claimEpoch:0,claimToken:null,claimedBy:null,claimExpiresAt:null,attempts:0,readback:null});
const scope = (tenant, objective) => JSON.stringify([tenant,objective]);
const operationKey = (tenant, actionKey) => JSON.stringify([tenant,actionKey]);

class ClaimModel {
  constructor(rows=[makeRow()]) {
    this.rows=rows.map(r=>({...r}));
    this.objectiveFences=new Map();
    this.actionPolicy=new Map();
    this.readPolicy=new Map();
    this.remoteOperations=new Map();
    this.remoteEffects=[];
    this.claimCounter=0;
  }
  addTenant(tenant='tenant-A',objective='objective-1',{epoch=1,permitted=true,revision=1,reader='auditor-A'}={}) {
    this.objectiveFences.set(scope(tenant,objective),epoch);
    this.actionPolicy.set(tenant,{revision,permitted});
    this.readPolicy.set(JSON.stringify([tenant,reader]),{revision:1,allowed:true});
  }
  row(id) { const r=this.rows.find(x=>x.id===id); if(!r) throw fail('UNKNOWN_EVENT','outbox event not found'); return r; }
  fence(tenant,objective) { return this.objectiveFences.get(scope(tenant,objective)); }
  _claimValid(row,claim,now) {
    return !!claim && row.status==='leased' && row.claimedBy===claim.worker && row.claimEpoch===claim.claimEpoch && row.claimToken===claim.claimToken && row.claimExpiresAt>now;
  }
  _requireClaim(row,claim,now) { if(!this._claimValid(row,claim,now)) throw fail('CLAIM_STALE','claim identity is not current and unexpired'); }
  _priorAggregateDelivered(row) {
    return this.rows.filter(x=>x.tenant===row.tenant && x.aggregate===row.aggregate && x.sequence<row.sequence).every(x=>x.status==='delivered');
  }
  claim(worker,now,ttl=10) {
    if(!worker || !Number.isSafeInteger(now) || !Number.isSafeInteger(ttl) || ttl<=0) throw fail('INVALID_CLAIM','invalid worker/clock/lease');
    const eligible=this.rows.filter(r=>(r.status==='pending' || (r.status==='leased' && r.claimExpiresAt<=now)) && this._priorAggregateDelivered(r))
      .sort((a,b)=>a.tenant.localeCompare(b.tenant)||a.aggregate.localeCompare(b.aggregate)||a.sequence-b.sequence||a.id.localeCompare(b.id));
    const row=eligible[0]; if(!row) return null;
    row.status='leased'; row.claimEpoch+=1; row.claimToken=`claim-${++this.claimCounter}`; row.claimedBy=worker; row.claimExpiresAt=now+ttl; row.attempts++;
    return {eventId:row.id,tenant:row.tenant,objective:row.objective,aggregate:row.aggregate,worker,claimEpoch:row.claimEpoch,claimToken:row.claimToken,claimExpiresAt:row.claimExpiresAt,actionKey:row.actionKey,requestDigest:row.requestDigest};
  }
  persistUnknown(claim,now) {
    const row=this.row(claim.eventId); this._requireClaim(row,claim,now);
    if(row.remoteOutcome==='committed') throw fail('ALREADY_RECONCILED','remote result already read back');
    if(row.remoteOutcome==='rejected') throw fail('REMOTE_REJECTED','sink definitively rejected operation');
    row.remoteOutcome='unknown';
  }
  sinkCommit(claim,{now,permissionRevision=1,objectiveEpoch=1,permitted=true}={}) {
    const row=this.row(claim.eventId); this._requireClaim(row,claim,now);
    if(row.remoteOutcome!=='unknown') throw fail('UNCERTAINTY_NOT_PERSISTED','unknown outcome boundary must commit before remote call');
    const policy=this.actionPolicy.get(row.tenant);
    if(!policy || !policy.permitted || !permitted || policy.revision!==permissionRevision) throw fail('SINK_PERMISSION_STALE','sink rejected current tenant permission');
    if(this.fence(row.tenant,row.objective)!==objectiveEpoch) throw fail('SINK_OBJECTIVE_FENCE_STALE','sink rejected stale objective authority');
    const key=operationKey(row.tenant,row.actionKey);
    const existing=this.remoteOperations.get(key);
    if(existing) {
      if(existing.requestDigest!==row.requestDigest) throw fail('REMOTE_IDEMPOTENCY_CONFLICT','same key reused with another request digest');
      return {operationId:existing.operationId,replayed:true,effectCount:existing.effectCount};
    }
    const remote={tenant:row.tenant,actionKey:row.actionKey,requestDigest:row.requestDigest,operationId:`remote-${digest({tenant:row.tenant,actionKey:row.actionKey,requestDigest:row.requestDigest}).slice(0,24)}`,effectCount:1,committedAt:now};
    this.remoteOperations.set(key,remote); this.remoteEffects.push({...remote});
    // Deliberately do not mark the local row committed. The executor may lose
    // the acknowledgement; only a separate read-authorized reconciliation does.
    return {operationId:remote.operationId,replayed:false,effectCount:1};
  }
  issueReadGrant({tenant='tenant-A',objective='objective-1',principal='auditor-A',actionKey='action-1',now=100,ttl=20}={}) {
    const policy=this.readPolicy.get(JSON.stringify([tenant,principal]));
    if(!policy || !policy.allowed) throw fail('READ_PERMISSION_DENIED','principal lacks current read authority');
    const row=this.rows.find(r=>r.tenant===tenant && r.objective===objective && r.actionKey===actionKey);
    if(!row) throw fail('READ_TARGET_MISSING','operation does not exist in requested scope');
    if(!Number.isSafeInteger(now)||!Number.isSafeInteger(ttl)||ttl<=0) throw fail('READ_GRANT_INVALID','read grant interval invalid');
    return {tenant,objective,principal,actionKey,revision:policy.revision,issuedAt:now,expiresAt:now+ttl};
  }
  revokeReader(tenant,principal='auditor-A') {
    const key=JSON.stringify([tenant,principal]); const p=this.readPolicy.get(key);
    if(!p) throw fail('READ_PERMISSION_MISSING','reader policy missing');
    p.revision++; p.allowed=false;
  }
  revokeAction(tenant) { const p=this.actionPolicy.get(tenant); if(!p) throw fail('TENANT_POLICY_MISSING','tenant policy missing'); p.revision++; p.permitted=false; }
  bumpFence(tenant='tenant-A',objective='objective-1') { const key=scope(tenant,objective); this.objectiveFences.set(key,(this.objectiveFences.get(key)||0)+1); }
  reconcileRemote(grant,now) {
    if(!grant) throw fail('READ_GRANT_UNKNOWN','read grant missing');
    if(!Number.isSafeInteger(now)||now<grant.issuedAt||now>=grant.expiresAt) throw fail('READ_GRANT_EXPIRED','read grant not currently valid');
    const policy=this.readPolicy.get(JSON.stringify([grant.tenant,grant.principal]));
    if(!policy || !policy.allowed || policy.revision!==grant.revision) throw fail('READ_PERMISSION_REVOKED','read permission revoked or changed');
    const row=this.rows.find(r=>r.tenant===grant.tenant&&r.objective===grant.objective&&r.actionKey===grant.actionKey);
    if(!row) throw fail('READ_SCOPE_MISMATCH','grant scope does not match operation');
    const remote=this.remoteOperations.get(operationKey(grant.tenant,grant.actionKey));
    if(!remote) return null;
    if(remote.requestDigest!==row.requestDigest) throw fail('REMOTE_IDEMPOTENCY_CONFLICT','remote request digest differs');
    row.remoteOutcome='committed';
    row.readback={tenant:remote.tenant,objective:grant.objective,actionKey:remote.actionKey,requestDigest:remote.requestDigest,operationId:remote.operationId,effectCount:remote.effectCount,verifiedAt:now};
    // Minimal read-only receipt: no worker identity or action payload is returned.
    return {tenant:remote.tenant,objective:grant.objective,actionKey:remote.actionKey,requestDigest:remote.requestDigest,operationId:remote.operationId,effectCount:remote.effectCount,verifiedAt:now};
  }
  finalize(claim,now,readback) {
    const row=this.row(claim.eventId); this._requireClaim(row,claim,now);
    if(row.remoteOutcome!=='committed' || !row.readback) throw fail('REMOTE_OUTCOME_UNKNOWN','cannot complete without independently reconciled sink result');
    if(!readback || readback.operationId!==row.readback.operationId || readback.requestDigest!==row.requestDigest || readback.effectCount!==1) throw fail('POSTCONDITION_UNPROVEN','readback does not match requested operation');
    row.status='delivered'; row.claimedBy=null; row.claimToken=null; row.claimExpiresAt=null;
    return {delivered:true,operationId:row.readback.operationId};
  }
  releaseBeforeRemote(claim,now) {
    const row=this.row(claim.eventId); this._requireClaim(row,claim,now);
    if(row.remoteOutcome!=='not_attempted') throw fail('REMOTE_OUTCOME_UNCERTAIN','cannot release after remote uncertainty');
    row.status='pending'; row.claimedBy=null; row.claimToken=null; row.claimExpiresAt=null;
  }
  quarantineDefinitiveReject(claim,now) {
    const row=this.row(claim.eventId); this._requireClaim(row,claim,now);
    if(row.remoteOutcome!=='unknown') throw fail('REMOTE_REJECTION_NOT_ESTABLISHED','only a definitive sink rejection may be quarantined');
    row.status='quarantined'; row.remoteOutcome='rejected'; row.claimedBy=null; row.claimToken=null; row.claimExpiresAt=null;
  }
}

const tests=[];
const test=(name,fn)=>{fn();tests.push({name,result:'pass'});};
const expect=(code,fn)=>assert.throws(fn,e=>e?.code===code,`expected ${code}`);
const base=()=>{const m=new ClaimModel([makeRow()]);m.addTenant();return m;};
const complete=(m,claim,now=101)=>{m.persistUnknown(claim,now);m.sinkCommit(claim,{now,permissionRevision:1,objectiveEpoch:1});const grant=m.issueReadGrant({now:now+1});const proof=m.reconcileRemote(grant,now+1);return m.finalize(claim,now+1,proof);};

try {
 test('claim epoch/token are separate from tenant/objective action fence',()=>{const m=base();const c=m.claim('worker-A',100);assert.equal(c.claimEpoch,1);assert.equal(m.fence('tenant-A','objective-1'),1);m.bumpFence();assert.equal(c.claimEpoch,1);assert.equal(m.fence('tenant-A','objective-1'),2);});
 test('expired queue claim cannot persist remote uncertainty',()=>{const m=base();const c=m.claim('worker-A',100,2);expect('CLAIM_STALE',()=>m.persistUnknown(c,102));assert.equal(m.row('event-1').remoteOutcome,'not_attempted');});
 test('expired queue claim cannot release or finalize replacement ownership',()=>{const m=base();const a=m.claim('worker-A',100,2);const b=m.claim('worker-B',103,20);expect('CLAIM_STALE',()=>m.releaseBeforeRemote(a,103));expect('CLAIM_STALE',()=>m.finalize(a,103,null));assert.equal(m.row('event-1').claimedBy,b.worker);assert.equal(b.claimEpoch,2);});
 test('remote request requires persisted outcome_unknown before network boundary',()=>{const m=base();const c=m.claim('worker-A',100);expect('UNCERTAINTY_NOT_PERSISTED',()=>m.sinkCommit(c,{now:101}));});
 test('claim worker rechecks current policy revision at sink',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.revokeAction('tenant-A');expect('SINK_PERMISSION_STALE',()=>m.sinkCommit(c,{now:102,permissionRevision:1}));assert.equal(m.remoteEffects.length,0);});
 test('claim worker rechecks current objective fence at sink',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.bumpFence();expect('SINK_OBJECTIVE_FENCE_STALE',()=>m.sinkCommit(c,{now:102,objectiveEpoch:1}));assert.equal(m.remoteEffects.length,0);});
 test('same objective identifier can exist in multiple tenants without fence collision',()=>{const m=new ClaimModel([makeRow(),makeRow({tenant:'tenant-B',id:'event-B',actionKey:'action-B'})]);m.addTenant('tenant-A','objective-1',{epoch:5});m.addTenant('tenant-B','objective-1',{epoch:2});assert.equal(m.fence('tenant-A','objective-1'),5);assert.equal(m.fence('tenant-B','objective-1'),2);});
 test('per-aggregate sequence prevents later event from being claimed early',()=>{const m=new ClaimModel([makeRow({id:'e1',sequence:1}),makeRow({id:'e2',sequence:2})]);m.addTenant();const c=m.claim('worker-A',100);assert.equal(c.eventId,'e1');assert.equal(m.claim('worker-B',100),null);complete(m,c,101);assert.equal(m.claim('worker-B',103).eventId,'e2');});
 test('independent aggregates can be claimed by separate workers',()=>{const m=new ClaimModel([makeRow({id:'a1',aggregate:'A'}),makeRow({id:'b1',aggregate:'B'})]);m.addTenant();const a=m.claim('worker-A',100);const b=m.claim('worker-B',100);assert.notEqual(a.eventId,b.eventId);});
 test('quarantined aggregate predecessor blocks later events',()=>{const m=new ClaimModel([makeRow({id:'e1',sequence:1}),makeRow({id:'e2',sequence:2})]);m.addTenant();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.quarantineDefinitiveReject(c,101);assert.equal(m.claim('worker-B',102),null);});
 test('lost sink acknowledgement can be reconciled by replacement worker using same key',()=>{const m=base();const a=m.claim('worker-A',100,2);m.persistUnknown(a,101);const remote=m.sinkCommit(a,{now:101});const b=m.claim('worker-B',103,20);const grant=m.issueReadGrant({now:103});const proof=m.reconcileRemote(grant,104);assert.equal(proof.operationId,remote.operationId);assert.equal(m.remoteEffects.length,1);assert.equal(m.finalize(b,104,proof).delivered,true);});
 test('read-only reconciliation remains possible after action permission revocation',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});m.revokeAction('tenant-A');const grant=m.issueReadGrant({now:102});const proof=m.reconcileRemote(grant,103);assert.ok(proof);assert.equal(m.row('event-1').remoteOutcome,'committed');});
 test('read-grant expiry blocks remote result disclosure',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});const grant=m.issueReadGrant({now:102,ttl:1});expect('READ_GRANT_EXPIRED',()=>m.reconcileRemote(grant,103));});
 test('reader revocation invalidates extant reconciliation grant',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});const grant=m.issueReadGrant({now:102});m.revokeReader('tenant-A');expect('READ_PERMISSION_REVOKED',()=>m.reconcileRemote(grant,103));});
 test('read grant is scoped to tenant, objective and operation key',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});const grant=m.issueReadGrant({now:102});m.readPolicy.set(JSON.stringify(['tenant-B','auditor-A']),{revision:1,allowed:true});const changed={...grant,tenant:'tenant-B'};expect('READ_SCOPE_MISMATCH',()=>m.reconcileRemote(changed,103));const changedKey={...grant,actionKey:'different'};expect('READ_SCOPE_MISMATCH',()=>m.reconcileRemote(changedKey,103));});
 test('remote same-key retries return one operation identity and one effect',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);const first=m.sinkCommit(c,{now:101});const second=m.sinkCommit(c,{now:102});assert.equal(second.replayed,true);assert.equal(first.operationId,second.operationId);assert.equal(m.remoteEffects.length,1);});
 test('remote idempotency conflicts on same key with different digest',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});m.row('event-1').requestDigest=digest({tampered:true});expect('REMOTE_IDEMPOTENCY_CONFLICT',()=>m.sinkCommit(c,{now:102}));assert.equal(m.remoteEffects.length,1);});
 test('readback mismatch cannot finalize claimed event',()=>{const m=base();const c=m.claim('worker-A',100);m.persistUnknown(c,101);m.sinkCommit(c,{now:101});const grant=m.issueReadGrant({now:102});const proof=m.reconcileRemote(grant,103);expect('POSTCONDITION_UNPROVEN',()=>m.finalize(c,103,{...proof,requestDigest:'wrong'}));assert.equal(m.row('event-1').status,'leased');});
 test('remote commit by expired worker is impossible; replacement must write or reconcile',()=>{const m=base();const a=m.claim('worker-A',100,2);m.persistUnknown(a,101);expect('CLAIM_STALE',()=>m.sinkCommit(a,{now:103}));const b=m.claim('worker-B',103,20);const remote=m.sinkCommit(b,{now:104});const grant=m.issueReadGrant({now:104});const proof=m.reconcileRemote(grant,105);assert.equal(proof.operationId,remote.operationId);assert.equal(m.finalize(b,105,proof).delivered,true);});
 test('objective fence blocks new sink mutation while separate auditor can reconcile old result',()=>{const m=base();const a=m.claim('worker-A',100,2);m.persistUnknown(a,101);m.sinkCommit(a,{now:101});const b=m.claim('worker-B',103,20);m.bumpFence();expect('SINK_OBJECTIVE_FENCE_STALE',()=>m.sinkCommit(b,{now:104,objectiveEpoch:1}));const grant=m.issueReadGrant({now:104});assert.ok(m.reconcileRemote(grant,105));});
 test('tenant-scoped outbox claim namespaces stay separate',()=>{const m=new ClaimModel([makeRow({tenant:'tenant-A',id:'event-A',actionKey:'key-A'}),makeRow({tenant:'tenant-B',id:'event-B',actionKey:'key-B'})]);m.addTenant('tenant-A');m.addTenant('tenant-B');const a=m.claim('worker-A',100);const b=m.claim('worker-B',100);assert.notEqual(a.tenant,b.tenant);});

 // All 7! orderings of claim -> uncertainty -> remote commit -> expiry ->
 // replacement claim -> independent reconciliation -> finalize-active-worker.
 const labels=['claim-A','persist-unknown-A','sink-commit','expire-A','claim-B','reconcile','finalize-active'];
 const metrics={schedules:0,remoteEffects:0,replayedSinkWrites:0,staleClaimsRejected:0,readGrantFailures:0,duplicateEffects:0,invariantViolations:[]};
 const permutations=arr=>arr.length===0?[[]]:arr.flatMap((v,i)=>permutations([...arr.slice(0,i),...arr.slice(i+1)]).map(rest=>[v,...rest]));
 for(const order of permutations(labels)) {
   const m=base();let a=null,b=null,proof=null,active=null;
   for(const op of order) {
     try {
       if(op==='claim-A'&&!a) a=m.claim('worker-A',100,2);
       else if(op==='persist-unknown-A'&&a) m.persistUnknown(a,101);
       else if(op==='sink-commit'&&(b||a)) { const c=b||a; const sinkNow=b?104:101; const old=m.remoteOperations.size; m.sinkCommit(c,{now:sinkNow}); if(old) metrics.replayedSinkWrites++; }
       else if(op==='expire-A') { if(a) m.row(a.eventId).claimExpiresAt=103; }
       else if(op==='claim-B'&&!b) b=m.claim('worker-B',103,20);
       else if(op==='reconcile') { const grant=m.issueReadGrant({now:103,ttl:50}); proof=m.reconcileRemote(grant,104); }
       else if(op==='finalize-active') { active=b||a; if(active&&proof) { try{m.finalize(active,104,proof);} catch(e) { if(e.code==='CLAIM_STALE')metrics.staleClaimsRejected++; else if(e.code==='REMOTE_OUTCOME_UNKNOWN'){} else throw e; } } }
     } catch(e) {
       if(e.code==='CLAIM_STALE') metrics.staleClaimsRejected++;
       else if(e.code==='READ_TARGET_MISSING'||e.code==='REMOTE_OUTCOME_UNKNOWN'||e.code==='UNCERTAINTY_NOT_PERSISTED') metrics.readGrantFailures++;
       else if(!['SINK_PERMISSION_STALE','SINK_OBJECTIVE_FENCE_STALE','REMOTE_IDEMPOTENCY_CONFLICT'].includes(e.code)) metrics.invariantViolations.push({order,op,code:e.code??null,message:e.message});
     }
   }
   metrics.schedules++;
   metrics.remoteEffects += m.remoteEffects.length;
   if(m.remoteEffects.length>1) metrics.duplicateEffects++;
   if(m.remoteEffects.length>1 || m.remoteOperations.size>1) metrics.invariantViolations.push({order,code:'DUPLICATE_REMOTE_OPERATION'});
   const row=m.row('event-1');
   if(row.status==='delivered' && (!row.readback || !m.remoteOperations.has(operationKey('tenant-A','action-1')))) metrics.invariantViolations.push({order,code:'DELIVERED_WITHOUT_READBACK'});
   if(row.status==='delivered' && m.remoteEffects.length!==1) metrics.invariantViolations.push({order,code:'DELIVERED_WITHOUT_SINGLE_EFFECT'});
 }
 assert.equal(metrics.schedules,5040);
 assert.equal(metrics.duplicateEffects,0);
 assert.equal(metrics.invariantViolations.length,0);
 const report={schema:'sfeb-mon004-postgres-claim-model-report-v1',status:'passed',deterministic_cases:tests.length,cases:tests,bounded_schedule_exploration:metrics,limits:['Pure in-memory sequential reference model; not PostgreSQL execution or a concurrent memory-model proof.','The model assumes an atomic idempotent remote sink and deterministic clocks; PostgreSQL MVCC, network partitions and real sink semantics are not qualified.','5,040 permutations test lifecycle-operation orderings, not probabilities or production reliability.','The SQL reference contract still requires execution against a pinned PostgreSQL version and multi-process stress tests.']};
 console.log(JSON.stringify(report,null,2));
} catch(e) {
 console.error(JSON.stringify({status:'failed',code:e.code??null,message:e.message,stack:e.stack},null,2));
 process.exitCode=1;
}
