#!/usr/bin/env node
// SFEB MON-003 SQLite persistence + transactional outbox preflight v1.
// Node.js v22.16.0 / node:sqlite. Two separate SQLite databases model the
// local ledger and remote sink. This is NOT distributed atomicity or a claim
// about arbitrary HTTP services, brokers, PostgreSQL, or multi-host execution.
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { performance } from 'node:perf_hooks';
import { createHash, randomUUID } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const NOW = 1_800_000_000;
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const hashText = value => createHash('sha256').update(value, 'utf8').digest('hex');
const fail = (code, message) => { const e = new Error(message); e.code = code; throw e; };

function openDb(path) {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=40;');
  return db;
}
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const value = fn(); db.exec('COMMIT'); return value; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}
function initLedger(db) {
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=FULL;
    CREATE TABLE tenant_policy(tenant_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, permitted INTEGER NOT NULL CHECK(permitted IN(0,1)));
    CREATE TABLE objectives(tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, version INTEGER NOT NULL, PRIMARY KEY(tenant_id,objective_id));
    CREATE TABLE fences(tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, epoch INTEGER NOT NULL, worker_id TEXT NOT NULL, expires_at INTEGER NOT NULL, PRIMARY KEY(tenant_id,objective_id));
    CREATE TABLE source_receipts(receipt_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, source TEXT NOT NULL, event_id TEXT NOT NULL, digest TEXT NOT NULL, resource_id TEXT NOT NULL, action_type TEXT NOT NULL, expires_at INTEGER NOT NULL, issuer_id TEXT NOT NULL, UNIQUE(tenant_id,source,event_id));
    CREATE TABLE receipt_revocations(receipt_id TEXT PRIMARY KEY REFERENCES source_receipts(receipt_id), revoked_at INTEGER NOT NULL, reason TEXT NOT NULL, authority_id TEXT NOT NULL);
    CREATE TABLE resources(tenant_id TEXT NOT NULL, resource_id TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN('available','pending_delivery','reserved')), version INTEGER NOT NULL, PRIMARY KEY(tenant_id,resource_id));
    CREATE TABLE operations(tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, action_key TEXT NOT NULL, request_digest TEXT NOT NULL, operation_id TEXT NOT NULL UNIQUE, objective_version INTEGER NOT NULL, receipt_id TEXT NOT NULL, fencing_epoch INTEGER NOT NULL, permission_revision INTEGER NOT NULL, status TEXT NOT NULL CHECK(status IN('prepared','outcome_unknown','remote_committed','rejected')), created_at INTEGER NOT NULL, PRIMARY KEY(tenant_id,action_key), FOREIGN KEY(tenant_id,objective_id) REFERENCES objectives(tenant_id,objective_id), FOREIGN KEY(receipt_id) REFERENCES source_receipts(receipt_id));
    CREATE TABLE outbox(event_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, action_key TEXT NOT NULL, request_digest TEXT NOT NULL, payload_json TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN('pending','delivered')), attempts INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, delivered_at INTEGER, UNIQUE(tenant_id,action_key), FOREIGN KEY(tenant_id,action_key) REFERENCES operations(tenant_id,action_key));
    CREATE TABLE evidence_events(seq INTEGER PRIMARY KEY, tenant_id TEXT NOT NULL, subject_id TEXT NOT NULL, event_type TEXT NOT NULL, occurred_at INTEGER NOT NULL, payload_json TEXT NOT NULL, previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL UNIQUE);
    CREATE TABLE read_permissions(tenant_id TEXT NOT NULL, principal_id TEXT NOT NULL, revision INTEGER NOT NULL, allowed INTEGER NOT NULL CHECK(allowed IN(0,1)), PRIMARY KEY(tenant_id,principal_id));
    CREATE TABLE read_grants(grant_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, principal_id TEXT NOT NULL, action_key TEXT NOT NULL, revision INTEGER NOT NULL, issued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL CHECK(expires_at>issued_at), FOREIGN KEY(tenant_id,action_key) REFERENCES operations(tenant_id,action_key));
    CREATE TRIGGER evidence_event_no_update BEFORE UPDATE ON evidence_events BEGIN SELECT RAISE(ABORT,'evidence journal is append-only'); END;
    CREATE TRIGGER evidence_event_no_delete BEFORE DELETE ON evidence_events BEGIN SELECT RAISE(ABORT,'evidence journal is append-only'); END;
    CREATE TRIGGER source_receipt_immutable BEFORE UPDATE ON source_receipts BEGIN SELECT RAISE(ABORT,'source receipt evidence is immutable'); END;
    CREATE TRIGGER source_receipt_no_delete BEFORE DELETE ON source_receipts BEGIN SELECT RAISE(ABORT,'source receipt evidence cannot be deleted'); END;
    CREATE TRIGGER receipt_revocation_no_update BEFORE UPDATE ON receipt_revocations BEGIN SELECT RAISE(ABORT,'receipt revocation evidence is append-only'); END;
    CREATE TRIGGER receipt_revocation_no_delete BEFORE DELETE ON receipt_revocations BEGIN SELECT RAISE(ABORT,'receipt revocation evidence is append-only'); END;
    CREATE TRIGGER outbox_no_regress BEFORE UPDATE OF status ON outbox WHEN OLD.status='delivered' AND NEW.status<>'delivered' BEGIN SELECT RAISE(ABORT,'outbox terminal state'); END;
    CREATE TRIGGER operation_no_regress BEFORE UPDATE OF status ON operations WHEN (OLD.status='remote_committed' AND NEW.status<>'remote_committed') OR (OLD.status='outcome_unknown' AND NEW.status='prepared') OR (OLD.status='rejected' AND NEW.status<>'rejected') BEGIN SELECT RAISE(ABORT,'operation terminal state'); END;
    CREATE TRIGGER operation_identity_immutable BEFORE UPDATE OF tenant_id,objective_id,action_key,request_digest,operation_id,objective_version,receipt_id,fencing_epoch,permission_revision,created_at ON operations BEGIN SELECT RAISE(ABORT,'operation identity immutable'); END;
    CREATE TRIGGER outbox_payload_immutable BEFORE UPDATE OF event_id,tenant_id,objective_id,action_key,request_digest,payload_json,created_at ON outbox BEGIN SELECT RAISE(ABORT,'outbox payload immutable'); END;
  `);
}
function initRemote(db) {
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=FULL;
    CREATE TABLE remote_policy(tenant_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, permitted INTEGER NOT NULL CHECK(permitted IN(0,1)));
    CREATE TABLE remote_fences(tenant_id TEXT NOT NULL, objective_id TEXT NOT NULL, epoch INTEGER NOT NULL, PRIMARY KEY(tenant_id,objective_id));
    CREATE TABLE remote_resources(tenant_id TEXT NOT NULL, resource_id TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN('available','reserved')), PRIMARY KEY(tenant_id,resource_id));
    CREATE TABLE remote_operations(tenant_id TEXT NOT NULL, action_key TEXT NOT NULL, request_digest TEXT NOT NULL, operation_id TEXT NOT NULL UNIQUE, objective_id TEXT NOT NULL, resource_id TEXT NOT NULL, effect_count INTEGER NOT NULL CHECK(effect_count=1), committed_at INTEGER NOT NULL, PRIMARY KEY(tenant_id,action_key));
  `);
}
function fixture() {
  const dir=mkdtempSync(join(tmpdir(),'sfeb-mon003-sqlite-'));
  const ledgerPath=join(dir,'ledger.db'), remotePath=join(dir,'remote.db');
  const ledger=openDb(ledgerPath), remote=openDb(remotePath), verifier=openDb(remotePath);
  initLedger(ledger); initRemote(remote);
  seed(ledger);
  tx(remote,()=>{
    remote.prepare('INSERT INTO remote_policy VALUES(?,1,1)').run('tenant-A');
    remote.prepare('INSERT INTO remote_fences VALUES(?,?,1)').run('tenant-A','objective-1');
    remote.prepare("INSERT INTO remote_resources VALUES(?,?,'available')").run('tenant-A','slot-17');
  });
  return {dir,ledgerPath,remotePath,ledger,remote,verifier,close(){ for (const d of [ledger,remote,verifier]) { try{d.close();}catch{}} rmSync(dir,{recursive:true,force:true}); }};
}
function seed(db,{tenant='tenant-A',objective='objective-1',resource='slot-17',receipt='receipt-1',eventId=`event-${receipt}`,expiresAt=NOW+500}={}) {
  tx(db,()=>{
    db.prepare('INSERT OR REPLACE INTO tenant_policy VALUES(?,1,1)').run(tenant);
    db.prepare('INSERT OR REPLACE INTO objectives VALUES(?,?,1)').run(tenant,objective);
    db.prepare('INSERT OR REPLACE INTO resources VALUES(?,?,\'available\',0)').run(tenant,resource);
    db.prepare('INSERT INTO source_receipts VALUES(?,?,?,?,?,?,?,?,?)').run(receipt,tenant,'urn:fixture:capacity-service',eventId,hash({tenant,receipt}),resource,'reserve',expiresAt,'capacity-prod');
    db.prepare('INSERT OR REPLACE INTO fences VALUES(?,?,1,?,?)').run(tenant,objective,'worker-A',NOW+200);
    db.prepare('INSERT OR REPLACE INTO read_permissions VALUES(?,?,1,1)').run(tenant,'auditor-A');
  });
}
function req({tenant='tenant-A',objective='objective-1',resource='slot-17',receipt='receipt-1',actionKey='action-1',now=NOW+1,worker='worker-A',epoch=1,version=1}={}) {
  const action={type:'reserve',resourceId:resource,units:1};
  const requestDigest=hash({tenant,objective,version,receipt,action});
  return {tenant,objective,resource,receipt,actionKey,now,worker,epoch,version,action,requestDigest};
}

function appendEvidence(db, {tenant,subject,type,at,payload}) {
  const previous=db.prepare('SELECT seq,event_hash FROM evidence_events ORDER BY seq DESC LIMIT 1').get();
  const seq=previous ? previous.seq+1 : 1;
  const previousHash=previous ? previous.event_hash : '0'.repeat(64);
  const payloadJson=JSON.stringify(payload);
  const frame=JSON.stringify({seq,tenant,subject,type,at,payloadJson,previousHash});
  const eventHash=hashText(frame);
  db.prepare('INSERT INTO evidence_events VALUES(?,?,?,?,?,?,?,?)').run(seq,tenant,subject,type,at,payloadJson,previousHash,eventHash);
  return {seq,eventHash};
}
function verifyEvidenceChain(db) {
  const rows=db.prepare('SELECT * FROM evidence_events ORDER BY seq').all();
  let prior='0'.repeat(64);
  let expectedSeq=1;
  for (const row of rows) {
    if (row.seq!==expectedSeq || row.previous_hash!==prior) return {valid:false,checked:expectedSeq-1,failedSeq:row.seq};
    const frame=JSON.stringify({seq:row.seq,tenant:row.tenant_id,subject:row.subject_id,type:row.event_type,at:row.occurred_at,payloadJson:row.payload_json,previousHash:row.previous_hash});
    const expected=hashText(frame);
    if (expected!==row.event_hash) return {valid:false,checked:expectedSeq-1,failedSeq:row.seq};
    prior=row.event_hash;
    expectedSeq++;
  }
  return {valid:true,checked:rows.length,lastHash:prior};
}

function accept(db,r,failAt=null) {
  return tx(db,()=>{
    const objective=db.prepare('SELECT version FROM objectives WHERE tenant_id=? AND objective_id=?').get(r.tenant,r.objective);
    if (!objective || objective.version!==r.version) fail('OBJECTIVE_STALE','objective version is stale');
    const policy=db.prepare('SELECT revision,permitted FROM tenant_policy WHERE tenant_id=?').get(r.tenant);
    if (!policy || policy.permitted!==1) fail('ACTION_PERMISSION_DENIED','tenant action permission denied');
    const fence=db.prepare('SELECT epoch,worker_id,expires_at FROM fences WHERE tenant_id=? AND objective_id=?').get(r.tenant,r.objective);
    if (!fence || fence.epoch!==r.epoch || fence.worker_id!==r.worker || fence.expires_at<=r.now) fail('STALE_FENCE','worker does not own current unexpired fence');
    const receipt=db.prepare('SELECT s.*, EXISTS(SELECT 1 FROM receipt_revocations rr WHERE rr.receipt_id=s.receipt_id) AS is_revoked FROM source_receipts s WHERE s.receipt_id=? AND s.tenant_id=?').get(r.receipt,r.tenant);
    if (!receipt || receipt.is_revoked===1 || receipt.expires_at<=r.now) fail('RECEIPT_INELIGIBLE','source receipt absent, append-only revoked or expired');
    if (receipt.resource_id!==r.resource || receipt.action_type!==r.action.type) fail('RECEIPT_SCOPE_MISMATCH','receipt does not authorize target/action');
    const prior=db.prepare('SELECT request_digest FROM operations WHERE tenant_id=? AND action_key=?').get(r.tenant,r.actionKey);
    if (prior) {
      if (prior.request_digest!==r.requestDigest) fail('IDEMPOTENCY_CONFLICT','same operation key with changed digest');
      fail('RECONCILIATION_REQUIRED','existing operation must be reconciled, never re-executed');
    }
    const operationId='op-'+hash({tenant:r.tenant,actionKey:r.actionKey,digest:r.requestDigest}).slice(0,24);
    db.prepare("INSERT INTO operations VALUES(?,?,?,?,?,?,?,?,?,'prepared',?)").run(r.tenant,r.objective,r.actionKey,r.requestDigest,operationId,r.version,r.receipt,r.epoch,policy.revision,r.now);
    appendEvidence(db,{tenant:r.tenant,subject:operationId,type:'objective.accepted',at:r.now,payload:{actionKey:r.actionKey,requestDigest:r.requestDigest,receiptId:r.receipt,epoch:r.epoch,permissionRevision:policy.revision}});
    if (failAt==='operation') fail('INJECTED','after-operation');
    const changed=db.prepare("UPDATE resources SET state='pending_delivery',version=version+1 WHERE tenant_id=? AND resource_id=? AND state='available'").run(r.tenant,r.resource);
    if (Number(changed.changes)!==1) fail('RESOURCE_CONFLICT','resource is not available');
    appendEvidence(db,{tenant:r.tenant,subject:operationId,type:'resource.reservation_intended',at:r.now,payload:{resourceId:r.resource,actionKey:r.actionKey}});
    if (failAt==='resource') fail('INJECTED','after-resource');
    const eventId='out-'+hash({tenant:r.tenant,actionKey:r.actionKey}).slice(0,24);
    const payload={tenantId:r.tenant,objectiveId:r.objective,resourceId:r.resource,receiptId:r.receipt,actionKey:r.actionKey,requestDigest:r.requestDigest,operationId,epoch:r.epoch,permissionRevision:policy.revision};
    db.prepare("INSERT INTO outbox VALUES(?,?,?,?,?,?,'pending',0,?,NULL)").run(eventId,r.tenant,r.objective,r.actionKey,r.requestDigest,JSON.stringify(payload),r.now);
    appendEvidence(db,{tenant:r.tenant,subject:operationId,type:'outbox.enqueued',at:r.now,payload:{eventId,actionKey:r.actionKey,requestDigest:r.requestDigest}});
    if (failAt==='outbox') fail('INJECTED','after-outbox');
    return {operationId,eventId};
  });
}
function issueReadGrant(db,{tenant='tenant-A',objective='objective-1',principal='auditor-A',actionKey='action-1',now=NOW+2,ttl=20}={}) {
  return tx(db,()=>{
    const permission=db.prepare('SELECT revision,allowed FROM read_permissions WHERE tenant_id=? AND principal_id=?').get(tenant,principal);
    if (!permission || permission.allowed!==1) fail('READ_PERMISSION_DENIED','reader is not authorized');
    const exists=db.prepare('SELECT 1 FROM operations WHERE tenant_id=? AND objective_id=? AND action_key=?').get(tenant,objective,actionKey);
    if (!exists) fail('READ_TARGET_MISSING','operation not found in requested scope');
    if (!Number.isSafeInteger(now)||!Number.isSafeInteger(ttl)||ttl<=0) fail('READ_GRANT_INVALID','invalid read grant interval');
    const grantId='read-'+randomUUID();
    db.prepare('INSERT INTO read_grants VALUES(?,?,?,?,?,?,?,?)').run(grantId,tenant,objective,principal,actionKey,permission.revision,now,now+ttl);
    appendEvidence(db,{tenant,subject:actionKey,type:'reconciliation.read_grant_issued',at:now,payload:{grantId,principal,permissionRevision:permission.revision,expiresAt:now+ttl}});
    return {grantId,tenant,objective,principal,actionKey,revision:permission.revision,issuedAt:now,expiresAt:now+ttl};
  });
}
function reconcile(db,{grantId,authenticatedPrincipal,now}) {
  const grant=db.prepare('SELECT * FROM read_grants WHERE grant_id=?').get(grantId);
  if (!grant) fail('READ_GRANT_UNKNOWN','read grant missing');
  if (grant.principal_id!==authenticatedPrincipal) fail('READ_PRINCIPAL_MISMATCH','authenticated principal differs from read grant');
  if (!Number.isSafeInteger(now)||now<grant.issued_at||now>=grant.expires_at) fail('READ_GRANT_EXPIRED','read grant expired or not yet valid');
  const permission=db.prepare('SELECT revision,allowed FROM read_permissions WHERE tenant_id=? AND principal_id=?').get(grant.tenant_id,grant.principal_id);
  if (!permission || permission.allowed!==1 || permission.revision!==grant.revision) fail('READ_PERMISSION_REVOKED','reader grant invalidated by permission change');
  const op=db.prepare('SELECT * FROM operations WHERE tenant_id=? AND objective_id=? AND action_key=?').get(grant.tenant_id,grant.objective_id,grant.action_key);
  if (!op) return null;
  // This API returns status/digest/operation identity only. It is not an action grant.
  return {tenantId:grant.tenant_id,objectiveId:grant.objective_id,actionKey:grant.action_key,operationId:op.operation_id,requestDigest:op.request_digest,status:op.status,createdAt:op.created_at};
}
function revokeAction(db,tenant,at=NOW+5,authority='policy-admin-A') { tx(db,()=>{const old=db.prepare('SELECT revision FROM tenant_policy WHERE tenant_id=?').get(tenant);if(!old)fail('TENANT_POLICY_MISSING','tenant policy not found');db.prepare('UPDATE tenant_policy SET revision=revision+1,permitted=0 WHERE tenant_id=?').run(tenant);appendEvidence(db,{tenant,subject:tenant,type:'tenant.action_permission_revoked',at,payload:{priorRevision:old.revision,newRevision:old.revision+1,authority}});}); }
function revokeReader(db,tenant,principal,at=NOW+5,authority='read-policy-admin-A') { tx(db,()=>{const old=db.prepare('SELECT revision FROM read_permissions WHERE tenant_id=? AND principal_id=?').get(tenant,principal);if(!old)fail('READ_PERMISSION_MISSING','reader permission not found');db.prepare('UPDATE read_permissions SET revision=revision+1,allowed=0 WHERE tenant_id=? AND principal_id=?').run(tenant,principal);appendEvidence(db,{tenant,subject:principal,type:'reconciliation.reader_permission_revoked',at,payload:{priorRevision:old.revision,newRevision:old.revision+1,authority}});}); }
function revokeReceipt(db,receiptId,{at=NOW+5,reason='issuer revoked',authority='trust-admin-A'}={}) { return tx(db,()=>{const receipt=db.prepare('SELECT tenant_id FROM source_receipts WHERE receipt_id=?').get(receiptId);if(!receipt)fail('RECEIPT_UNKNOWN','receipt not found');db.prepare('INSERT INTO receipt_revocations VALUES(?,?,?,?)').run(receiptId,at,reason,authority);appendEvidence(db,{tenant:receipt.tenant_id,subject:receiptId,type:'source.receipt_revoked',at,payload:{reason,authority}});}); }

function dispatchOne(ledger,remote,verifier,now,{loseAck=false,precommitFailure=false,corruptReadback=false}={}) {
  const event=ledger.prepare("SELECT * FROM outbox WHERE status='pending' ORDER BY rowid LIMIT 1").get();
  if (!event) return {delivered:false};
  const p=JSON.parse(event.payload_json);
  tx(ledger,()=>{
    const n=ledger.prepare("UPDATE outbox SET attempts=attempts+1 WHERE event_id=? AND status='pending'").run(event.event_id);
    if (Number(n.changes)!==1) fail('OUTBOX_CLAIM_LOST','outbox no longer pending');
    ledger.prepare("UPDATE operations SET status='outcome_unknown' WHERE tenant_id=? AND action_key=? AND status IN('prepared','outcome_unknown')").run(event.tenant_id,event.action_key);
    appendEvidence(ledger,{tenant:event.tenant_id,subject:event.action_key,type:'remote.dispatch_attempted',at:now,payload:{eventId:event.event_id,attempt:Number(ledger.prepare('SELECT attempts FROM outbox WHERE event_id=?').get(event.event_id).attempts),requestDigest:event.request_digest}});
  });
  const remoteResult=tx(remote,()=>{
    const prior=remote.prepare('SELECT * FROM remote_operations WHERE tenant_id=? AND action_key=?').get(event.tenant_id,event.action_key);
    if (prior) {
      if (prior.request_digest!==event.request_digest) fail('REMOTE_IDEMPOTENCY_CONFLICT','remote key digest mismatch');
      return {remoteOperationId:prior.operation_id,replayed:true};
    }
    const policy=remote.prepare('SELECT revision,permitted FROM remote_policy WHERE tenant_id=?').get(p.tenantId);
    if (!policy||policy.permitted!==1||policy.revision!==p.permissionRevision) fail('REMOTE_PERMISSION_STALE','sink permission revision changed');
    const fence=remote.prepare('SELECT epoch FROM remote_fences WHERE tenant_id=? AND objective_id=?').get(p.tenantId,p.objectiveId);
    if (!fence||fence.epoch!==p.epoch) fail('REMOTE_FENCE_STALE','sink fence changed');
    const resource=remote.prepare('SELECT state FROM remote_resources WHERE tenant_id=? AND resource_id=?').get(p.tenantId,p.resourceId);
    if (resource&&resource.state!=='available') fail('REMOTE_RESOURCE_CONFLICT','remote resource already unavailable');
    if (precommitFailure) fail('REMOTE_PRECOMMIT_FAILURE','injected remote failure before transaction commit');
    const operationId='remote-'+hash({tenant:event.tenant_id,key:event.action_key,digest:event.request_digest}).slice(0,24);
    if (resource) remote.prepare("UPDATE remote_resources SET state='reserved' WHERE tenant_id=? AND resource_id=? AND state='available'").run(p.tenantId,p.resourceId);
    else remote.prepare("INSERT INTO remote_resources VALUES(?,?,'reserved')").run(p.tenantId,p.resourceId);
    remote.prepare('INSERT INTO remote_operations VALUES(?,?,?,?,?,?,1,?)').run(event.tenant_id,event.action_key,event.request_digest,operationId,event.objective_id,p.resourceId,now);
    return {remoteOperationId:operationId,replayed:false};
  });
  if (corruptReadback) remote.prepare("UPDATE remote_resources SET state='available' WHERE tenant_id=? AND resource_id=?").run(p.tenantId,p.resourceId);
  if (loseAck) fail('REMOTE_ACK_LOST','sink committed but acknowledgement was lost');
  // A separate SQLite connection reads the state of record; the executor's
  // return value is not used as the proof of postcondition.
  const observed=verifier.prepare('SELECT request_digest,operation_id,resource_id FROM remote_operations WHERE tenant_id=? AND action_key=?').get(event.tenant_id,event.action_key);
  const state=verifier.prepare('SELECT state FROM remote_resources WHERE tenant_id=? AND resource_id=?').get(p.tenantId,p.resourceId);
  if (!observed||observed.request_digest!==event.request_digest||!state||state.state!=='reserved') fail('POSTCONDITION_MISMATCH','independent readback does not prove requested effect');
  tx(ledger,()=>{
    ledger.prepare("UPDATE outbox SET status='delivered',delivered_at=? WHERE event_id=? AND status='pending'").run(now,event.event_id);
    ledger.prepare("UPDATE operations SET status='remote_committed' WHERE tenant_id=? AND action_key=? AND status='outcome_unknown'").run(event.tenant_id,event.action_key);
    ledger.prepare("UPDATE resources SET state='reserved' WHERE tenant_id=? AND resource_id=? AND state='pending_delivery'").run(event.tenant_id,p.resourceId);
    appendEvidence(ledger,{tenant:event.tenant_id,subject:event.action_key,type:'remote.postcondition_verified',at:now,payload:{remoteOperationId:remoteResult.remoteOperationId,requestDigest:event.request_digest,resourceId:p.resourceId}});
    appendEvidence(ledger,{tenant:event.tenant_id,subject:event.action_key,type:'operation.remote_committed',at:now,payload:{eventId:event.event_id,operationId:ledger.prepare('SELECT operation_id FROM operations WHERE tenant_id=? AND action_key=?').get(event.tenant_id,event.action_key).operation_id}});
  });
  return {delivered:true,postconditionVerified:true,...remoteResult};
}

const tests=[];
function test(name,fn){fn();tests.push({name,result:'pass'});}
function expect(code,fn){assert.throws(fn,e=>e&&e.code===code,`expected ${code}`);}
function withFixture(fn){const f=fixture();try{return fn(f);}finally{f.close();}}

try {
  test('local operation, resource intent and outbox commit atomically',()=>withFixture(f=>{accept(f.ledger,req());assert.equal(f.ledger.prepare('SELECT status FROM operations').get().status,'prepared');assert.equal(f.ledger.prepare('SELECT state FROM resources').get().state,'pending_delivery');assert.equal(f.ledger.prepare('SELECT status FROM outbox').get().status,'pending');}));
  for (const point of ['operation','resource','outbox']) test(`injected ${point} failure rolls all local writes back`,()=>withFixture(f=>{expect('INJECTED',()=>accept(f.ledger,req(),point));assert.equal(f.ledger.prepare('SELECT count(*) n FROM operations').get().n,0);assert.equal(f.ledger.prepare('SELECT state FROM resources').get().state,'available');assert.equal(f.ledger.prepare('SELECT count(*) n FROM outbox').get().n,0);assert.equal(f.ledger.prepare('SELECT count(*) n FROM evidence_events').get().n,0);}));
  test('stale owner fence blocks local mutation',()=>withFixture(f=>{expect('STALE_FENCE',()=>accept(f.ledger,req({epoch:0})));assert.equal(f.ledger.prepare('SELECT count(*) n FROM operations').get().n,0);}));
  test('same objective identifier is isolated by tenant',()=>withFixture(f=>{seed(f.ledger,{tenant:'tenant-B',resource:'slot-B',receipt:'receipt-B'});accept(f.ledger,req());accept(f.ledger,req({tenant:'tenant-B',resource:'slot-B',receipt:'receipt-B',actionKey:'action-B'}));assert.equal(f.ledger.prepare('SELECT count(*) n FROM operations').get().n,2);}));
  test('current action permission revocation blocks acceptance',()=>withFixture(f=>{revokeAction(f.ledger,'tenant-A');expect('ACTION_PERMISSION_DENIED',()=>accept(f.ledger,req()));}));
  test('expired source receipt blocks acceptance',()=>withFixture(f=>{seed(f.ledger,{resource:'slot-expired',receipt:'receipt-expired',expiresAt:NOW});expect('RECEIPT_INELIGIBLE',()=>accept(f.ledger,req({resource:'slot-expired',receipt:'receipt-expired'})));}));
  test('append-only receipt revocation evidence blocks acceptance',()=>withFixture(f=>{revokeReceipt(f.ledger,'receipt-1',{at:NOW+1,reason:'issuer compromise',authority:'trust-admin-A'});expect('RECEIPT_INELIGIBLE',()=>accept(f.ledger,req()));const rev=f.ledger.prepare('SELECT * FROM receipt_revocations WHERE receipt_id=?').get('receipt-1');assert.equal(rev.reason,'issuer compromise');assert.equal(rev.authority_id,'trust-admin-A');assert.throws(()=>f.ledger.prepare("UPDATE receipt_revocations SET reason='changed' WHERE receipt_id=?").run('receipt-1'));assert.throws(()=>f.ledger.prepare('DELETE FROM receipt_revocations WHERE receipt_id=?').run('receipt-1'));}));
  test('source receipt target/action substitution is rejected',()=>withFixture(f=>{expect('RECEIPT_SCOPE_MISMATCH',()=>accept(f.ledger,req({resource:'slot-attacker'})));}));
  test('same key and same digest require reconciliation rather than re-execution',()=>withFixture(f=>{accept(f.ledger,req());expect('RECONCILIATION_REQUIRED',()=>accept(f.ledger,req()));assert.equal(f.ledger.prepare('SELECT count(*) n FROM outbox').get().n,1);}));
  test('same key with a changed request digest conflicts',()=>withFixture(f=>{accept(f.ledger,req());const r=req();r.requestDigest=hash({changed:true});expect('IDEMPOTENCY_CONFLICT',()=>accept(f.ledger,r));}));
  test('resource compare-and-set prevents double allocation by distinct keys',()=>withFixture(f=>{accept(f.ledger,req());expect('RESOURCE_CONFLICT',()=>accept(f.ledger,req({actionKey:'action-2'})));assert.equal(f.ledger.prepare('SELECT count(*) n FROM operations').get().n,1);}));
  test('auditor reconciliation is separate and payload-minimized',()=>withFixture(f=>{accept(f.ledger,req());const grant=issueReadGrant(f.ledger);const receipt=reconcile(f.ledger,{grantId:grant.grantId,authenticatedPrincipal:'auditor-A',now:NOW+3});assert.equal(receipt.status,'prepared');assert.equal('resourceId' in receipt,false);assert.equal('workerId' in receipt,false);}));
  test('action revocation does not revoke independent read-only reconciliation',()=>withFixture(f=>{accept(f.ledger,req());const grant=issueReadGrant(f.ledger);revokeAction(f.ledger,'tenant-A');assert.equal(reconcile(f.ledger,{grantId:grant.grantId,authenticatedPrincipal:'auditor-A',now:NOW+3}).status,'prepared');}));
  test('reader revocation invalidates extant grants',()=>withFixture(f=>{accept(f.ledger,req());const grant=issueReadGrant(f.ledger);revokeReader(f.ledger,'tenant-A','auditor-A');expect('READ_PERMISSION_REVOKED',()=>reconcile(f.ledger,{grantId:grant.grantId,authenticatedPrincipal:'auditor-A',now:NOW+3}));}));
  test('expired reconciliation grants fail closed',()=>withFixture(f=>{accept(f.ledger,req());const grant=issueReadGrant(f.ledger,{ttl:1});expect('READ_GRANT_EXPIRED',()=>reconcile(f.ledger,{grantId:grant.grantId,authenticatedPrincipal:'auditor-A',now:NOW+3}));}));
  test('grant cannot be used by another authenticated principal',()=>withFixture(f=>{accept(f.ledger,req());const grant=issueReadGrant(f.ledger);expect('READ_PRINCIPAL_MISMATCH',()=>reconcile(f.ledger,{grantId:grant.grantId,authenticatedPrincipal:'worker-A',now:NOW+3}));}));
  test('grant cannot be minted for another tenant or objective operation',()=>withFixture(f=>{accept(f.ledger,req());f.ledger.prepare('INSERT INTO read_permissions VALUES(?,?,1,1)').run('tenant-B','auditor-A');expect('READ_TARGET_MISSING',()=>issueReadGrant(f.ledger,{tenant:'tenant-B'}));expect('READ_TARGET_MISSING',()=>issueReadGrant(f.ledger,{objective:'objective-other'}));}));
  test('remote sink rechecks current permission revision before effect',()=>withFixture(f=>{accept(f.ledger,req());f.remote.prepare('UPDATE remote_policy SET revision=revision+1,permitted=0 WHERE tenant_id=?').run('tenant-A');expect('REMOTE_PERMISSION_STALE',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3));assert.equal(f.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,0);assert.equal(f.ledger.prepare('SELECT status FROM operations').get().status,'outcome_unknown');}));
  test('remote sink checks tenant/objective fence at commit boundary',()=>withFixture(f=>{accept(f.ledger,req());f.remote.prepare('UPDATE remote_fences SET epoch=epoch+1 WHERE tenant_id=? AND objective_id=?').run('tenant-A','objective-1');expect('REMOTE_FENCE_STALE',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3));assert.equal(f.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,0);}));
  test('remote precommit failure leaves local outbox pending and remote unchanged',()=>withFixture(f=>{accept(f.ledger,req());expect('REMOTE_PRECOMMIT_FAILURE',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3,{precommitFailure:true}));assert.equal(f.ledger.prepare('SELECT status FROM outbox').get().status,'pending');assert.equal(f.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,0);}));
  test('lost remote acknowledgement retries same key and commits exactly one mock effect',()=>withFixture(f=>{accept(f.ledger,req());expect('REMOTE_ACK_LOST',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3,{loseAck:true}));assert.equal(f.ledger.prepare('SELECT status FROM operations').get().status,'outcome_unknown');assert.equal(f.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,1);const result=dispatchOne(f.ledger,f.remote,f.verifier,NOW+4);assert.equal(result.replayed,true);assert.equal(f.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,1);assert.equal(f.ledger.prepare('SELECT status FROM operations').get().status,'remote_committed');assert.equal(f.ledger.prepare('SELECT status FROM outbox').get().status,'delivered');assert.equal(f.ledger.prepare('SELECT state FROM resources').get().state,'reserved');}));
  test('independent postcondition mismatch leaves operation unknown',()=>withFixture(f=>{accept(f.ledger,req());expect('POSTCONDITION_MISMATCH',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3,{corruptReadback:true}));assert.equal(f.ledger.prepare('SELECT status FROM operations').get().status,'outcome_unknown');assert.equal(f.ledger.prepare('SELECT status FROM outbox').get().status,'pending');}));
  test('remote same-key changed-digest conflict is not marked delivered',()=>withFixture(f=>{accept(f.ledger,req());const e=f.ledger.prepare('SELECT * FROM outbox').get();f.remote.prepare('INSERT INTO remote_operations VALUES(?,?,?,?,?,?,1,?)').run(e.tenant_id,e.action_key,'different','remote-preexisting','objective-1','slot-17',NOW);expect('REMOTE_IDEMPOTENCY_CONFLICT',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3));assert.equal(f.ledger.prepare('SELECT status FROM outbox').get().status,'pending');}));
  test('file-backed ledger and sink survive close/reopen after local acceptance',()=>withFixture(f=>{accept(f.ledger,req());f.ledger.close();const d=openDb(f.ledgerPath);try{assert.equal(d.prepare('SELECT status FROM outbox').get().status,'pending');assert.equal(d.prepare('SELECT status FROM operations').get().status,'prepared');}finally{d.close();}}));
  test('lost acknowledgement survives close/reopen and reconciles by same key',()=>withFixture(f=>{accept(f.ledger,req());expect('REMOTE_ACK_LOST',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3,{loseAck:true}));f.ledger.close();f.remote.close();f.verifier.close();const l=openDb(f.ledgerPath),r=openDb(f.remotePath),v=openDb(f.remotePath);try{assert.equal(l.prepare('SELECT status FROM operations').get().status,'outcome_unknown');assert.equal(r.prepare('SELECT count(*) n FROM remote_operations').get().n,1);assert.equal(dispatchOne(l,r,v,NOW+4).replayed,true);assert.equal(l.prepare('SELECT status FROM operations').get().status,'remote_committed');}finally{l.close();r.close();v.close();}}));
  test('outbox dispatch preserves insertion order for equal timestamps',()=>withFixture(f=>{seed(f.ledger,{resource:'slot-A',receipt:'receipt-A'});seed(f.ledger,{resource:'slot-B',receipt:'receipt-B'});accept(f.ledger,req({resource:'slot-A',receipt:'receipt-A',actionKey:'ordered-A'}));accept(f.ledger,req({resource:'slot-B',receipt:'receipt-B',actionKey:'ordered-B'}));dispatchOne(f.ledger,f.remote,f.verifier,NOW+3);dispatchOne(f.ledger,f.remote,f.verifier,NOW+4);const local=f.ledger.prepare('SELECT action_key FROM outbox ORDER BY rowid').all().map(x=>x.action_key);const remote=f.remote.prepare('SELECT action_key FROM remote_operations ORDER BY rowid').all().map(x=>x.action_key);assert.deepEqual(remote,local);}));
  test('delivered outbox and remote_committed operation cannot regress',()=>withFixture(f=>{accept(f.ledger,req());dispatchOne(f.ledger,f.remote,f.verifier,NOW+3);assert.throws(()=>f.ledger.prepare("UPDATE outbox SET status='pending' WHERE status='delivered'").run());assert.throws(()=>f.ledger.prepare("UPDATE operations SET status='prepared' WHERE status='remote_committed'").run());}));
  test('operation and outbox evidence fields are immutable',()=>withFixture(f=>{accept(f.ledger,req());assert.throws(()=>f.ledger.prepare("UPDATE operations SET request_digest='tampered'").run());assert.throws(()=>f.ledger.prepare("UPDATE outbox SET payload_json='{}'").run());}));
  test('evidence journal records local causal sequence and verifies its hash chain',()=>withFixture(f=>{accept(f.ledger,req());const rows=f.ledger.prepare('SELECT event_type FROM evidence_events ORDER BY seq').all().map(x=>x.event_type);assert.deepEqual(rows,['objective.accepted','resource.reservation_intended','outbox.enqueued']);assert.equal(verifyEvidenceChain(f.ledger).valid,true);}));
  test('evidence journal rows cannot be updated or deleted',()=>withFixture(f=>{accept(f.ledger,req());assert.throws(()=>f.ledger.prepare("UPDATE evidence_events SET payload_json='{}' WHERE seq=1").run());assert.throws(()=>f.ledger.prepare('DELETE FROM evidence_events WHERE seq=1').run());}));
  test('evidence chain detects payload tampering when an administrator bypasses append-only trigger',()=>withFixture(f=>{accept(f.ledger,req());f.ledger.exec('DROP TRIGGER evidence_event_no_update');f.ledger.prepare("UPDATE evidence_events SET payload_json='{}' WHERE seq=2").run();const check=verifyEvidenceChain(f.ledger);assert.equal(check.valid,false);assert.equal(check.failedSeq,2);}));
  test('lost acknowledgement and later readback are recorded as separate evidence events',()=>withFixture(f=>{accept(f.ledger,req());expect('REMOTE_ACK_LOST',()=>dispatchOne(f.ledger,f.remote,f.verifier,NOW+3,{loseAck:true}));assert.equal(verifyEvidenceChain(f.ledger).valid,true);assert.ok(f.ledger.prepare("SELECT 1 FROM evidence_events WHERE event_type='remote.dispatch_attempted'").get());assert.equal(f.ledger.prepare("SELECT 1 FROM evidence_events WHERE event_type='remote.postcondition_verified'").get(),undefined);dispatchOne(f.ledger,f.remote,f.verifier,NOW+4);assert.equal(verifyEvidenceChain(f.ledger).valid,true);assert.equal(f.ledger.prepare("SELECT count(*) n FROM evidence_events WHERE event_type='remote.postcondition_verified'").get().n,1);}));
  test('permission and receipt revocations enter the evidence journal',()=>withFixture(f=>{revokeAction(f.ledger,'tenant-A');revokeReader(f.ledger,'tenant-A','auditor-A');revokeReceipt(f.ledger,'receipt-1');assert.equal(verifyEvidenceChain(f.ledger).valid,true);const types=f.ledger.prepare('SELECT event_type FROM evidence_events ORDER BY seq').all().map(x=>x.event_type);assert.deepEqual(types,['tenant.action_permission_revoked','reconciliation.reader_permission_revoked','source.receipt_revoked']);}));
  test('source receipt evidence is immutable after intake',()=>withFixture(f=>{assert.throws(()=>f.ledger.prepare("UPDATE source_receipts SET expires_at=expires_at+1 WHERE receipt_id='receipt-1'").run());assert.throws(()=>f.ledger.prepare("DELETE FROM source_receipts WHERE receipt_id='receipt-1'").run());}));
  test('source event identity is unique within a tenant/source scope',()=>withFixture(f=>{assert.throws(()=>f.ledger.prepare('INSERT INTO source_receipts VALUES(?,?,?,?,?,?,?,?,?)').run('receipt-other','tenant-A','urn:fixture:capacity-service','event-receipt-1','d','slot-17','reserve',NOW+500,'capacity-prod'));}));
  test('SQLite BEGIN IMMEDIATE rejects a concurrent writer instead of interleaving',()=>withFixture(f=>{const second=openDb(f.ledgerPath);try{f.ledger.exec('BEGIN IMMEDIATE');assert.throws(()=>second.exec('BEGIN IMMEDIATE'),/busy|locked/i);f.ledger.exec('ROLLBACK');second.exec('BEGIN IMMEDIATE');second.exec('ROLLBACK');}finally{second.close();}}));

  // Warm sequential local microbenchmark; deliberately not described as SOTA.
  const bench=fixture(), local=[], dispatch=[]; const N=200;
  try {
    for(let i=0;i<N;i++){
      const resource=`bench-slot-${i}`,receipt=`bench-receipt-${i}`;
      seed(bench.ledger,{resource,receipt});
      const r=req({resource,receipt,actionKey:`bench-action-${i}`});
      let t=performance.now();accept(bench.ledger,r);local.push(performance.now()-t);
      t=performance.now();dispatchOne(bench.ledger,bench.remote,bench.verifier,NOW+10+i);dispatch.push(performance.now()-t);
    }
    assert.equal(bench.ledger.prepare("SELECT count(*) n FROM outbox WHERE status='delivered'").get().n,N);
    assert.equal(bench.remote.prepare('SELECT count(*) n FROM remote_operations').get().n,N);
  } finally {bench.close();}
  const pct=(xs,p)=>{const s=[...xs].sort((a,b)=>a-b);return Number(s[Math.floor((s.length-1)*p)].toFixed(3));};
  const totalMs=local.reduce((a,b)=>a+b,0)+dispatch.reduce((a,b)=>a+b,0);
  const db=new DatabaseSync(':memory:');const sqliteVersion=db.prepare('SELECT sqlite_version() v').get().v;db.close();
  console.log(JSON.stringify({schema:'sfeb-mon003-sqlite-transactional-outbox-report-v1',status:'passed',node:process.version,sqlite:sqliteVersion,deterministic_cases:tests.length,cases:tests,smoke_benchmark:{cycles:N,local_accept_ms:{p50:pct(local,.50),p95:pct(local,.95)},remote_dispatch_and_readback_ms:{p50:pct(dispatch,.50),p95:pct(dispatch,.95)},end_to_end_cycles_per_second:Number((N/totalMs*1000).toFixed(1)),environment:'single process, two file-backed SQLite DBs, warm sequential local-container storage, no network/broker'},qualification:{localDatabase:'SQLite WAL, synchronous=FULL, BEGIN IMMEDIATE; operation/resource-intent/outbox are one local transaction',remoteDatabase:'separate SQLite transaction with own current permission revision and tenant/objective fence checks; idempotency key; independent read connection',tested:['local failure injection at operation/resource/outbox writes','read-grant expiry, revocation, principal and scope binding','remote precommit failure and postcommit lost acknowledgement','remote idempotency replay and changed-digest conflict','independent postcondition readback','close/reopen durability and two-connection writer-lock behavior'],not_tested:['process kill at arbitrary storage instructions or physical power loss','PostgreSQL isolation/replication, multi-host consensus, brokers or real HTTP services','concurrent multi-process stress/linearizability beyond the writer-lock test','production authentication, PKI/key lifecycle, live source attestations; source receipt issuer_id in this fixture is trusted test data','industry-equivalent throughput or production SLO; the measured sequential run is a local smoke benchmark only']},core_invariant:'The local objective operation, resource intent, outbox event and causally ordered evidence journal commit or roll back together; source receipts and revocations are append-only evidence; remote effects are separately idempotent and independently read back; lost acknowledgement remains outcome_unknown until same-key reconciliation. No distributed atomicity is claimed.'},null,2));
} catch(e) {
  console.error(JSON.stringify({status:'failed',code:e.code??null,message:e.message,stack:e.stack},null,2));
  process.exitCode=1;
}
