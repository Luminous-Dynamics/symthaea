#!/usr/bin/env node
// SFEB MON-005: tenant-scoped, quorum-witnessed evidence checkpoints.
// Node.js >=22; only built-in modules. Reference implementation / executable model,
// not a production witness service or a substitute for independent key custody.
import assert from 'node:assert/strict';
import {
  createHash,
  createPrivateKey,
  createPublicKey,
  sign as cryptoSign,
  verify as cryptoVerify,
} from 'node:crypto';

const RECORD_DOMAIN = Buffer.from('SFEB-RECORD-V1\0', 'utf8');
const CHECKPOINT_DOMAIN = Buffer.from('SFEB-CHECKPOINT-V1\0', 'utf8');
const GENESIS_DOMAIN = Buffer.from('SFEB-GENESIS-V1\0', 'utf8');
const LEAF_PREFIX = Buffer.from([0x00]);
const NODE_PREFIX = Buffer.from([0x01]);
const ED25519_PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest();
}
function hex(bytes) { return Buffer.from(bytes).toString('hex'); }
function fromHex(value) {
  if (typeof value !== 'string' || !/^(?:[0-9a-f]{2})+$/.test(value)) {
    throw new TypeError('expected lowercase even-length hexadecimal');
  }
  return Buffer.from(value, 'hex');
}

// A deliberately strict JSON subset. No toJSON hooks, accessors, Dates, typed
// arrays, functions, undefined, BigInt, non-finite numbers, or cyclic objects.
function canonicalize(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value);
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('non-finite number is not canonical JSON');
    return JSON.stringify(value); // JSON.stringify maps -0 to 0.
  }
  if (Array.isArray(value)) {
    if (seen.has(value)) throw new TypeError('cyclic JSON value');
    seen.add(value);
    const out = `[${value.map((v) => {
      if (v === undefined) throw new TypeError('undefined array member');
      return canonicalize(v, seen);
    }).join(',')}]`;
    seen.delete(value);
    return out;
  }
  if (typeof value === 'object') {
    if (seen.has(value)) throw new TypeError('cyclic JSON value');
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) {
      throw new TypeError('only plain JSON objects are accepted');
    }
    seen.add(value);
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Object.keys(descriptors).sort();
    const fields = [];
    for (const key of keys) {
      const descriptor = descriptors[key];
      if (!descriptor.enumerable) continue;
      if (!Object.hasOwn(descriptor, 'value')) throw new TypeError('accessor properties are not accepted');
      if (descriptor.value === undefined) throw new TypeError('undefined object member');
      fields.push(`${JSON.stringify(key)}:${canonicalize(descriptor.value, seen)}`);
    }
    seen.delete(value);
    return `{${fields.join(',')}}`;
  }
  throw new TypeError(`unsupported JSON value type: ${typeof value}`);
}

function genesisHash(tenantId) {
  if (typeof tenantId !== 'string' || tenantId.length === 0) throw new TypeError('tenantId required');
  return hex(sha256(Buffer.concat([GENESIS_DOMAIN, Buffer.from(tenantId, 'utf8')])));
}

function makeRecord(tenantId, sequence, previousRecordHash, payload) {
  const body = { schema: 'sfeb-evidence-record-v1', tenantId, sequence, previousRecordHash, payload };
  const digest = sha256(Buffer.concat([RECORD_DOMAIN, Buffer.from(canonicalize(body), 'utf8')]));
  return Object.freeze({ ...body, recordHash: hex(digest) });
}

function verifyRecordChain(tenantId, records) {
  if (!Array.isArray(records)) throw new TypeError('records must be an array');
  let previous = genesisHash(tenantId);
  for (let i = 0; i < records.length; i += 1) {
    const record = records[i];
    if (!record || record.schema !== 'sfeb-evidence-record-v1' || record.tenantId !== tenantId) {
      throw new Error(`record ${i} has wrong schema or tenant scope`);
    }
    if (record.sequence !== i + 1) throw new Error(`record ${i} has non-contiguous sequence`);
    if (record.previousRecordHash !== previous) throw new Error(`record ${i} breaks previous-hash chain`);
    const expected = makeRecord(tenantId, record.sequence, record.previousRecordHash, record.payload);
    if (expected.recordHash !== record.recordHash) throw new Error(`record ${i} hash mismatch`);
    previous = record.recordHash;
  }
  return previous;
}

// RFC 9162 Merkle Tree Hash shape and leaf/node domain separation.
function largestPowerOfTwoLessThan(n) {
  if (!Number.isSafeInteger(n) || n < 2) throw new RangeError('n must be >= 2');
  let k = 1;
  while (k * 2 < n) k *= 2;
  return k;
}
function leafHash(record) {
  return sha256(Buffer.concat([LEAF_PREFIX, fromHex(record.recordHash)]));
}
function nodeHash(left, right) {
  return sha256(Buffer.concat([NODE_PREFIX, left, right]));
}
function merkleRoot(records) {
  if (!Array.isArray(records)) throw new TypeError('records must be an array');
  if (records.length === 0) return sha256(Buffer.alloc(0));
  if (records.length === 1) return leafHash(records[0]);
  const k = largestPowerOfTwoLessThan(records.length);
  return nodeHash(merkleRoot(records.slice(0, k)), merkleRoot(records.slice(k)));
}
function merkleInclusionProof(records, leafIndex) {
  if (!Array.isArray(records) || !Number.isSafeInteger(leafIndex) || leafIndex < 0 || leafIndex >= records.length) {
    throw new RangeError('invalid inclusion proof index');
  }
  if (records.length === 1) return [];
  const k = largestPowerOfTwoLessThan(records.length);
  if (leafIndex < k) {
    return [...merkleInclusionProof(records.slice(0, k), leafIndex), hex(merkleRoot(records.slice(k)))];
  }
  return [...merkleInclusionProof(records.slice(k), leafIndex - k), hex(merkleRoot(records.slice(0, k)))];
}
function verifyMerkleInclusion(record, leafIndex, treeSize, proof, expectedRootHex) {
  if (!Number.isSafeInteger(treeSize) || treeSize < 1 || !Number.isSafeInteger(leafIndex) ||
      leafIndex < 0 || leafIndex >= treeSize || !Array.isArray(proof)) return false;
  let fn = leafIndex;
  let sn = treeSize - 1;
  let root = leafHash(record);
  try {
    for (const siblingHex of proof) {
      if (sn === 0) return false;
      const sibling = fromHex(siblingHex);
      if (sibling.length !== 32) return false;
      if ((fn & 1) === 1 || fn === sn) {
        root = nodeHash(sibling, root);
        if ((fn & 1) === 0) {
          while ((fn & 1) === 0 && fn !== 0) {
            fn >>= 1;
            sn >>= 1;
          }
        }
      } else {
        root = nodeHash(root, sibling);
      }
      fn >>= 1;
      sn >>= 1;
    }
  } catch {
    return false;
  }
  return sn === 0 && hex(root) === expectedRootHex;
}

function checkpointBody(input) {
  const { tenantId, epoch, treeSize, rootHash, previousCheckpointHash, issuedAt, challengeNonce, witnessSetId } = input;
  if (input.schema !== undefined && input.schema !== 'sfeb-checkpoint-v1') throw new TypeError('unsupported checkpoint schema');
  if (typeof tenantId !== 'string' || tenantId.length === 0) throw new TypeError('tenantId required');
  if (!Number.isSafeInteger(epoch) || epoch < 1) throw new TypeError('invalid checkpoint epoch');
  if (!Number.isSafeInteger(treeSize) || treeSize < 1) throw new TypeError('invalid tree size');
  fromHex(rootHash);
  if (previousCheckpointHash !== null) fromHex(previousCheckpointHash);
  if (typeof issuedAt !== 'string' || !Number.isFinite(Date.parse(issuedAt))) throw new TypeError('issuedAt must be an ISO timestamp');
  if (typeof challengeNonce !== 'string' || challengeNonce.length < 16) throw new TypeError('fresh challenge nonce required');
  fromHex(witnessSetId);
  return Object.freeze({
    schema: 'sfeb-checkpoint-v1', tenantId, epoch, treeSize, rootHash,
    previousCheckpointHash, issuedAt, challengeNonce, witnessSetId,
  });
}
function checkpointDigest(checkpoint) {
  return sha256(Buffer.concat([CHECKPOINT_DOMAIN, Buffer.from(canonicalize(checkpoint), 'utf8')]));
}
function keyId(publicKey) {
  return hex(sha256(publicKey.export({ type: 'spki', format: 'der' }))).slice(0, 32);
}
function witnessSetDigest(witnesses) {
  return hex(sha256(Buffer.from(canonicalize(witnesses.map((w) => w.keyId).sort()), 'utf8')));
}

class Witness {
  constructor(name, privateKey) {
    if (typeof name !== 'string' || name.length === 0) throw new TypeError('witness name required');
    this.name = name;
    this.privateKey = privateKey;
    this.publicKey = createPublicKey(privateKey);
    this.keyId = keyId(this.publicKey);
    this.stateByTenant = new Map();
    this.challengeReceipts = new Map();
  }

  accept(checkpointInput, records) {
    const checkpoint = checkpointBody(checkpointInput);
    const stateKey = checkpoint.tenantId;
    const prior = this.stateByTenant.get(stateKey) ?? null;
    const challengeKey = `${stateKey}:${checkpoint.challengeNonce}`;
    if (checkpoint.treeSize !== records.length) throw new Error(`${this.name}: tree size mismatch`);
    verifyRecordChain(checkpoint.tenantId, records);
    const root = hex(merkleRoot(records));
    if (root !== checkpoint.rootHash) throw new Error(`${this.name}: Merkle root mismatch`);
    if (checkpoint.witnessSetId !== this.expectedWitnessSetId) throw new Error(`${this.name}: witness set mismatch`);

    const digest = checkpointDigest(checkpoint);
    const checkpointHash = hex(digest);
    const priorChallenge = this.challengeReceipts.get(challengeKey);
    if (priorChallenge) {
      if (priorChallenge.checkpointHash !== checkpointHash) throw new Error(`${this.name}: challenge replay conflicts with previously witnessed checkpoint`);
      return Object.freeze({ witnessKeyId: this.keyId, signature: priorChallenge.signature });
    }

    if (prior === null) {
      if (checkpoint.epoch !== 1 || checkpoint.previousCheckpointHash !== null) {
        throw new Error(`${this.name}: first checkpoint must be epoch 1 with no predecessor`);
      }
    } else {
      if (checkpoint.epoch !== prior.epoch + 1) throw new Error(`${this.name}: epoch rollback, replay, or gap`);
      if (checkpoint.previousCheckpointHash !== prior.checkpointHash) throw new Error(`${this.name}: checkpoint fork or broken linkage`);
      if (checkpoint.treeSize <= prior.treeSize) throw new Error(`${this.name}: tree size did not advance`);
      const prefixRoot = hex(merkleRoot(records.slice(0, prior.treeSize)));
      if (prefixRoot !== prior.rootHash) throw new Error(`${this.name}: previously witnessed prefix was rewritten`);
    }

    const signature = cryptoSign(null, digest, this.privateKey).toString('base64');
    this.challengeReceipts.set(challengeKey, { checkpointHash, signature });
    this.stateByTenant.set(stateKey, {
      epoch: checkpoint.epoch,
      treeSize: checkpoint.treeSize,
      rootHash: checkpoint.rootHash,
      checkpointHash,
    });
    return Object.freeze({ witnessKeyId: this.keyId, signature });
  }
}

function configureWitnessSet(witnesses) {
  if (!Array.isArray(witnesses) || witnesses.length < 2) throw new TypeError('at least two witnesses required');
  const ids = witnesses.map((w) => w.keyId);
  if (new Set(ids).size !== ids.length) throw new Error('duplicate witness key IDs');
  const setId = witnessSetDigest(witnesses);
  for (const witness of witnesses) witness.expectedWitnessSetId = setId;
  return setId;
}

function buildCheckpoint(records, { tenantId, epoch, previousCheckpointHash, challengeNonce, witnessSetId, issuedAt }) {
  verifyRecordChain(tenantId, records);
  return checkpointBody({
    tenantId,
    epoch,
    treeSize: records.length,
    rootHash: hex(merkleRoot(records)),
    previousCheckpointHash,
    issuedAt,
    challengeNonce,
    witnessSetId,
  });
}

function collectQuorum(checkpoint, records, witnesses) {
  const signatures = [];
  const failures = [];
  for (const witness of witnesses) {
    try {
      signatures.push(witness.accept(checkpoint, records));
    } catch (error) {
      failures.push({ witness: witness.name, reason: String(error.message) });
    }
  }
  return Object.freeze({
    checkpoint,
    checkpointHash: hex(checkpointDigest(checkpoint)),
    signatures: Object.freeze(signatures),
    witnessFailures: Object.freeze(failures),
  });
}

function verifyCertificate(certificate, records, trustedWitnessKeys, threshold, options = {}) {
  try {
    const checkpoint = checkpointBody(certificate.checkpoint);
    if (checkpoint.challengeNonce !== options.expectedChallengeNonce) return { ok: false, reason: 'challenge mismatch' };
    if (certificate.checkpointHash !== hex(checkpointDigest(checkpoint))) return { ok: false, reason: 'checkpoint digest mismatch' };
    if (checkpoint.treeSize !== records.length) return { ok: false, reason: 'tree size mismatch' };
    verifyRecordChain(checkpoint.tenantId, records);
    if (hex(merkleRoot(records)) !== checkpoint.rootHash) return { ok: false, reason: 'Merkle root mismatch' };
    if (!Number.isSafeInteger(threshold) || threshold < 1) return { ok: false, reason: 'invalid quorum threshold' };

    const trustedKeys = new Map(trustedWitnessKeys.map((key) => [key.keyId, key.publicKey]));
    const expectedSetId = hex(sha256(Buffer.from(canonicalize([...trustedKeys.keys()].sort()), 'utf8')));
    if (checkpoint.witnessSetId !== expectedSetId) return { ok: false, reason: 'trusted witness-set mismatch' };
    const prior = options.trustedPriorCheckpoint ?? null;
    if (prior === null) {
      if (checkpoint.epoch !== 1 || checkpoint.previousCheckpointHash !== null) return { ok: false, reason: 'unanchored initial checkpoint' };
    } else {
      if (checkpoint.previousCheckpointHash !== prior.checkpointHash || checkpoint.epoch !== prior.epoch + 1) {
        return { ok: false, reason: 'checkpoint does not extend trusted prior anchor' };
      }
      if (records.length <= prior.treeSize || hex(merkleRoot(records.slice(0, prior.treeSize))) !== prior.rootHash) {
        return { ok: false, reason: 'trusted prefix not preserved' };
      }
    }

    const digest = checkpointDigest(checkpoint);
    const counted = new Set();
    for (const item of certificate.signatures) {
      if (counted.has(item.witnessKeyId)) continue;
      const publicKey = trustedKeys.get(item.witnessKeyId);
      if (!publicKey) continue;
      let signature;
      try { signature = Buffer.from(item.signature, 'base64'); } catch { continue; }
      if (cryptoVerify(null, digest, publicKey, signature)) counted.add(item.witnessKeyId);
    }
    if (counted.size < threshold) return { ok: false, reason: `quorum not met: ${counted.size}/${threshold}` };
    return { ok: true, reason: 'verified', checkpointHash: hex(digest), validWitnesses: counted.size };
  } catch (error) {
    return { ok: false, reason: String(error.message) };
  }
}

// Deterministic test-only Ed25519 identities. Production keys must be generated
// in independent HSM/KMS boundaries; never ship these fixture seeds.
function fixtureWitness(name) {
  const seed = sha256(Buffer.from(`SFEB-MON005-TEST-ONLY:${name}`, 'utf8')).subarray(0, 32);
  const privateKey = createPrivateKey({
    key: Buffer.concat([ED25519_PKCS8_PREFIX, seed]),
    format: 'der',
    type: 'pkcs8',
  });
  return new Witness(name, privateKey);
}
function append(tenantId, records, payload) {
  const previousRecordHash = records.length ? records[records.length - 1].recordHash : genesisHash(tenantId);
  return [...records, makeRecord(tenantId, records.length + 1, previousRecordHash, payload)];
}
function actionEvidence(i, tenantId = 'tenant-a') {
  return {
    kind: 'external-action-observation',
    operationId: `operation-${i}`,
    tenantId,
    sourceReceiptDigest: sha256(Buffer.from(`source-${i}`)).toString('hex'),
    authorityReceiptDigest: sha256(Buffer.from(`authority-${i}`)).toString('hex'),
    executionReceiptDigest: sha256(Buffer.from(`execution-${i}`)).toString('hex'),
    outcomeReadbackDigest: sha256(Buffer.from(`readback-${i}`)).toString('hex'),
    outcome: 'committed_and_independently_read_back',
  };
}

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

// 1. Canonicalization and record commitments.
test('canonical JSON sorts object keys recursively', () => {
  assert.equal(canonicalize({ z: 1, a: { y: 2, x: 3 } }), '{"a":{"x":3,"y":2},"z":1}');
});
test('canonical JSON normalizes negative zero', () => {
  assert.equal(canonicalize(-0), '0');
});
test('canonical JSON rejects undefined members', () => {
  assert.throws(() => canonicalize({ a: undefined }), /undefined/);
});
test('canonical JSON rejects non-finite numbers', () => {
  assert.throws(() => canonicalize(Number.NaN), /non-finite/);
});
test('canonical JSON rejects accessors without invoking them', () => {
  let invoked = false;
  const value = Object.defineProperty({}, 'danger', { enumerable: true, get() { invoked = true; return 1; } });
  assert.throws(() => canonicalize(value), /accessor/);
  assert.equal(invoked, false);
});
test('canonical JSON rejects cycles', () => {
  const value = {}; value.self = value;
  assert.throws(() => canonicalize(value), /cyclic/);
});
test('tenant genesis commitments differ', () => {
  assert.notEqual(genesisHash('tenant-a'), genesisHash('tenant-b'));
});
test('record hash binds tenant, sequence, previous hash and payload', () => {
  const a = makeRecord('tenant-a', 1, genesisHash('tenant-a'), { x: 1 });
  const b = makeRecord('tenant-b', 1, genesisHash('tenant-b'), { x: 1 });
  const c = makeRecord('tenant-a', 1, genesisHash('tenant-a'), { x: 2 });
  assert.notEqual(a.recordHash, b.recordHash);
  assert.notEqual(a.recordHash, c.recordHash);
});
test('record chain verifies a valid append-only sequence', () => {
  let records = [];
  records = append('tenant-a', records, actionEvidence(1));
  records = append('tenant-a', records, actionEvidence(2));
  assert.equal(verifyRecordChain('tenant-a', records), records[1].recordHash);
});
test('record chain rejects tenant substitution', () => {
  const records = append('tenant-a', [], actionEvidence(1));
  assert.throws(() => verifyRecordChain('tenant-b', records), /tenant/);
});
test('record chain rejects reordered rows', () => {
  let records = append('tenant-a', [], actionEvidence(1));
  records = append('tenant-a', records, actionEvidence(2));
  assert.throws(() => verifyRecordChain('tenant-a', [...records].reverse()), /sequence|previous-hash/);
});
test('record chain rejects payload tampering', () => {
  const records = append('tenant-a', [], actionEvidence(1));
  const changed = [{ ...records[0], payload: { ...records[0].payload, outcome: 'not_committed' } }];
  assert.throws(() => verifyRecordChain('tenant-a', changed), /hash mismatch/);
});

// 2. RFC 9162 Merkle root and inclusion proof interoperability shape.
test('empty Merkle tree uses SHA-256 of the empty string', () => {
  assert.equal(hex(merkleRoot([])), hex(sha256(Buffer.alloc(0))));
});
test('Merkle inclusion proofs verify all leaves for tree sizes 1 through 31', () => {
  for (let n = 1; n <= 31; n += 1) {
    let records = [];
    for (let i = 0; i < n; i += 1) records = append('tenant-a', records, actionEvidence(i));
    const root = hex(merkleRoot(records));
    for (let i = 0; i < n; i += 1) {
      const proof = merkleInclusionProof(records, i);
      assert.equal(verifyMerkleInclusion(records[i], i, n, proof, root), true, `n=${n} i=${i}`);
      assert.equal(verifyMerkleInclusion(records[i], i, n, proof, '00'.repeat(32)), false);
    }
  }
});
test('Merkle leaf and internal-node domains are distinct', () => {
  const one = append('tenant-a', [], actionEvidence(1));
  const leaf = leafHash(one[0]);
  const node = nodeHash(leaf, leaf);
  assert.notEqual(hex(leaf), hex(node));
});
test('Merkle verifier rejects a modified inclusion path', () => {
  let records = [];
  for (let i = 0; i < 7; i += 1) records = append('tenant-a', records, actionEvidence(i));
  const proof = merkleInclusionProof(records, 3);
  proof[0] = '00'.repeat(32);
  assert.equal(verifyMerkleInclusion(records[3], 3, records.length, proof, hex(merkleRoot(records))), false);
});
test('Merkle verifier rejects invalid leaf indexes and tree sizes', () => {
  let records = [];
  for (let i = 0; i < 4; i += 1) records = append('tenant-a', records, actionEvidence(i));
  const proof = merkleInclusionProof(records, 2);
  const root = hex(merkleRoot(records));
  assert.equal(verifyMerkleInclusion(records[2], 4, 4, proof, root), false);
  assert.equal(verifyMerkleInclusion(records[2], 2, 3, proof, root), false);
});

// 3. Quorum checkpoints and independent witness state.
const witnesses = [fixtureWitness('witness-1'), fixtureWitness('witness-2'), fixtureWitness('witness-3'), fixtureWitness('witness-4')];
const witnessSetId = configureWitnessSet(witnesses);
const trustedWitnessKeys = witnesses.map((w) => ({ keyId: w.keyId, publicKey: w.publicKey }));
const threshold = 3;
const issuedAt = '2026-11-24T12:00:00.000Z';
let recordsA = [];
for (let i = 1; i <= 12; i += 1) recordsA = append('tenant-a', recordsA, actionEvidence(i));
const checkpointA = buildCheckpoint(recordsA, {
  tenantId: 'tenant-a', epoch: 1, previousCheckpointHash: null,
  challengeNonce: 'auditor-fresh-nonce-0001', witnessSetId, issuedAt,
});
const certificateA = collectQuorum(checkpointA, recordsA, witnesses);
const trustedPriorA = {
  epoch: checkpointA.epoch,
  treeSize: checkpointA.treeSize,
  rootHash: checkpointA.rootHash,
  checkpointHash: certificateA.checkpointHash,
};
test('four Ed25519 witnesses certify a tenant-bound checkpoint with a 3-of-4 quorum', () => {
  assert.equal(certificateA.signatures.length, 4);
  assert.equal(certificateA.witnessFailures.length, 0);
  assert.equal(verifyCertificate(certificateA, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, true);
});
test('three-of-four quorum remains valid when one witness is unavailable', () => {
  const threeOfFour = { ...certificateA, signatures: certificateA.signatures.slice(0, 3) };
  assert.equal(verifyCertificate(threeOfFour, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, true);
});
test('two-of-four signatures do not meet quorum', () => {
  const one = { ...certificateA, signatures: certificateA.signatures.slice(0, 2) };
  const result = verifyCertificate(one, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  });
  assert.equal(result.ok, false);
  assert.match(result.reason, /quorum not met/);
});
test('duplicate witness signatures count only once', () => {
  const oneDuplicated = { ...certificateA, signatures: [certificateA.signatures[0], certificateA.signatures[0], certificateA.signatures[0]] };
  assert.equal(verifyCertificate(oneDuplicated, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, false);
});
test('unknown witness key cannot contribute to quorum', () => {
  const forgedList = { ...certificateA, signatures: [
    { witnessKeyId: 'ff'.repeat(16), signature: certificateA.signatures[0].signature },
  ] };
  assert.equal(verifyCertificate(forgedList, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, false);
});
test('tampered checkpoint field invalidates signatures', () => {
  const altered = { ...certificateA, checkpoint: { ...checkpointA, epoch: 2 } };
  assert.equal(verifyCertificate(altered, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, false);
});
test('tampered record invalidates checkpoint root', () => {
  const altered = [...recordsA];
  altered[4] = { ...altered[4], payload: { ...altered[4].payload, outcome: 'unknown' } };
  const result = verifyCertificate(certificateA, altered, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  });
  assert.equal(result.ok, false);
});
test('fresh challenge nonce is required to stop stale certificate replay', () => {
  const result = verifyCertificate(certificateA, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'different-fresh-nonce-0002',
  });
  assert.equal(result.ok, false);
  assert.match(result.reason, /challenge mismatch/);
});
test('witness set identity is cryptographically bound into checkpoint', () => {
  const changed = { ...certificateA, checkpoint: { ...checkpointA, witnessSetId: 'ab'.repeat(32) } };
  assert.equal(verifyCertificate(changed, recordsA, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  }).ok, false);
});
test('unsupported checkpoint schema is rejected', () => {
  assert.throws(() => checkpointBody({ ...checkpointA, schema: 'sfeb-checkpoint-v0' }), /unsupported checkpoint schema/);
});
test('witness returns the identical signature for an idempotent challenge retry', () => {
  const witness = witnesses[0];
  const first = certificateA.signatures.find((item) => item.witnessKeyId === witness.keyId);
  const repeated = witness.accept(checkpointA, recordsA);
  assert.equal(repeated.signature, first.signature);
});
test('witness rejects a different checkpoint reusing an already consumed challenge', () => {
  const witness = witnesses[0];
  const altered = checkpointBody({ ...checkpointA, epoch: 2, challengeNonce: checkpointA.challengeNonce });
  assert.throws(() => witness.accept(altered, recordsA), /challenge replay conflicts/);
});
test('witness refuses first checkpoint with a non-genesis epoch', () => {
  const isolated = fixtureWitness('isolated-witness');
  const set = configureWitnessSet([isolated, fixtureWitness('isolated-witness-2')]);
  const bad = buildCheckpoint(recordsA, {
    tenantId: 'tenant-a', epoch: 2, previousCheckpointHash: null,
    challengeNonce: 'isolated-nonce-00000001', witnessSetId: set, issuedAt,
  });
  assert.throws(() => isolated.accept(bad, recordsA), /first checkpoint/);
});

// 4. Append, rollback, fork and privileged historical rewrite tests.
let recordsB = recordsA;
for (let i = 13; i <= 18; i += 1) recordsB = append('tenant-a', recordsB, actionEvidence(i));
const checkpointB = buildCheckpoint(recordsB, {
  tenantId: 'tenant-a', epoch: 2, previousCheckpointHash: certificateA.checkpointHash,
  challengeNonce: 'auditor-fresh-nonce-0002', witnessSetId, issuedAt: '2026-11-24T12:01:00.000Z',
});
const certificateB = collectQuorum(checkpointB, recordsB, witnesses);
const trustedPriorB = {
  epoch: checkpointB.epoch,
  treeSize: checkpointB.treeSize,
  rootHash: checkpointB.rootHash,
  checkpointHash: certificateB.checkpointHash,
};
test('valid append preserves prior witnessed prefix and advances epoch', () => {
  assert.equal(certificateB.signatures.length, 4);
  assert.equal(verifyCertificate(certificateB, recordsB, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0002', trustedPriorCheckpoint: trustedPriorA,
  }).ok, true);
});
test('witness rejects rollback to the old checkpoint under a fresh challenge', () => {
  const rollback = checkpointBody({ ...checkpointA, challengeNonce: 'rollback-fresh-nonce-0001' });
  assert.throws(() => witnesses[0].accept(rollback, recordsA), /epoch rollback/);
});
test('witness rejects a same-epoch fork after accepting the canonical checkpoint', () => {
  const replicaSet = [fixtureWitness('witness-1'), fixtureWitness('witness-2'), fixtureWitness('witness-3'), fixtureWitness('witness-4')];
  configureWitnessSet(replicaSet);
  collectQuorum(checkpointA, recordsA, replicaSet);
  const canonicalRecords = append('tenant-a', recordsA, actionEvidence(13));
  const canonicalCheckpoint = buildCheckpoint(canonicalRecords, {
    tenantId: 'tenant-a', epoch: 2, previousCheckpointHash: certificateA.checkpointHash,
    challengeNonce: 'canonical-epoch2-nonce-0001', witnessSetId, issuedAt,
  });
  collectQuorum(canonicalCheckpoint, canonicalRecords, replicaSet);
  const forkRecords = append('tenant-a', recordsA, { kind: 'forked-payload', value: 1 });
  const fork = buildCheckpoint(forkRecords, {
    tenantId: 'tenant-a', epoch: 2, previousCheckpointHash: certificateA.checkpointHash,
    challengeNonce: 'fork-attempt-nonce-00001', witnessSetId, issuedAt,
  });
  assert.throws(() => replicaSet[0].accept(fork, forkRecords), /epoch rollback|checkpoint fork/);
});
test('witness rejects a rewritten previously witnessed prefix even when the attacker recomputes the chain', () => {
  const replicaSet = [fixtureWitness('witness-1'), fixtureWitness('witness-2'), fixtureWitness('witness-3'), fixtureWitness('witness-4')];
  configureWitnessSet(replicaSet);
  collectQuorum(checkpointA, recordsA, replicaSet);
  const rewrittenPayload = { ...recordsA[0].payload, outcome: 'rewritten-after-commit' };
  let rewritten = append('tenant-a', [], rewrittenPayload);
  for (let i = 1; i < recordsA.length; i += 1) rewritten = append('tenant-a', rewritten, recordsA[i].payload);
  rewritten = append('tenant-a', rewritten, actionEvidence(19));
  const rewrittenCheckpoint = buildCheckpoint(rewritten, {
    tenantId: 'tenant-a', epoch: 2, previousCheckpointHash: certificateA.checkpointHash,
    challengeNonce: 'rewrite-prefix-nonce-0001', witnessSetId, issuedAt,
  });
  assert.throws(() => replicaSet[1].accept(rewrittenCheckpoint, rewritten), /previously witnessed prefix was rewritten/);
});
test('witness rejects a skipped checkpoint epoch', () => {
  const tooFar = buildCheckpoint(recordsB, {
    tenantId: 'tenant-a', epoch: 4, previousCheckpointHash: certificateA.checkpointHash,
    challengeNonce: 'epoch-gap-nonce-0000001', witnessSetId, issuedAt,
  });
  assert.throws(() => witnesses[2].accept(tooFar, recordsB), /epoch rollback, replay, or gap/);
});
test('independent verifier rejects non-descendant checkpoint', () => {
  const invalid = verifyCertificate(certificateB, recordsB, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0002',
    trustedPriorCheckpoint: { ...trustedPriorA, checkpointHash: 'ee'.repeat(32) },
  });
  assert.equal(invalid.ok, false);
  assert.match(invalid.reason, /does not extend/);
});
test('independent verifier rejects modified historical prefix', () => {
  const altered = [...recordsB];
  altered[0] = { ...altered[0], payload: { ...altered[0].payload, outcome: 'tampered' } };
  const result = verifyCertificate(certificateB, altered, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0002', trustedPriorCheckpoint: trustedPriorA,
  });
  assert.equal(result.ok, false);
});
test('independent verifier rejects cross-tenant checkpoint substitution', () => {
  let otherTenant = [];
  otherTenant = append('tenant-b', otherTenant, actionEvidence(1, 'tenant-b'));
  const result = verifyCertificate(certificateA, otherTenant, trustedWitnessKeys, threshold, {
    expectedChallengeNonce: 'auditor-fresh-nonce-0001',
  });
  assert.equal(result.ok, false);
});
test('checkpoint root commits to a non-empty tenant evidence sequence', () => {
  assert.equal(checkpointA.treeSize, 12);
  assert.equal(checkpointA.rootHash, hex(merkleRoot(recordsA)));
});

let failures = 0;
for (const item of tests) {
  try {
    item.fn();
    process.stdout.write(`PASS ${item.name}\n`);
  } catch (error) {
    failures += 1;
    process.stderr.write(`FAIL ${item.name}\n${error?.stack ?? error}\n`);
  }
}
const report = {
  artifact: 'SFEB MON-005 witnessed evidence checkpoint reference model v1',
  runtime: process.version,
  cryptography: 'Node.js built-in SHA-256 and Ed25519; deterministic test-only keys',
  merkleCompatibility: 'RFC 9162 Merkle Tree Hash leaf/node domain separation and inclusion-proof shape',
  tests: tests.length,
  passed: tests.length - failures,
  failed: failures,
  merkleInclusionChecks: Array.from({ length: 31 }, (_, i) => i + 1).reduce((n, size) => n + size, 0),
  witnessThreshold: `${threshold}-of-${witnesses.length}`,
  quorumInterpretation: '3-of-4 has quorum intersection of at least two; with at most one Byzantine witness, at least one intersecting signer is honest and refuses to equivocate, assuming durable atomic witness state',
  witnessedCheckpoints: 2,
  recordsInFirstCheckpoint: recordsA.length,
  recordsInSecondCheckpoint: recordsB.length,
  observedAttacksRejected: [
    'payload tampering', 'record reordering', 'tenant substitution', 'quorum downgrade',
    'duplicate witness identity', 'unknown witness key', 'checkpoint mutation',
    'stale challenge replay', 'epoch rollback/gap', 'same-epoch fork',
    'historical-prefix rewrite with recomputed record hashes', 'broken checkpoint linkage',
  ],
  limitations: [
    'witness state is in-memory in this reference model',
    'witnesses are simulated in one process and do not establish operational independence',
    'test keys are deterministic fixtures, not production keys or HSM-backed identities',
    'full prefix is recomputed at each checkpoint; RFC 9162 consistency proofs are the scaling path',
    'no PostgreSQL adapter, network service, trusted timestamp authority, key rotation, or hardware isolation is implemented',
    'canonicalization is a strict local JSON subset, not a complete RFC 8785 implementation',
  ],
};
process.stdout.write(`\nSUMMARY ${JSON.stringify(report)}\n`);
if (failures > 0) process.exitCode = 1;
