#!/usr/bin/env node
// SFEB MON-006: SCITT-compatible signed action evidence + COSE receipt reference model.
// Node.js 22+; built-in modules only. This is not a live SCITT TS client or production profile.
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { createHash, createPrivateKey, createPublicKey, sign as cryptoSign, verify as cryptoVerify } from 'node:crypto';

const COSE_SIGN1_TAG = 18;
const COSE_ALG_EDDSA = -8;
const RFC9942_VDS_RFC9162_SHA256 = 1;
const RFC9942_VDP_INCLUSION = -1;
const CONTENT_TYPE = 'application/sfeb-action-evidence+cbor';
const PKCS8_ED25519_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

function sha256(data) { return createHash('sha256').update(data).digest(); }
function hex(data) { return Buffer.from(data).toString('hex'); }
function compareBytes(a, b) {
  if (a.length !== b.length) return a.length - b.length;
  return Buffer.compare(a, b);
}
function head(major, n) {
  if (!Number.isSafeInteger(n) || n < 0) throw new RangeError('CBOR length/integer must be a non-negative safe integer');
  if (n < 24) return Buffer.from([(major << 5) | n]);
  if (n <= 0xff) return Buffer.from([(major << 5) | 24, n]);
  if (n <= 0xffff) { const b = Buffer.alloc(3); b[0] = (major << 5) | 25; b.writeUInt16BE(n, 1); return b; }
  if (n <= 0xffffffff) { const b = Buffer.alloc(5); b[0] = (major << 5) | 26; b.writeUInt32BE(n, 1); return b; }
  const b = Buffer.alloc(9); b[0] = (major << 5) | 27; b.writeBigUInt64BE(BigInt(n), 1); return b;
}
function encodeCbor(value) {
  if (value === null) return Buffer.from([0xf6]);
  if (value === false) return Buffer.from([0xf4]);
  if (value === true) return Buffer.from([0xf5]);
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
    const b = Buffer.from(value); return Buffer.concat([head(2, b.length), b]);
  }
  if (typeof value === 'string') {
    const b = Buffer.from(value, 'utf8'); return Buffer.concat([head(3, b.length), b]);
  }
  if (typeof value === 'number' && Number.isSafeInteger(value)) {
    return value >= 0 ? head(0, value) : head(1, -1 - value);
  }
  if (Array.isArray(value)) return Buffer.concat([head(4, value.length), ...value.map(encodeCbor)]);
  if (value instanceof Map) {
    const pairs = [...value.entries()].map(([k, v]) => [encodeCbor(k), encodeCbor(v)]);
    pairs.sort((a, b) => compareBytes(a[0], b[0]));
    for (let i = 1; i < pairs.length; i++) {
      if (Buffer.compare(pairs[i - 1][0], pairs[i][0]) === 0) throw new Error('duplicate canonical CBOR map key');
    }
    return Buffer.concat([head(5, pairs.length), ...pairs.flat()]);
  }
  if (value && typeof value === 'object' && Number.isSafeInteger(value.tag) && Object.hasOwn(value, 'value')) {
    return Buffer.concat([head(6, value.tag), encodeCbor(value.value)]);
  }
  throw new TypeError(`unsupported CBOR value: ${typeof value}`);
}
function decodeCbor(input) {
  const bytes = Buffer.from(input); let offset = 0;
  function readN(n) { if (offset + n > bytes.length) throw new Error('truncated CBOR'); const out = bytes.subarray(offset, offset + n); offset += n; return out; }
  function readLength(ai) {
    if (ai < 24) return ai;
    if (ai === 24) return readN(1)[0];
    if (ai === 25) return readN(2).readUInt16BE(0);
    if (ai === 26) return readN(4).readUInt32BE(0);
    if (ai === 27) { const n = readN(8).readBigUInt64BE(0); if (n > BigInt(Number.MAX_SAFE_INTEGER)) throw new RangeError('CBOR integer too large'); return Number(n); }
    throw new Error('indefinite/reserved CBOR lengths are not accepted');
  }
  function item(depth = 0) {
    if (depth > 64) throw new Error('CBOR nesting limit exceeded');
    const initial = readN(1)[0], major = initial >> 5, ai = initial & 31;
    if (major === 0) return readLength(ai);
    if (major === 1) return -1 - readLength(ai);
    if (major === 2) return Buffer.from(readN(readLength(ai)));
    if (major === 3) return readN(readLength(ai)).toString('utf8');
    if (major === 4) { const n = readLength(ai), out = []; for (let i = 0; i < n; i++) out.push(item(depth + 1)); return out; }
    if (major === 5) {
      const n = readLength(ai), out = new Map();
      for (let i = 0; i < n; i++) { const k = item(depth + 1), v = item(depth + 1); if (out.has(k)) throw new Error('duplicate CBOR map key'); out.set(k, v); }
      return out;
    }
    if (major === 6) return { tag: readLength(ai), value: item(depth + 1) };
    if (major === 7 && ai === 20) return false;
    if (major === 7 && ai === 21) return true;
    if (major === 7 && ai === 22) return null;
    throw new Error('unsupported CBOR simple/floating value');
  }
  const result = item();
  if (offset !== bytes.length) throw new Error('trailing CBOR bytes');
  return result;
}
function mapGet(map, key) { if (!(map instanceof Map) || !map.has(key)) throw new Error(`missing CBOR map label ${String(key)}`); return map.get(key); }
function keyPair(name) {
  const seed = sha256(Buffer.from(`SFEB-MON006-TEST-ONLY:${name}`));
  const privateKey = createPrivateKey({ key: Buffer.concat([PKCS8_ED25519_PREFIX, seed]), format: 'der', type: 'pkcs8' });
  const publicKey = createPublicKey(privateKey);
  return { privateKey, publicKey, publicDer: publicKey.export({ format: 'der', type: 'spki' }) };
}
function makeSigStructure(protectedBytes, payload) {
  return encodeCbor(['Signature1', protectedBytes, Buffer.alloc(0), Buffer.from(payload)]);
}
function makeCoseSign1({ protectedMap, unprotectedMap = new Map(), payload, detached = false, privateKey }) {
  const protectedBytes = encodeCbor(protectedMap);
  const payloadBytes = Buffer.from(payload);
  const signature = cryptoSign(null, makeSigStructure(protectedBytes, payloadBytes), privateKey);
  const envelope = [protectedBytes, unprotectedMap, detached ? null : payloadBytes, signature];
  return encodeCbor({ tag: COSE_SIGN1_TAG, value: envelope });
}
function parseCoseSign1(coseBytes) {
  const tagged = decodeCbor(coseBytes);
  if (!encodeCbor(tagged).equals(Buffer.from(coseBytes))) throw new Error('COSE_Sign1 is not deterministic CBOR');
  if (!tagged || tagged.tag !== COSE_SIGN1_TAG || !Array.isArray(tagged.value) || tagged.value.length !== 4) throw new Error('expected CBOR tag 18 COSE_Sign1');
  const [protectedBytes, unprotected, payload, signature] = tagged.value;
  if (!Buffer.isBuffer(protectedBytes) || !(unprotected instanceof Map) || !(payload === null || Buffer.isBuffer(payload)) || !Buffer.isBuffer(signature)) throw new Error('malformed COSE_Sign1 fields');
  const protectedMap = decodeCbor(protectedBytes);
  if (!(protectedMap instanceof Map)) throw new Error('COSE protected header must decode to a map');
  if (!encodeCbor(protectedMap).equals(protectedBytes)) throw new Error('COSE protected header is not deterministic CBOR');
  return { protectedBytes, protectedMap, unprotected, payload, signature, envelope: tagged.value };
}
function verifyCoseSign1(coseBytes, publicKey, detachedPayload = undefined) {
  const parsed = parseCoseSign1(coseBytes);
  const payload = parsed.payload === null ? detachedPayload : parsed.payload;
  if (payload === undefined || payload === null) throw new Error('detached payload must be supplied');
  const ok = cryptoVerify(null, makeSigStructure(parsed.protectedBytes, payload), publicKey, parsed.signature);
  if (!ok) throw new Error('COSE_Sign1 signature verification failed');
  return { ...parsed, verifiedPayload: Buffer.from(payload) };
}
function makeStatement({ tenantId, resourceId, issuer, subject, kid, keyPair: issuerKeys, actionEvidence }) {
  const payload = encodeCbor(new Map(Object.entries(actionEvidence)));
  const protectedMap = new Map([
    [1, COSE_ALG_EDDSA],
    [3, CONTENT_TYPE],
    [4, Buffer.from(kid)],
    [15, new Map([[1, issuer], [2, subject]])],
  ]);
  const bytes = makeCoseSign1({ protectedMap, unprotectedMap: new Map(), payload, privateKey: issuerKeys.privateKey });
  return { bytes, payload, protectedMap, tenantId, resourceId, issuer, subject, kid: Buffer.from(kid) };
}
function verifyActionStatement(coseBytes, trustStore, expectedTenant, expectedResource) {
  const parsed = parseCoseSign1(coseBytes);
  const h = parsed.protectedMap;
  if (mapGet(h, 1) !== COSE_ALG_EDDSA) throw new Error('unsupported statement algorithm');
  if (mapGet(h, 3) !== CONTENT_TYPE) throw new Error('unexpected statement content type');
  const kid = mapGet(h, 4);
  if (!Buffer.isBuffer(kid)) throw new Error('kid must be a byte string');
  const claims = mapGet(h, 15);
  const issuer = mapGet(claims, 1), subject = mapGet(claims, 2);
  const trusted = trustStore.get(issuer);
  if (!trusted || !Buffer.from(trusted.kid).equals(kid)) throw new Error('issuer/kid is not trusted');
  if (trusted.tenantId !== expectedTenant) throw new Error('issuer is not authorized for expected tenant');
  const expectedSubject = `urn:sfeb:tenant:${expectedTenant}:resource:${expectedResource}`;
  if (subject !== expectedSubject) throw new Error('statement subject mismatch');
  const verified = verifyCoseSign1(coseBytes, trusted.publicKey);
  const payloadMap = decodeCbor(verified.verifiedPayload);
  if (!encodeCbor(payloadMap).equals(verified.verifiedPayload)) throw new Error('action payload is not deterministic CBOR');
  if (!(payloadMap instanceof Map)) throw new Error('action payload must be a CBOR map');
  const evidence = Object.fromEntries(payloadMap.entries());
  if (evidence.tenantId !== expectedTenant || evidence.resourceId !== expectedResource) throw new Error('payload tenant/resource binding mismatch');
  for (const field of ['requestDigest','sourceReceiptDigest','executionReceiptDigest','sinkReceiptDigest','postconditionReadbackDigest']) {
    if (typeof evidence[field] !== 'string' || !/^[0-9a-f]{64}$/.test(evidence[field])) throw new Error(`invalid ${field}`);
  }
  if (!Number.isSafeInteger(evidence.authorityRevision) || evidence.authorityRevision < 1 || !Number.isSafeInteger(evidence.objectiveFence) || evidence.objectiveFence < 1 || !Number.isSafeInteger(evidence.aggregateSequence) || evidence.aggregateSequence < 1) throw new Error('invalid authority/fence/sequence');
  return { issuer, subject, kid, evidence, payloadBytes: verified.verifiedPayload };
}

// RFC 9162 Merkle Tree Hash over the CBOR-encoded Signed Statement entries.
function largestPowerOfTwoLessThan(n) { let k = 1; while (k * 2 < n) k *= 2; return k; }
function leafHash(entry) { return sha256(Buffer.concat([Buffer.from([0]), Buffer.from(entry)])); }
function nodeHash(left, right) { return sha256(Buffer.concat([Buffer.from([1]), left, right])); }
function merkleRoot(entries) {
  if (!entries.length) return sha256(Buffer.alloc(0));
  if (entries.length === 1) return leafHash(entries[0]);
  const k = largestPowerOfTwoLessThan(entries.length);
  return nodeHash(merkleRoot(entries.slice(0,k)), merkleRoot(entries.slice(k)));
}
function inclusionPath(entries, index) {
  if (!Number.isSafeInteger(index) || index < 0 || index >= entries.length) throw new RangeError('invalid Merkle leaf index');
  if (entries.length === 1) return [];
  const k = largestPowerOfTwoLessThan(entries.length);
  if (index < k) return [...inclusionPath(entries.slice(0,k),index), merkleRoot(entries.slice(k))];
  return [...inclusionPath(entries.slice(k),index-k), merkleRoot(entries.slice(0,k))];
}
function rootFromInclusionProof(entry, index, size, path) {
  if (!Number.isSafeInteger(size) || size < 1 || !Number.isSafeInteger(index) || index < 0 || index >= size || !Array.isArray(path)) return null;
  let fn = index, sn = size - 1, root = leafHash(entry);
  try {
    for (const siblingValue of path) {
      const sibling = Buffer.from(siblingValue);
      if (sibling.length !== 32 || sn === 0) return null;
      if ((fn & 1) === 1 || fn === sn) {
        root = nodeHash(sibling, root);
        if ((fn & 1) === 0) while ((fn & 1) === 0 && fn !== 0) { fn >>= 1; sn >>= 1; }
      } else root = nodeHash(root, sibling);
      fn >>= 1; sn >>= 1;
    }
  } catch { return null; }
  return sn === 0 ? root : null;
}
function verifyInclusion(entry, index, size, path, expectedRoot) {
  const computed = rootFromInclusionProof(entry, index, size, path);
  return computed !== null && computed.equals(expectedRoot);
}
function makeTransparencyService({ issuer, logId, kid, keyPair: tsKeys }) {
  const entries = [];
  return {
    issuer, logId, kid: Buffer.from(kid), keys: tsKeys, entries,
    register(statementBytes, issuerTrustStore, expectedTenant, expectedResource) {
      const statementEnvelope = parseCoseSign1(statementBytes);
      if (statementEnvelope.unprotected.size !== 0) throw new Error('SCITT Signed Statement unprotected header must be empty at registration');
      verifyActionStatement(statementBytes, issuerTrustStore, expectedTenant, expectedResource);
      const index = entries.length;
      entries.push(Buffer.from(statementBytes));
      const root = merkleRoot(entries);
      const proofBytes = encodeCbor([entries.length, index, inclusionPath(entries,index)]);
      const protectedMap = new Map([
        [1, COSE_ALG_EDDSA], [4, Buffer.from(kid)], [395, RFC9942_VDS_RFC9162_SHA256],
        [15, new Map([[1, issuer], [2, logId]])],
      ]);
      const unprotected = new Map([[396, new Map([[RFC9942_VDP_INCLUSION, [proofBytes]]])]]);
      // RFC 9942 receipt payload is detached and contains the Merkle Tree Hash.
      return makeCoseSign1({ protectedMap, unprotectedMap: unprotected, payload: root, detached: true, privateKey: tsKeys.privateKey });
    },
  };
}
function verifyInclusionReceipt(receiptBytes, statementBytes, transparencyTrustStore) {
  const parsed = parseCoseSign1(receiptBytes);
  const h = parsed.protectedMap;
  if (mapGet(h,1) !== COSE_ALG_EDDSA || mapGet(h,395) !== RFC9942_VDS_RFC9162_SHA256) throw new Error('unsupported COSE receipt algorithm/VDS');
  const receiptKid = mapGet(h,4);
  if (!Buffer.isBuffer(receiptKid)) throw new Error('receipt kid must be a byte string');
  const claims = mapGet(h,15), issuer = mapGet(claims,1), logId = mapGet(claims,2);
  const trusted = transparencyTrustStore.get(issuer);
  if (!trusted || trusted.logId !== logId || !Buffer.from(trusted.kid).equals(receiptKid)) throw new Error('untrusted Transparency Service identity/key id');
  const vdp = mapGet(parsed.unprotected,396);
  const proofList = mapGet(vdp,RFC9942_VDP_INCLUSION);
  if (!Array.isArray(proofList) || proofList.length !== 1 || !Buffer.isBuffer(proofList[0])) throw new Error('expected one RFC 9942 inclusion proof');
  const proof = decodeCbor(proofList[0]);
  if (!Array.isArray(proof) || proof.length !== 3) throw new Error('malformed RFC 9942 inclusion proof');
  const [treeSize, leafIndex, path] = proof;
  if (!Number.isSafeInteger(treeSize) || !Number.isSafeInteger(leafIndex) || !Array.isArray(path) || path.some((x) => !Buffer.isBuffer(x))) throw new Error('invalid inclusion proof fields');
  // RFC 9942: first derive the Merkle root from the candidate entry and proof;
  // that computed root is the detached COSE_Sign1 payload authenticated by the TS.
  const root = rootFromInclusionProof(statementBytes, leafIndex, treeSize, path);
  if (root === null) throw new Error('RFC 9162 inclusion proof verification failed');
  verifyCoseSign1(receiptBytes, trusted.publicKey, root);
  return { issuer, logId, treeSize, leafIndex, root: hex(root) };
}
function makeTransparentStatement(statementBytes, receipts) {
  const parsed = parseCoseSign1(statementBytes);
  const unprotected = new Map([[394, receipts.map((r) => Buffer.from(r))]]);
  return encodeCbor({ tag: COSE_SIGN1_TAG, value: [parsed.protectedBytes, unprotected, parsed.payload, parsed.signature] });
}
function verifyTransparentStatement(bytes, issuerTrustStore, transparencyTrustStore, expectedTenant, expectedResource, requiredDistinctServices = 2) {
  const parsed = parseCoseSign1(bytes);
  const receipts = mapGet(parsed.unprotected,394);
  if (!Array.isArray(receipts) || receipts.length < requiredDistinctServices || receipts.some((r) => !Buffer.isBuffer(r))) throw new Error('insufficient attached SCITT receipts');
  const base = encodeCbor({ tag: COSE_SIGN1_TAG, value: [parsed.protectedBytes, new Map(), parsed.payload, parsed.signature] });
  const statement = verifyActionStatement(base, issuerTrustStore, expectedTenant, expectedResource);
  const verified = receipts.map((r) => verifyInclusionReceipt(r,base,transparencyTrustStore));
  const unique = new Set(verified.map((r) => r.issuer));
  if (unique.size < requiredDistinctServices) throw new Error('receipt policy requires distinct Transparency Services');
  return { statement, receipts: verified };
}

function testDigest(label) { return hex(sha256(Buffer.from(label))); }
function makeFixture(tenantId, resourceId, sequence = 41) {
  const issuer = `https://issuer.example/tenants/${tenantId}`;
  const subject = `urn:sfeb:tenant:${tenantId}:resource:${resourceId}`;
  const kid = sha256(Buffer.from(`kid:${tenantId}`)).subarray(0,8);
  const keys = keyPair(`issuer:${tenantId}`);
  const actionEvidence = {
    schema: 'sfeb-action-evidence-v1', tenantId, resourceId,
    operationId: `op-${tenantId}-${sequence}`, action: 'resource.reserve',
    requestDigest: testDigest('request'), sourceReceiptDigest: testDigest('source'),
    authorityRevision: 7, objectiveFence: 19, executionReceiptDigest: testDigest('execution'),
    sinkReceiptDigest: testDigest('sink'), postconditionReadbackDigest: testDigest('readback'),
    aggregateSequence: sequence, issuedAt: 1795520000,
  };
  const statement = makeStatement({ tenantId, resourceId, issuer, subject, kid, keyPair: keys, actionEvidence });
  const trust = new Map([[issuer,{tenantId,resourceId,kid,publicKey:keys.publicKey}]]);
  return { tenantId, resourceId, issuer, subject, kid, keys, statement, trust };
}
function registerLog({ts, statementBytes, issuerTrust, tenantId, resourceId, padding = 0}) {
  for (let i=0;i<padding;i++) ts.entries.push(Buffer.from(`prior-valid-statement-${ts.issuer}-${i}`));
  return ts.register(statementBytes, issuerTrust, tenantId, resourceId);
}

const results = [];
function check(name, fn) { try { fn(); results.push({name,ok:true}); } catch (e) { results.push({name,ok:false,error:e.message}); } }
function expectReject(fn, pattern = undefined) { let error; try { fn(); } catch(e) { error=e; } assert.ok(error,'expected rejection'); if (pattern) assert.match(error.message,pattern); }

const fx = makeFixture('tenant-a','pump-17',41);
const signed = fx.statement.bytes;
const decodedStatement = parseCoseSign1(signed);
const receiptTsA = makeTransparencyService({issuer:'https://ts-a.example',logId:'log-a',kid:Buffer.from('ts-a-v1'),keyPair:keyPair('ts-a')});
const receiptTsB = makeTransparencyService({issuer:'https://ts-b.example',logId:'log-b',kid:Buffer.from('ts-b-v1'),keyPair:keyPair('ts-b')});
const transparencyTrust = new Map([
  [receiptTsA.issuer,{logId:receiptTsA.logId,kid:receiptTsA.kid,publicKey:receiptTsA.keys.publicKey}],
  [receiptTsB.issuer,{logId:receiptTsB.logId,kid:receiptTsB.kid,publicKey:receiptTsB.keys.publicKey}],
]);
let receiptA, receiptB, transparent;

check('CBOR deterministic map ordering and round-trip', () => {
  const map1 = new Map([['z',1],['a',2],['m',3]]), map2 = new Map([['m',3],['z',1],['a',2]]);
  assert.ok(encodeCbor(map1).equals(encodeCbor(map2)));
  assert.deepEqual([...decodeCbor(encodeCbor(map1)).entries()], [['a',2],['m',3],['z',1]]);
});
check('COSE_Sign1 statement is tagged with CBOR tag 18', () => { const d=decodeCbor(signed); assert.equal(d.tag,18); assert.equal(d.value.length,4); });
check('SCITT protected header carries EdDSA, content type, kid and CWT iss/sub', () => {
  const h=decodedStatement.protectedMap; assert.equal(mapGet(h,1),-8); assert.equal(mapGet(h,3),CONTENT_TYPE);
  assert.ok(mapGet(h,4).equals(fx.kid)); const c=mapGet(h,15); assert.equal(mapGet(c,1),fx.issuer); assert.equal(mapGet(c,2),fx.subject);
});
check('valid tenant-bound signed action statement verifies', () => {
  const v=verifyActionStatement(signed,fx.trust,'tenant-a','pump-17'); assert.equal(v.evidence.operationId,'op-tenant-a-41'); assert.equal(v.evidence.aggregateSequence,41);
});
check('payload mutation is rejected', () => {
  const a=decodedStatement.envelope.slice(); a[2]=Buffer.from(decodedStatement.payload); a[2][a[2].length-1]^=1;
  const bad=encodeCbor({tag:18,value:a}); expectReject(()=>verifyActionStatement(bad,fx.trust,'tenant-a','pump-17'));
});
check('protected-header mutation is rejected', () => {
  const h=new Map(decodedStatement.protectedMap); h.set(3,'application/json');
  const bad=encodeCbor({tag:18,value:[encodeCbor(h),decodedStatement.unprotected,decodedStatement.payload,decodedStatement.signature]});
  expectReject(()=>verifyActionStatement(bad,fx.trust,'tenant-a','pump-17'),/signature|content type/);
});
check('signature mutation is rejected', () => {
  const a=decodedStatement.envelope.slice(); a[3]=Buffer.from(a[3]); a[3][0]^=0x80;
  expectReject(()=>verifyActionStatement(encodeCbor({tag:18,value:a}),fx.trust,'tenant-a','pump-17'));
});
check('cross-tenant verifier substitution is rejected', () => expectReject(()=>verifyActionStatement(signed,fx.trust,'tenant-b','pump-17'),/tenant/));
check('cross-resource subject substitution is rejected', () => expectReject(()=>verifyActionStatement(signed,fx.trust,'tenant-a','pump-18'),/subject/));
check('unknown issuer or key id is rejected', () => {
  const emptyTrust=new Map(); expectReject(()=>verifyActionStatement(signed,emptyTrust,'tenant-a','pump-17'),/not trusted/);
  const wrongKid=new Map([[fx.issuer,{tenantId:'tenant-a',kid:Buffer.from('wrong'),publicKey:fx.keys.publicKey}]]);
  expectReject(()=>verifyActionStatement(signed,wrongKid,'tenant-a','pump-17'),/not trusted/);
});
check('statement embeds explicit aggregate sequence rather than relying on log order', () => {
  const v=verifyActionStatement(signed,fx.trust,'tenant-a','pump-17'); assert.equal(v.evidence.aggregateSequence,41);
});
check('Transparency Service refuses a statement with invalid issuer signature', () => {
  const bad=decodedStatement.envelope.slice(); bad[3]=Buffer.alloc(64,0);
  expectReject(()=>receiptTsA.register(encodeCbor({tag:18,value:bad}),fx.trust,'tenant-a','pump-17'));
});
check('TS A issues an RFC 9942 detached-payload inclusion receipt', () => {
  receiptA=registerLog({ts:receiptTsA,statementBytes:signed,issuerTrust:fx.trust,tenantId:'tenant-a',resourceId:'pump-17',padding:2});
  const d=parseCoseSign1(receiptA); assert.equal(d.payload,null); assert.equal(mapGet(d.protectedMap,395),1);
  const c=mapGet(d.protectedMap,15); assert.equal(mapGet(c,1),receiptTsA.issuer); assert.equal(mapGet(c,2),receiptTsA.logId);
  assert.ok(mapGet(d.protectedMap,4).equals(receiptTsA.kid));
  const v=verifyInclusionReceipt(receiptA,signed,transparencyTrust); assert.equal(v.treeSize,3); assert.equal(v.leafIndex,2);
});
check('TS B independently issues a second inclusion receipt for same statement', () => {
  receiptB=registerLog({ts:receiptTsB,statementBytes:signed,issuerTrust:fx.trust,tenantId:'tenant-a',resourceId:'pump-17',padding:4});
  const v=verifyInclusionReceipt(receiptB,signed,transparencyTrust); assert.equal(v.treeSize,5); assert.equal(v.leafIndex,4);
});
check('receipt signature is bound to the trusted Transparency Service identity', () => {
  const wrong=new Map([[receiptTsA.issuer,{logId:receiptTsA.logId,kid:receiptTsA.kid,publicKey:receiptTsB.keys.publicKey}]]);
  expectReject(()=>verifyInclusionReceipt(receiptA,signed,wrong));
});
check('receipt proof tampering is rejected despite valid signature over root', () => {
  const p=parseCoseSign1(receiptA), vdp=mapGet(p.unprotected,396), proofList=mapGet(vdp,-1);
  const proof=decodeCbor(proofList[0]); proof[1]=0;
  const mutatedVdp=new Map([[396,new Map([[-1,[encodeCbor(proof)]]])]]);
  const tampered=encodeCbor({tag:18,value:[p.protectedBytes,mutatedVdp,null,p.signature]});
  expectReject(()=>verifyInclusionReceipt(tampered,signed,transparencyTrust),/signature|inclusion proof/);
});
check('receipt VDS downgrade/substitution is rejected', () => {
  const p=parseCoseSign1(receiptA), h=new Map(p.protectedMap); h.set(395,2);
  const bad=encodeCbor({tag:18,value:[encodeCbor(h),p.unprotected,null,p.signature]});
  expectReject(()=>verifyInclusionReceipt(bad,signed,transparencyTrust),/VDS/);
});
check('transparent statement attaches two independently signed receipts and verifies', () => {
  transparent=makeTransparentStatement(signed,[receiptA,receiptB]);
  const v=verifyTransparentStatement(transparent,fx.trust,transparencyTrust,'tenant-a','pump-17',2);
  assert.equal(v.receipts.length,2); assert.equal(new Set(v.receipts.map(x=>x.issuer)).size,2);
});
check('transparent statement requiring two distinct services rejects one receipt', () => {
  const one=makeTransparentStatement(signed,[receiptA]);
  expectReject(()=>verifyTransparentStatement(one,fx.trust,transparencyTrust,'tenant-a','pump-17',2),/insufficient/);
});
check('duplicate receipts from one TS do not satisfy two-service policy', () => {
  const dup=makeTransparentStatement(signed,[receiptA,receiptA]);
  expectReject(()=>verifyTransparentStatement(dup,fx.trust,transparencyTrust,'tenant-a','pump-17',2),/distinct/);
});
check('unprotected receipt attachment does not change original issuer signature', () => {
  const t=parseCoseSign1(transparent);
  const base=encodeCbor({tag:18,value:[t.protectedBytes,new Map(),t.payload,t.signature]});
  verifyActionStatement(base,fx.trust,'tenant-a','pump-17');
});
check('signed statement with detached payload verifies only with supplied payload', () => {
  const detached=makeCoseSign1({protectedMap:decodedStatement.protectedMap,unprotectedMap:new Map(),payload:decodedStatement.payload,detached:true,privateKey:fx.keys.privateKey});
  expectReject(()=>verifyCoseSign1(detached,fx.keys.publicKey));
  const v=verifyCoseSign1(detached,fx.keys.publicKey,decodedStatement.payload); assert.ok(v.verifiedPayload.equals(decodedStatement.payload));
});
check('non-deterministic CBOR action payload is rejected even with a valid issuer signature', () => {
  const payloadMap=decodeCbor(decodedStatement.payload);
  const reversed=[...payloadMap.entries()].reverse();
  const raw=Buffer.concat([head(5,reversed.length),...reversed.flatMap(([k,v])=>[encodeCbor(k),encodeCbor(v)])]);
  const bad=makeCoseSign1({protectedMap:decodedStatement.protectedMap,unprotectedMap:new Map(),payload:raw,privateKey:fx.keys.privateKey});
  expectReject(()=>verifyActionStatement(bad,fx.trust,'tenant-a','pump-17'),/deterministic CBOR/);
});
check('non-deterministic protected header is rejected', () => {
  const entries=[...decodedStatement.protectedMap.entries()].reverse();
  const raw=Buffer.concat([head(5,entries.length),...entries.flatMap(([k,v])=>[encodeCbor(k),encodeCbor(v)])]);
  const signature=cryptoSign(null,makeSigStructure(raw,decodedStatement.payload),fx.keys.privateKey);
  const bad=encodeCbor({tag:18,value:[raw,new Map(),decodedStatement.payload,signature]});
  expectReject(()=>verifyActionStatement(bad,fx.trust,'tenant-a','pump-17'),/deterministic CBOR/);
});
check('Transparency Service requires empty unprotected header before registration', () => {
  const withUnprotected=encodeCbor({tag:18,value:[decodedStatement.protectedBytes,new Map([[999,'unexpected']]),decodedStatement.payload,decodedStatement.signature]});
  expectReject(()=>receiptTsA.register(withUnprotected,fx.trust,'tenant-a','pump-17'),/unprotected header must be empty/);
});
check('transparency receipt is rejected when protected key id does not match the trusted TS key', () => {
  const p=parseCoseSign1(receiptA), h=new Map(p.protectedMap); h.set(4,Buffer.from('other-key'));
  const bad=encodeCbor({tag:18,value:[encodeCbor(h),p.unprotected,null,p.signature]});
  expectReject(()=>verifyInclusionReceipt(bad,signed,transparencyTrust),/identity\/key id/);
});
check('transparency registration authenticates issuer provenance, not real-world truth', () => {
  const claims=Object.fromEntries(decodeCbor(fx.statement.payload).entries());
  claims.sinkReceiptDigest=testDigest('invented-nonexistent-sink-receipt');
  claims.postconditionReadbackDigest=testDigest('fabricated-readback-claim');
  const fabricated=makeStatement({tenantId:fx.tenantId,resourceId:fx.resourceId,issuer:fx.issuer,subject:fx.subject,kid:fx.kid,keyPair:fx.keys,actionEvidence:claims});
  const receipt=receiptTsA.register(fabricated.bytes,fx.trust,'tenant-a','pump-17');
  assert.ok(verifyInclusionReceipt(receipt,fabricated.bytes,transparencyTrust));
});
check('same action sequence can be independently registered with distinct TS log sequences', () => {
  const a=verifyInclusionReceipt(receiptA,signed,transparencyTrust), b=verifyInclusionReceipt(receiptB,signed,transparencyTrust);
  assert.notEqual(a.treeSize,b.treeSize); assert.equal(a.issuer!==b.issuer,true);
});

const benchCount = 600;
const benchStart = performance.now();
for (let i = 0; i < benchCount; i += 1) {
  const evidence = { ...Object.fromEntries(decodeCbor(fx.statement.payload).entries()), operationId: `bench-op-${i}`, aggregateSequence: 1000 + i };
  const statement = makeStatement({ tenantId: fx.tenantId, resourceId: fx.resourceId, issuer: fx.issuer, subject: fx.subject, kid: fx.kid, keyPair: fx.keys, actionEvidence: evidence });
  verifyActionStatement(statement.bytes, fx.trust, fx.tenantId, fx.resourceId);
}
const signVerifyMs = performance.now() - benchStart;
const receiptBenchStart = performance.now();
for (let i = 0; i < benchCount; i += 1) verifyInclusionReceipt(receiptA, signed, transparencyTrust);
const receiptVerifyMs = performance.now() - receiptBenchStart;
const benchmark = {
  operationsPerSample: benchCount,
  signedActionCreateAndVerifyOpsPerSecond: Math.round(benchCount / (signVerifyMs / 1000)),
  signedActionCreateAndVerifyElapsedMs: Number(signVerifyMs.toFixed(3)),
  detachedInclusionReceiptVerifyOpsPerSecond: Math.round(benchCount / (receiptVerifyMs / 1000)),
  detachedInclusionReceiptVerifyElapsedMs: Number(receiptVerifyMs.toFixed(3)),
  scope: 'same-process Node.js benchmark; built-in CBOR/Ed25519 and local Merkle proof verification; no network, storage or live TS API',
};

const summary = {
  artifact: 'SFEB MON-006 SCITT-compatible action evidence and COSE receipts v1',
  runtime: process.version,
  tests: results.length,
  passed: results.filter(r=>r.ok).length,
  failed: results.filter(r=>!r.ok).length,
  cbor: 'Deterministic CBOR subset; canonical map ordering by encoded key length then lexicographic bytes; no floats/indefinite-length items',
  statement: 'RFC 9943-shaped tagged COSE_Sign1; EdDSA (-8), content type, kid, protected CWT iss/sub; action payload is CBOR',
  receipt: 'RFC 9942-shaped tagged COSE_Sign1 inclusion receipt; VDS RFC9162_SHA256 (1), VDP inclusion (-1), detached Merkle root payload',
  receipts: 2,
  independentTransparencyServices: 2,
  statementAggregateSequence: 41,
  wireExamples: {
    signedStatementCborHex: hex(signed),
    transparencyReceiptACborHex: hex(receiptA),
    transparencyReceiptBCborHex: hex(receiptB),
    transparentStatementCborHex: hex(transparent),
    signedStatementSha256: hex(sha256(signed)),
    receiptASha256: hex(sha256(receiptA)),
    receiptBSha256: hex(sha256(receiptB)),
    transparentStatementSha256: hex(sha256(transparent)),
  },
  benchmark,
  limitations: [
    'This is a local SCITT message and receipt reference model; no live SCITT Transparency Service API was called.',
    'CBOR encoder/decoder implements a strict subset for the exercised structures and is not a general-purpose RFC 8949 implementation.',
    'RFC 9942 inclusion proof and COSE receipt structure are tested locally but not differentially verified with an independent SCITT/COSE implementation.',
    'Test issuer and Transparency Service keys are deterministic fixtures, not production key custody or trust discovery.',
    'TS instances are in-process mock logs; this does not demonstrate independent administration, network availability, registration policy, key rotation, revocation or gossip.',
    'The signed action payload demonstrates evidence fields; no underlying source receipt, authority service, mutation sink or independent readback is contacted or validated for real-world truth.',
    'The content type is a prototype application media type; a production SFEB SCITT profile/content-type specification and IANA considerations need to be completed.'
  ],
  results
};
console.log(JSON.stringify(summary,null,2));
if (summary.failed !== 0) process.exitCode = 1;
