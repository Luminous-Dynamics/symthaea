# MON-008 Go checkpoint verifier

This is a Go standard-library research reference profile for authenticated checkpoints, trust-root rotation, monotonicity, RFC 9162 tree extensions, and signed witness observations. It depends on the MON-007 RFC 9162 module already present at `../sfeb-mon007/go` relative to the `monitoring` directory.

The source is stored as gzip assets in this research branch. From the repository root, extract the sources with:

```sh
for f in checkpoint/profile.go checkpoint/profile_test.go cmd/checkpoint-vectors/main.go; do
  gzip -dc "benchmarks/frontend/monitoring/sfeb-mon008/go/${f}.gz" > "benchmarks/frontend/monitoring/sfeb-mon008/go/${f}"
done
cd benchmarks/frontend/monitoring/sfeb-mon008/go
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
go test -cover ./...
go test -run '^$' -bench 'BenchmarkVerifyCheckpointWitnessQuorum' -benchmem -count=5 ./checkpoint
```

To regenerate the Go vector, run `go run ./cmd/checkpoint-vectors > ../js/testdata/go-generated-v1.json`. The Go suite verifies the Node-generated fixture in `../js/testdata/node-generated-v1.json`.

The benchmark is only in-process signature, quorum and verifier-state work. It excludes network, durable storage, COSE parsing, transparency service, external sink mutation and readback. `StateSnapshot` is an export format, not a storage engine. The caller must persist it in rollback-resistant storage outside the log operator's administrative domain. This implementation retains the active trust root; historical verification requires a separately retained and validated root-update chain.
