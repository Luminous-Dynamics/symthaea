package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"sfeb-mon008/checkpoint/checkpoint"
)

type fixture struct {
	Schema                    string         `json:"schema"`
	Checkpoint                checkpointJSON `json:"checkpoint"`
	CheckpointPayloadHex      string         `json:"checkpointPayloadHex"`
	CheckpointPublicKeyBase64 string         `json:"checkpointPublicKeyBase64"`
	CheckpointSignatureBase64 string         `json:"checkpointSignatureBase64"`
	Witnesses                 []witnessJSON  `json:"witnesses"`
}
type checkpointJSON struct {
	Version          uint16 `json:"version"`
	TrustRootVersion uint64 `json:"trustRootVersion"`
	LogID            string `json:"logId"`
	TreeSize         uint64 `json:"treeSize"`
	RootHashHex      string `json:"rootHashHex"`
	IssuedAtUnixMS   int64  `json:"issuedAtUnixMs"`
	PolicyVersion    uint64 `json:"policyVersion"`
	PolicyDigestHex  string `json:"policyDigestHex"`
	KeyID            string `json:"keyId"`
}
type witnessJSON struct {
	ID                string `json:"id"`
	FailureDomain     string `json:"failureDomain"`
	ObservedAtUnixMS  int64  `json:"observedAtUnixMs"`
	PublicKeyBase64   string `json:"publicKeyBase64"`
	SignatureBase64   string `json:"signatureBase64"`
	SigningPayloadHex string `json:"signingPayloadHex"`
}

func seed(label string) []byte {
	h := sha256.Sum256([]byte("sfeb-mon008-vector:" + label))
	return h[:]
}
func key(label string) (ed25519.PublicKey, ed25519.PrivateKey) {
	priv := ed25519.NewKeyFromSeed(seed(label))
	return priv.Public().(ed25519.PublicKey), priv
}
func main() {
	logPub, logPriv := key("log-key")
	rootBytes := sha256.Sum256([]byte("mon008 deterministic log root"))
	cp := checkpoint.Checkpoint{Version: checkpoint.ProfileVersion, TrustRootVersion: 1, LogID: "mon008.example.test", TreeSize: 7, RootHash: rootBytes, IssuedAtUnixMS: 1_800_000_000_000, PolicyVersion: 3, PolicyDigest: sha256.Sum256([]byte("mon008 registration policy v3")), KeyID: "log-key-1"}
	signed, err := checkpoint.SignCheckpoint(cp, logPriv)
	must(err)
	payload, err := checkpoint.CanonicalCheckpointBytes(cp)
	must(err)
	digest, err := checkpoint.SignedCheckpointDigest(signed)
	must(err)
	out := fixture{Schema: "sfeb-mon008-checkpoint-v1", Checkpoint: checkpointJSON{cp.Version, cp.TrustRootVersion, cp.LogID, cp.TreeSize, hex.EncodeToString(cp.RootHash[:]), cp.IssuedAtUnixMS, cp.PolicyVersion, hex.EncodeToString(cp.PolicyDigest[:]), cp.KeyID}, CheckpointPayloadHex: hex.EncodeToString(payload), CheckpointPublicKeyBase64: base64.StdEncoding.EncodeToString(logPub), CheckpointSignatureBase64: base64.StdEncoding.EncodeToString(signed.Signature)}
	for _, w := range []struct{ id, domain string }{{"witness-a", "cloud-a"}, {"witness-b", "cloud-b"}} {
		pub, priv := key(w.id)
		observed := time.UnixMilli(cp.IssuedAtUnixMS + 10)
		att, err := checkpoint.SignWitness(signed, w.id, observed, priv)
		must(err)
		wPayload, err := checkpoint.WitnessSigningBytes(cp.LogID, w.id, digest, att.ObservedAtUnixMS)
		must(err)
		out.Witnesses = append(out.Witnesses, witnessJSON{w.id, w.domain, att.ObservedAtUnixMS, base64.StdEncoding.EncodeToString(pub), base64.StdEncoding.EncodeToString(att.Signature), hex.EncodeToString(wPayload)})
	}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	must(enc.Encode(out))
}
func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
