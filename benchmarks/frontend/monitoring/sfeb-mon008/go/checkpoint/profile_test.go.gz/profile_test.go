package checkpoint

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"sync"
	"testing"
	"time"

	"sfeb-mon007/assurance/rfc9162"
)

type fixture struct {
	root           TrustRoot
	logPrivate     ed25519.PrivateKey
	witnessPrivate map[string]ed25519.PrivateKey
	witnessKeys    []WitnessKey
	leaves         [][]byte
	now            time.Time
}

func seed(label string) []byte {
	sum := sha256.Sum256([]byte("sfeb-mon008-test-seed:" + label))
	return sum[:]
}
func makeKey(label string) (ed25519.PublicKey, ed25519.PrivateKey) {
	privateKey := ed25519.NewKeyFromSeed(seed(label))
	return privateKey.Public().(ed25519.PublicKey), privateKey
}

func newFixture(t testing.TB) *fixture {
	t.Helper()
	logPub, logPriv := makeKey("log-v1")
	witnessPrivate := map[string]ed25519.PrivateKey{}
	witnessKeys := []WitnessKey{}
	for _, item := range []struct{ id, domain string }{{"witness-a", "cloud-a"}, {"witness-b", "cloud-b"}, {"witness-c", "cloud-c"}} {
		pub, priv := makeKey(item.id)
		witnessPrivate[item.id] = priv
		witnessKeys = append(witnessKeys, WitnessKey{ID: item.id, FailureDomain: item.domain, PublicKey: pub})
	}
	f := &fixture{root: TrustRoot{LogID: "example-log", Version: 1, IssuedAtUnixMS: 1, Threshold: 1, Keys: []LogKey{{ID: "log-key-1", PublicKey: logPub}}}, logPrivate: logPriv, witnessPrivate: witnessPrivate, witnessKeys: witnessKeys, leaves: [][]byte{[]byte("one"), []byte("two"), []byte("three"), []byte("four"), []byte("five"), []byte("six"), []byte("seven")}, now: time.Unix(1_800_000_000, 0)}
	return f
}

func (f *fixture) config(t testing.TB, threshold uint16) VerifierConfig {
	t.Helper()
	pin := BootstrapPin{LogID: f.root.LogID, TreeSize: 3, RootHash: rfc9162.RootFromLeaves(f.leaves[:3])}
	return VerifierConfig{TrustRoot: f.root, Bootstrap: pin, WitnessKeys: f.witnessKeys, WitnessThreshold: threshold, MaxCheckpointAge: time.Hour, MaxFutureSkew: time.Minute, MaxWitnessAge: time.Hour}
}

func (f *fixture) signed(t testing.TB, size int, at time.Time, keyID string) SignedCheckpoint {
	t.Helper()
	if keyID == "" {
		keyID = "log-key-1"
	}
	cp := Checkpoint{Version: ProfileVersion, TrustRootVersion: f.root.Version, LogID: f.root.LogID, TreeSize: uint64(size), RootHash: rfc9162.RootFromLeaves(f.leaves[:size]), IssuedAtUnixMS: at.UnixMilli(), PolicyVersion: 1, PolicyDigest: sha256.Sum256([]byte("policy-v1")), KeyID: keyID}
	s, err := SignCheckpoint(cp, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	return s
}
func (f *fixture) attestations(t testing.TB, s SignedCheckpoint, at time.Time, ids ...string) []WitnessAttestation {
	t.Helper()
	out := make([]WitnessAttestation, 0, len(ids))
	for _, id := range ids {
		a, err := SignWitness(s, id, at, f.witnessPrivate[id])
		if err != nil {
			t.Fatal(err)
		}
		out = append(out, a)
	}
	return out
}
func (f *fixture) verifier(t testing.TB, threshold uint16) *Verifier {
	t.Helper()
	v, err := NewVerifier(f.config(t, threshold))
	if err != nil {
		t.Fatal(err)
	}
	return v
}

func TestCanonicalCheckpointSigningAndBootstrapPin(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	s := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	state := v.Snapshot()
	if state.Current == nil || state.Current.TreeSize != 3 {
		t.Fatalf("unexpected state: %#v", state)
	}
}

func TestRejectsBadSignatureAndWrongLog(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	s := f.signed(t, 3, f.now, "log-key-1")
	s.Signature[0] ^= 0xff
	if err := v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrInvalidSignature) {
		t.Fatalf("got %v", err)
	}
	cp := f.signed(t, 3, f.now, "log-key-1")
	cp.Checkpoint.LogID = "other-log"
	cp, err := SignCheckpoint(cp.Checkpoint, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	if err = v.Verify(cp, nil, f.attestations(t, cp, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrUnknownLogKey) {
		t.Fatalf("got %v", err)
	}
}

func TestBootstrapMustBeExternallyPinned(t *testing.T) {
	f := newFixture(t)
	cfg := f.config(t, 2)
	cfg.Bootstrap.RootHash = sha256.Sum256([]byte("operator supplied root"))
	v, err := NewVerifier(cfg)
	if err != nil {
		t.Fatal(err)
	}
	s := f.signed(t, 3, f.now, "log-key-1")
	if err = v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrBootstrapMismatch) {
		t.Fatalf("got %v", err)
	}
}

func TestExtensionRequiresValidConsistencyProof(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	first := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(first, nil, f.attestations(t, first, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	second := f.signed(t, 7, f.now.Add(time.Minute), "log-key-1")
	if err := v.Verify(second, nil, f.attestations(t, second, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); !errors.Is(err, ErrConsistencyRequired) {
		t.Fatalf("got %v", err)
	}
	proof, err := rfc9162.ConsistencyProof(f.leaves, 3)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Verify(second, proof, f.attestations(t, second, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
}

func TestRejectsRollbackAndSameSizeFork(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	first := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(first, nil, f.attestations(t, first, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	rolled := f.signed(t, 2, f.now.Add(time.Minute), "log-key-1")
	if err := v.Verify(rolled, nil, f.attestations(t, rolled, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); !errors.Is(err, ErrRollback) {
		t.Fatalf("got %v", err)
	}
	forkLeaves := [][]byte{[]byte("evil-1"), []byte("evil-2"), []byte("evil-3")}
	fork := Checkpoint{Version: 1, LogID: f.root.LogID, TreeSize: 3, RootHash: rfc9162.RootFromLeaves(forkLeaves), IssuedAtUnixMS: f.now.Add(time.Minute).UnixMilli(), PolicyVersion: 1, PolicyDigest: sha256.Sum256([]byte("policy-v1")), KeyID: "log-key-1", TrustRootVersion: 1}
	bad, err := SignCheckpoint(fork, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	if err = v.Verify(bad, nil, f.attestations(t, bad, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); !errors.Is(err, ErrSplitView) {
		t.Fatalf("got %v", err)
	}
}

func TestWitnessThresholdCountsFailureDomainsNotKeys(t *testing.T) {
	f := newFixture(t)
	f.witnessKeys[1].FailureDomain = f.witnessKeys[0].FailureDomain
	cfg := f.config(t, 2)
	cfg.WitnessKeys = f.witnessKeys
	v, err := NewVerifier(cfg)
	if err != nil {
		t.Fatal(err)
	}
	s := f.signed(t, 3, f.now, "log-key-1")
	if err = v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrWitnessThreshold) {
		t.Fatalf("same domain should not count twice: %v", err)
	}
	if err = v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-c"), f.now); err != nil {
		t.Fatal(err)
	}
}

func TestWitnessSignaturesBindExactSignedCheckpoint(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	s := f.signed(t, 3, f.now, "log-key-1")
	atts := f.attestations(t, s, f.now, "witness-a", "witness-b")
	s.Checkpoint.PolicyVersion = 2
	s, err := SignCheckpoint(s.Checkpoint, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	if err = v.Verify(s, nil, atts, f.now); !errors.Is(err, ErrWitnessInvalid) {
		t.Fatalf("got %v", err)
	}
}

func TestRejectsStaleFutureAndKeyValidity(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	stale := f.signed(t, 3, f.now.Add(-2*time.Hour), "log-key-1")
	if err := v.Verify(stale, nil, f.attestations(t, stale, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrStaleCheckpoint) {
		t.Fatalf("got %v", err)
	}
	future := f.signed(t, 3, f.now.Add(2*time.Minute), "log-key-1")
	if err := v.Verify(future, nil, f.attestations(t, future, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrFutureCheckpoint) {
		t.Fatalf("got %v", err)
	}
	f.root.Keys[0].NotAfterMS = f.now.Add(-time.Minute).UnixMilli()
	v2 := f.verifier(t, 2)
	validity := f.signed(t, 3, f.now, "log-key-1")
	if err := v2.Verify(validity, nil, f.attestations(t, validity, f.now, "witness-a", "witness-b"), f.now); !errors.Is(err, ErrKeyOutsideValidity) {
		t.Fatalf("got %v", err)
	}
}

func TestRootRotationRequiresOldAndNewThresholdsAndSequentialDigest(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	newPub, newPriv := makeKey("log-v2")
	next := TrustRoot{LogID: f.root.LogID, Version: 2, PreviousDigest: mustDigest(t, f.root), IssuedAtUnixMS: f.now.Add(time.Hour).UnixMilli(), Threshold: 1, Keys: []LogKey{{ID: "log-key-2", PublicKey: newPub}}}
	update, err := SignRootUpdate(next, map[string]ed25519.PrivateKey{"log-key-1": f.logPrivate}, map[string]ed25519.PrivateKey{"log-key-2": newPriv})
	if err != nil {
		t.Fatal(err)
	}
	if err = v.ApplyRootUpdate(update); err != nil {
		t.Fatal(err)
	}
	newCP := Checkpoint{Version: 1, TrustRootVersion: 2, LogID: f.root.LogID, TreeSize: 3, RootHash: rfc9162.RootFromLeaves(f.leaves[:3]), IssuedAtUnixMS: f.now.Add(2 * time.Hour).UnixMilli(), PolicyVersion: 1, PolicyDigest: sha256.Sum256([]byte("policy-v1")), KeyID: "log-key-2"}
	newSigned, err := SignCheckpoint(newCP, newPriv)
	if err != nil {
		t.Fatal(err)
	}
	atts := []WitnessAttestation{}
	for _, id := range []string{"witness-a", "witness-b"} {
		a, e := SignWitness(newSigned, id, f.now.Add(2*time.Hour), f.witnessPrivate[id])
		if e != nil {
			t.Fatal(e)
		}
		atts = append(atts, a)
	}
	if err = v.Verify(newSigned, nil, atts, f.now.Add(2*time.Hour)); err != nil {
		t.Fatal(err)
	}
	badNext := next
	badNext.Version = 4
	badUpdate, _ := SignRootUpdate(badNext, map[string]ed25519.PrivateKey{"log-key-1": f.logPrivate}, map[string]ed25519.PrivateKey{"log-key-2": newPriv})
	if err = v.ApplyRootUpdate(badUpdate); !errors.Is(err, ErrInvalidRotation) {
		t.Fatalf("got %v", err)
	}
}

func TestRootRotationFailsWithoutEitherSignatureThreshold(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	newPub, newPriv := makeKey("log-v2")
	next := TrustRoot{LogID: f.root.LogID, Version: 2, PreviousDigest: mustDigest(t, f.root), IssuedAtUnixMS: f.now.Add(time.Hour).UnixMilli(), Threshold: 1, Keys: []LogKey{{ID: "log-key-2", PublicKey: newPub}}}
	oldMissing, _ := SignRootUpdate(next, nil, map[string]ed25519.PrivateKey{"log-key-2": newPriv})
	if err := v.ApplyRootUpdate(oldMissing); !errors.Is(err, ErrRotationThreshold) {
		t.Fatalf("got %v", err)
	}
	newMissing, _ := SignRootUpdate(next, map[string]ed25519.PrivateKey{"log-key-1": f.logPrivate}, nil)
	if err := v.ApplyRootUpdate(newMissing); !errors.Is(err, ErrRotationThreshold) {
		t.Fatalf("got %v", err)
	}
}

func TestSnapshotRestoreBindsLogAndTrustRoot(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	s := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(s, nil, f.attestations(t, s, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	snap := v.Snapshot()
	restored := f.verifier(t, 2)
	if err := restored.RestoreSnapshot(snap); err != nil {
		t.Fatal(err)
	}
	if restored.Snapshot().Current.TreeSize != 3 {
		t.Fatal("snapshot not restored")
	}
	foreign := snap
	foreign.LogID = "other-log"
	if err := restored.RestoreSnapshot(foreign); !errors.Is(err, ErrStateLogMismatch) {
		t.Fatalf("got %v", err)
	}
}

func TestConcurrentSnapshotsAndCheckpointReads(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	s := f.signed(t, 3, f.now, "log-key-1")
	atts := f.attestations(t, s, f.now, "witness-a", "witness-b")
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				_ = v.Snapshot()
			}
		}()
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		if err := v.Verify(s, nil, atts, f.now); err != nil {
			t.Error(err)
		}
	}()
	wg.Wait()
}

func mustDigest(t testing.TB, root TrustRoot) [32]byte {
	t.Helper()
	d, err := TrustRootDigest(root)
	if err != nil {
		t.Fatal(err)
	}
	return d
}

func TestReasonCodesAreStable(t *testing.T) {
	if got := ExplainError(fmt.Errorf("wrap: %w", ErrSplitView)); got != "checkpoint:split-view" {
		t.Fatalf("got %q", got)
	}
}

func TestOlderWitnessViewNeedsItsOwnConsistencyProof(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 1)
	first := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(first, nil, f.attestations(t, first, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	second := f.signed(t, 5, f.now.Add(time.Minute), "log-key-1")
	proof3to5, err := rfc9162.ConsistencyProof(f.leaves[:5], 3)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Verify(second, proof3to5, f.attestations(t, second, f.now.Add(time.Minute), "witness-a"), f.now.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	third := f.signed(t, 7, f.now.Add(2*time.Minute), "log-key-1")
	proof5to7, err := rfc9162.ConsistencyProof(f.leaves, 5)
	if err != nil {
		t.Fatal(err)
	}
	atts := f.attestations(t, third, f.now.Add(2*time.Minute), "witness-a", "witness-b")
	if err := v.Verify(third, proof5to7, atts, f.now.Add(2*time.Minute)); !errors.Is(err, ErrWitnessConsistency) {
		t.Fatalf("older witness view without proof should fail, got %v", err)
	}
	proof3to7, err := rfc9162.ConsistencyProof(f.leaves, 3)
	if err != nil {
		t.Fatal(err)
	}
	atts[1].ConsistencyProof = proof3to7
	if err := v.Verify(third, proof5to7, atts, f.now.Add(2*time.Minute)); err != nil {
		t.Fatal(err)
	}
}

func TestRegistrationPolicyVersionCannotRollBack(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	firstCP := f.signed(t, 3, f.now, "log-key-1").Checkpoint
	firstCP.PolicyVersion = 2
	firstCP.PolicyDigest = sha256.Sum256([]byte("policy-v2"))
	first, err := SignCheckpoint(firstCP, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Verify(first, nil, f.attestations(t, first, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	secondCP := f.signed(t, 7, f.now.Add(time.Minute), "log-key-1").Checkpoint
	secondCP.PolicyVersion = 1
	secondCP.PolicyDigest = sha256.Sum256([]byte("policy-v1"))
	second, err := SignCheckpoint(secondCP, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	proof, err := rfc9162.ConsistencyProof(f.leaves, 3)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Verify(second, proof, f.attestations(t, second, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); !errors.Is(err, ErrPolicyRollback) {
		t.Fatalf("got %v", err)
	}
}

type nodeVector struct {
	Schema     string `json:"schema"`
	Checkpoint struct {
		Version          uint16 `json:"version"`
		LogID            string `json:"logId"`
		TreeSize         uint64 `json:"treeSize"`
		RootHashHex      string `json:"rootHashHex"`
		IssuedAtUnixMS   int64  `json:"issuedAtUnixMs"`
		PolicyVersion    uint64 `json:"policyVersion"`
		PolicyDigestHex  string `json:"policyDigestHex"`
		TrustRootVersion uint64 `json:"trustRootVersion"`
		KeyID            string `json:"keyId"`
	} `json:"checkpoint"`
	CheckpointPayloadHex      string `json:"checkpointPayloadHex"`
	CheckpointPublicKeyBase64 string `json:"checkpointPublicKeyBase64"`
	CheckpointSignatureBase64 string `json:"checkpointSignatureBase64"`
	Witnesses                 []struct {
		ID                string `json:"id"`
		FailureDomain     string `json:"failureDomain"`
		ObservedAtUnixMS  int64  `json:"observedAtUnixMs"`
		PublicKeyBase64   string `json:"publicKeyBase64"`
		SignatureBase64   string `json:"signatureBase64"`
		SigningPayloadHex string `json:"signingPayloadHex"`
	} `json:"witnesses"`
}

func TestGoIndependentlyVerifiesNodeGeneratedCheckpointAndWitnessVectors(t *testing.T) {
	data, err := os.ReadFile("../../js/testdata/node-generated-v1.json")
	if err != nil {
		t.Fatal(err)
	}
	var vector nodeVector
	if err := json.Unmarshal(data, &vector); err != nil {
		t.Fatal(err)
	}
	if vector.Schema != "sfeb-mon008-checkpoint-v1" {
		t.Fatalf("unexpected schema %q", vector.Schema)
	}
	rootBytes, err := hex.DecodeString(vector.Checkpoint.RootHashHex)
	if err != nil || len(rootBytes) != 32 {
		t.Fatal("invalid root hash")
	}
	var rootHash rfc9162.Hash
	copy(rootHash[:], rootBytes)
	policyDigestBytes, err := hex.DecodeString(vector.Checkpoint.PolicyDigestHex)
	if err != nil || len(policyDigestBytes) != 32 {
		t.Fatal("invalid policy digest")
	}
	var policyDigest [32]byte
	copy(policyDigest[:], policyDigestBytes)
	cp := Checkpoint{Version: vector.Checkpoint.Version, TrustRootVersion: vector.Checkpoint.TrustRootVersion, LogID: vector.Checkpoint.LogID, TreeSize: vector.Checkpoint.TreeSize, RootHash: rootHash, IssuedAtUnixMS: vector.Checkpoint.IssuedAtUnixMS, PolicyVersion: vector.Checkpoint.PolicyVersion, PolicyDigest: policyDigest, KeyID: vector.Checkpoint.KeyID}
	payload, err := CanonicalCheckpointBytes(cp)
	if err != nil {
		t.Fatal(err)
	}
	if hex.EncodeToString(payload) != vector.CheckpointPayloadHex {
		t.Fatal("Go/Node checkpoint canonical bytes differ")
	}
	pubBytes, err := base64.StdEncoding.DecodeString(vector.CheckpointPublicKeyBase64)
	if err != nil || len(pubBytes) != ed25519.PublicKeySize {
		t.Fatal("invalid Node public key")
	}
	sig, err := base64.StdEncoding.DecodeString(vector.CheckpointSignatureBase64)
	if err != nil || !ed25519.Verify(ed25519.PublicKey(pubBytes), payload, sig) {
		t.Fatal("Node checkpoint signature did not verify in Go")
	}
	signed := SignedCheckpoint{Checkpoint: cp, Signature: sig}
	digest, err := SignedCheckpointDigest(signed)
	if err != nil {
		t.Fatal(err)
	}
	witnessKeys := make([]WitnessKey, 0, len(vector.Witnesses))
	attestations := make([]WitnessAttestation, 0, len(vector.Witnesses))
	for _, witness := range vector.Witnesses {
		wPub, e := base64.StdEncoding.DecodeString(witness.PublicKeyBase64)
		if e != nil || len(wPub) != ed25519.PublicKeySize {
			t.Fatal("invalid witness key")
		}
		wSig, e := base64.StdEncoding.DecodeString(witness.SignatureBase64)
		if e != nil {
			t.Fatal(e)
		}
		wPayload, e := WitnessSigningBytes(cp.LogID, witness.ID, digest, witness.ObservedAtUnixMS)
		if e != nil {
			t.Fatal(e)
		}
		if hex.EncodeToString(wPayload) != witness.SigningPayloadHex || !ed25519.Verify(ed25519.PublicKey(wPub), wPayload, wSig) {
			t.Fatalf("Node witness %q failed Go verification", witness.ID)
		}
		witnessKeys = append(witnessKeys, WitnessKey{ID: witness.ID, FailureDomain: witness.FailureDomain, PublicKey: ed25519.PublicKey(wPub)})
		attestations = append(attestations, WitnessAttestation{WitnessID: witness.ID, ObservedAtUnixMS: witness.ObservedAtUnixMS, Signature: wSig})
	}
	rootKey := ed25519.PublicKey(pubBytes)
	root := TrustRoot{LogID: cp.LogID, Version: 1, IssuedAtUnixMS: 1, Threshold: 1, Keys: []LogKey{{ID: cp.KeyID, PublicKey: rootKey}}}
	v, err := NewVerifier(VerifierConfig{TrustRoot: root, Bootstrap: BootstrapPin{LogID: cp.LogID, TreeSize: cp.TreeSize, RootHash: cp.RootHash}, WitnessKeys: witnessKeys, WitnessThreshold: 2, MaxCheckpointAge: time.Hour, MaxFutureSkew: time.Hour, MaxWitnessAge: time.Hour})
	if err != nil {
		t.Fatal(err)
	}
	now := time.UnixMilli(cp.IssuedAtUnixMS + 30)
	if err := v.Verify(signed, nil, attestations, now); err != nil {
		t.Fatal(err)
	}
}

func TestCompareSnapshotsDetectsSplitViewsAndAcceptsProvedPrefix(t *testing.T) {
	f := newFixture(t)
	oldVerifier := f.verifier(t, 2)
	oldCP := f.signed(t, 3, f.now, "log-key-1")
	if err := oldVerifier.Verify(oldCP, nil, f.attestations(t, oldCP, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	oldSnapshot := oldVerifier.Snapshot()

	newVerifier := f.verifier(t, 2)
	if err := newVerifier.Verify(oldCP, nil, f.attestations(t, oldCP, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	newCP := f.signed(t, 7, f.now.Add(time.Minute), "log-key-1")
	proof := mustConsistencyProof(t, f.leaves, 3)
	if err := newVerifier.Verify(newCP, proof, f.attestations(t, newCP, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	newSnapshot := newVerifier.Snapshot()
	if err := CompareSnapshots(oldSnapshot, newSnapshot, proof); err != nil {
		t.Fatal(err)
	}
	if err := CompareSnapshots(oldSnapshot, newSnapshot, nil); !errors.Is(err, ErrConsistencyRequired) {
		t.Fatalf("got %v", err)
	}

	fork := newSnapshot
	fork.Current = &CheckpointState{TreeSize: oldSnapshot.Current.TreeSize, RootHash: sha256.Sum256([]byte("fork")), IssuedAtUnixMS: oldSnapshot.Current.IssuedAtUnixMS, PolicyVersion: oldSnapshot.Current.PolicyVersion, PolicyDigest: oldSnapshot.Current.PolicyDigest}
	if err := CompareSnapshots(oldSnapshot, fork, nil); !errors.Is(err, ErrSplitView) {
		t.Fatalf("got %v", err)
	}
}

func TestEqualPolicyVersionCannotNameTwoPolicyDigests(t *testing.T) {
	f := newFixture(t)
	v := f.verifier(t, 2)
	first := f.signed(t, 3, f.now, "log-key-1")
	if err := v.Verify(first, nil, f.attestations(t, first, f.now, "witness-a", "witness-b"), f.now); err != nil {
		t.Fatal(err)
	}
	secondCP := first.Checkpoint
	secondCP.IssuedAtUnixMS = f.now.Add(time.Minute).UnixMilli()
	secondCP.PolicyDigest = sha256.Sum256([]byte("substituted same-version policy"))
	second, err := SignCheckpoint(secondCP, f.logPrivate)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Verify(second, nil, f.attestations(t, second, f.now.Add(time.Minute), "witness-a", "witness-b"), f.now.Add(time.Minute)); !errors.Is(err, ErrPolicyFork) {
		t.Fatalf("got %v", err)
	}
}

func mustConsistencyProof(t testing.TB, leaves [][]byte, first uint64) []rfc9162.Hash {
	t.Helper()
	proof, err := rfc9162.ConsistencyProof(leaves, first)
	if err != nil {
		t.Fatal(err)
	}
	return proof
}

func BenchmarkVerifyCheckpointWitnessQuorum(b *testing.B) {
	for _, witnessCount := range []int{1, 2, 3} {
		b.Run(fmt.Sprintf("witnesses-%d", witnessCount), func(b *testing.B) {
			f := newFixture(b)
			v := f.verifier(b, uint16(witnessCount))
			s := f.signed(b, 3, f.now, "log-key-1")
			ids := []string{"witness-a", "witness-b", "witness-c"}[:witnessCount]
			atts := f.attestations(b, s, f.now, ids...)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if err := v.Verify(s, nil, atts, f.now); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
