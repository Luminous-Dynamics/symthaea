// Package checkpoint implements an executable MON-008 reference profile for
// authenticated transparency checkpoints. The signed binary profile is a
// research fixture, NOT a COSE/RFC 9942 wire encoding. Production adapters
// should map RFC 9942 COSE receipt payloads into these verified semantics.
package checkpoint

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"sfeb-mon007/assurance/rfc9162"
)

const (
	ProfileVersion      uint16 = 1
	checkpointDomain           = "LUMINOUS-SFEB-CHECKPOINT\x00V1\x00"
	rootDomain                 = "LUMINOUS-SFEB-TRUST-ROOT\x00V1\x00"
	rootSignatureDomain        = "LUMINOUS-SFEB-TRUST-ROOT-SIGNATURE\x00V1\x00"
	witnessDomain              = "LUMINOUS-SFEB-WITNESS\x00V1\x00"
)

var (
	ErrInvalidProfile            = errors.New("invalid checkpoint profile")
	ErrUnknownLogKey             = errors.New("checkpoint signing key is not trusted")
	ErrKeyOutsideValidity        = errors.New("checkpoint signing key is outside its validity interval")
	ErrInvalidSignature          = errors.New("checkpoint signature is invalid")
	ErrInvalidRoot               = errors.New("invalid trust root")
	ErrInvalidRotation           = errors.New("invalid trust-root rotation")
	ErrRotationThreshold         = errors.New("trust-root rotation threshold not met")
	ErrRollback                  = errors.New("checkpoint tree size rollback")
	ErrSplitView                 = errors.New("conflicting checkpoint at an already observed tree size")
	ErrTimestampRollback         = errors.New("checkpoint timestamp rollback")
	ErrStaleCheckpoint           = errors.New("checkpoint is stale")
	ErrFutureCheckpoint          = errors.New("checkpoint timestamp is too far in the future")
	ErrBootstrapMismatch         = errors.New("checkpoint does not match the externally pinned bootstrap head")
	ErrConsistencyRequired       = errors.New("checkpoint extension requires a consistency proof")
	ErrWitnessThreshold          = errors.New("independent witness failure-domain threshold not met")
	ErrWitnessUnknown            = errors.New("witness is not trusted")
	ErrWitnessDuplicate          = errors.New("duplicate witness identity")
	ErrWitnessInvalid            = errors.New("witness attestation is invalid")
	ErrWitnessReplay             = errors.New("witness observation timestamp rollback")
	ErrWitnessConsistency        = errors.New("witness checkpoint extension requires a consistency proof")
	ErrPolicyRollback            = errors.New("registration policy version rollback")
	ErrPolicyFork                = errors.New("registration policy digest changed without a new version")
	ErrTrustRootVersion          = errors.New("checkpoint trust-root version does not match verifier history")
	ErrCheckpointBeforeTrustRoot = errors.New("checkpoint predates the trust root authorizing it")
	ErrStateLogMismatch          = errors.New("persisted verifier state belongs to another log")
	ErrStateAhead                = errors.New("persisted verifier state is ahead of the supplied checkpoint")
)

// Checkpoint identifies one authenticated view of a transparency log.
// RootHash is an RFC 9162 Merkle Tree Hash. PolicyVersion and PolicyDigest
// bind the checkpoint to a historical policy object; they do not prove that
// policy was substantively correct.
type Checkpoint struct {
	Version          uint16
	TrustRootVersion uint64
	LogID            string
	TreeSize         uint64
	RootHash         rfc9162.Hash
	IssuedAtUnixMS   int64
	PolicyVersion    uint64
	PolicyDigest     [32]byte
	KeyID            string
}

type SignedCheckpoint struct {
	Checkpoint Checkpoint
	Signature  []byte
}

// LogKey is a key authorized by an externally pinned TrustRoot. PublicKey is
// Ed25519 and validity bounds are inclusive Unix milliseconds; zero bounds are
// open-ended.
type LogKey struct {
	ID          string
	PublicKey   ed25519.PublicKey
	NotBeforeMS int64
	NotAfterMS  int64
}

type TrustRoot struct {
	LogID          string
	Version        uint64
	PreviousDigest [32]byte
	IssuedAtUnixMS int64
	Threshold      uint16
	Keys           []LogKey
}

type KeySignature struct {
	KeyID     string
	Signature []byte
}

// RootUpdate is dual-authorized: the previous root's threshold authorizes the
// change, and the next root's threshold proves possession of the new key set.
type RootUpdate struct {
	Next          TrustRoot
	OldSignatures []KeySignature
	NewSignatures []KeySignature
}

type WitnessKey struct {
	ID            string
	FailureDomain string
	PublicKey     ed25519.PublicKey
	NotBeforeMS   int64
	NotAfterMS    int64
}

type WitnessAttestation struct {
	WitnessID        string
	ObservedAtUnixMS int64
	Signature        []byte
	// ConsistencyProof is an auditor-supplied Merkle proof from this witness's previously persisted checkpoint to the current checkpoint. It is not
	// part of the witness signature; the previous endpoint is verifier state.
	ConsistencyProof []rfc9162.Hash
}

type BootstrapPin struct {
	LogID    string
	TreeSize uint64
	RootHash rfc9162.Hash
}

type VerifierConfig struct {
	TrustRoot        TrustRoot
	Bootstrap        BootstrapPin
	WitnessKeys      []WitnessKey
	WitnessThreshold uint16
	MaxCheckpointAge time.Duration
	MaxFutureSkew    time.Duration
	MaxWitnessAge    time.Duration
}

type CheckpointState struct {
	TreeSize       uint64
	RootHash       rfc9162.Hash
	IssuedAtUnixMS int64
	PolicyVersion  uint64
	PolicyDigest   [32]byte
}

type WitnessState struct {
	TreeSize         uint64
	RootHash         rfc9162.Hash
	ObservedAtUnixMS int64
}

// StateSnapshot is intended to be stored in a rollback-resistant store outside
// the transparency operator's control. Restoring an old snapshot weakens
// rollback detection; this package does not claim to provide durable storage.
type StateSnapshot struct {
	LogID       string
	RootVersion uint64
	RootDigest  [32]byte
	Current     *CheckpointState
	Witnesses   map[string]WitnessState
}

type Verifier struct {
	mu               sync.RWMutex
	root             TrustRoot
	witnesses        map[string]WitnessKey
	witnessThreshold uint16
	bootstrap        BootstrapPin
	maxAge           time.Duration
	maxFutureSkew    time.Duration
	maxWitnessAge    time.Duration
	current          *CheckpointState
	witnessState     map[string]WitnessState
}

func appendU16(dst []byte, n uint16) []byte {
	var b [2]byte
	binary.BigEndian.PutUint16(b[:], n)
	return append(dst, b[:]...)
}
func appendU64(dst []byte, n uint64) []byte {
	var b [8]byte
	binary.BigEndian.PutUint64(b[:], n)
	return append(dst, b[:]...)
}
func appendString(dst []byte, value string) ([]byte, error) {
	if value == "" || len(value) > 65535 {
		return nil, ErrInvalidProfile
	}
	dst = appendU16(dst, uint16(len(value)))
	return append(dst, value...), nil
}
func validTimeWindow(notBefore, notAfter, at int64) bool {
	return (notBefore == 0 || at >= notBefore) && (notAfter == 0 || at <= notAfter) && (notBefore == 0 || notAfter == 0 || notBefore <= notAfter)
}

// CanonicalCheckpointBytes returns the exact deterministic bytes signed by a
// log key. All fields are length-delimited or fixed-width and domain-separated.
func CanonicalCheckpointBytes(cp Checkpoint) ([]byte, error) {
	if cp.Version != ProfileVersion || cp.TrustRootVersion == 0 || cp.TreeSize == 0 || cp.IssuedAtUnixMS <= 0 || cp.PolicyVersion == 0 {
		return nil, ErrInvalidProfile
	}
	buf := append([]byte(nil), []byte(checkpointDomain)...)
	buf = appendU16(buf, cp.Version)
	buf = appendU64(buf, cp.TrustRootVersion)
	var err error
	if buf, err = appendString(buf, cp.LogID); err != nil {
		return nil, err
	}
	buf = appendU64(buf, cp.TreeSize)
	buf = append(buf, cp.RootHash[:]...)
	buf = appendU64(buf, uint64(cp.IssuedAtUnixMS))
	buf = appendU64(buf, cp.PolicyVersion)
	buf = append(buf, cp.PolicyDigest[:]...)
	if buf, err = appendString(buf, cp.KeyID); err != nil {
		return nil, err
	}
	return buf, nil
}

func SignCheckpoint(cp Checkpoint, privateKey ed25519.PrivateKey) (SignedCheckpoint, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return SignedCheckpoint{}, ErrInvalidProfile
	}
	payload, err := CanonicalCheckpointBytes(cp)
	if err != nil {
		return SignedCheckpoint{}, err
	}
	return SignedCheckpoint{Checkpoint: cp, Signature: ed25519.Sign(privateKey, payload)}, nil
}

func SignedCheckpointDigest(s SignedCheckpoint) ([32]byte, error) {
	payload, err := CanonicalCheckpointBytes(s.Checkpoint)
	if err != nil {
		return [32]byte{}, err
	}
	if len(s.Signature) != ed25519.SignatureSize {
		return [32]byte{}, ErrInvalidSignature
	}
	buf := append([]byte("LUMINOUS-SFEB-SIGNED-CHECKPOINT\x00V1\x00"), payload...)
	buf = append(buf, s.Signature...)
	return sha256.Sum256(buf), nil
}

func CanonicalTrustRootBytes(root TrustRoot) ([]byte, error) {
	if root.LogID == "" || root.Version == 0 || root.IssuedAtUnixMS <= 0 || root.Threshold == 0 || int(root.Threshold) > len(root.Keys) || len(root.Keys) == 0 || len(root.Keys) > 65535 {
		return nil, ErrInvalidRoot
	}
	keys := append([]LogKey(nil), root.Keys...)
	sort.Slice(keys, func(i, j int) bool { return keys[i].ID < keys[j].ID })
	buf := append([]byte(nil), []byte(rootDomain)...)
	var err error
	if buf, err = appendString(buf, root.LogID); err != nil {
		return nil, ErrInvalidRoot
	}
	buf = appendU64(buf, root.Version)
	buf = append(buf, root.PreviousDigest[:]...)
	buf = appendU64(buf, uint64(root.IssuedAtUnixMS))
	buf = appendU16(buf, root.Threshold)
	buf = appendU16(buf, uint16(len(keys)))
	lastID := ""
	for _, key := range keys {
		if key.ID == "" || key.ID == lastID || len(key.PublicKey) != ed25519.PublicKeySize || !validTimeWindow(key.NotBeforeMS, key.NotAfterMS, root.IssuedAtUnixMS) {
			return nil, ErrInvalidRoot
		}
		lastID = key.ID
		if buf, err = appendString(buf, key.ID); err != nil {
			return nil, ErrInvalidRoot
		}
		buf = append(buf, key.PublicKey...)
		buf = appendU64(buf, uint64(key.NotBeforeMS))
		buf = appendU64(buf, uint64(key.NotAfterMS))
	}
	return buf, nil
}

func TrustRootDigest(root TrustRoot) ([32]byte, error) {
	payload, err := CanonicalTrustRootBytes(root)
	if err != nil {
		return [32]byte{}, err
	}
	return sha256.Sum256(payload), nil
}

func rootSigningBytes(root TrustRoot) ([]byte, error) {
	digest, err := TrustRootDigest(root)
	if err != nil {
		return nil, err
	}
	return append([]byte(rootSignatureDomain), digest[:]...), nil
}

func lookupLogKey(root TrustRoot, id string) (LogKey, bool) {
	for _, key := range root.Keys {
		if key.ID == id {
			return key, true
		}
	}
	return LogKey{}, false
}

func verifyThreshold(signatures []KeySignature, root TrustRoot, payload []byte, at int64) error {
	seen := make(map[string]struct{})
	valid := 0
	for _, sig := range signatures {
		if _, exists := seen[sig.KeyID]; exists {
			continue
		}
		seen[sig.KeyID] = struct{}{}
		key, ok := lookupLogKey(root, sig.KeyID)
		if !ok || !validTimeWindow(key.NotBeforeMS, key.NotAfterMS, at) || !ed25519.Verify(key.PublicKey, payload, sig.Signature) {
			continue
		}
		valid++
	}
	if valid < int(root.Threshold) {
		return ErrRotationThreshold
	}
	return nil
}

func SignRootUpdate(root TrustRoot, oldSigners map[string]ed25519.PrivateKey, newSigners map[string]ed25519.PrivateKey) (RootUpdate, error) {
	payload, err := rootSigningBytes(root)
	if err != nil {
		return RootUpdate{}, err
	}
	update := RootUpdate{Next: root}
	for id, key := range oldSigners {
		if len(key) == ed25519.PrivateKeySize {
			update.OldSignatures = append(update.OldSignatures, KeySignature{KeyID: id, Signature: ed25519.Sign(key, payload)})
		}
	}
	for id, key := range newSigners {
		if len(key) == ed25519.PrivateKeySize {
			update.NewSignatures = append(update.NewSignatures, KeySignature{KeyID: id, Signature: ed25519.Sign(key, payload)})
		}
	}
	sort.Slice(update.OldSignatures, func(i, j int) bool { return update.OldSignatures[i].KeyID < update.OldSignatures[j].KeyID })
	sort.Slice(update.NewSignatures, func(i, j int) bool { return update.NewSignatures[i].KeyID < update.NewSignatures[j].KeyID })
	return update, nil
}

// ApplyRootUpdate enforces sequential, hash-linked, dual-threshold key
// rotation. Callers must persist the resulting root and monotonic state
// atomically in independently controlled storage.
func (v *Verifier) ApplyRootUpdate(update RootUpdate) error {
	v.mu.Lock()
	defer v.mu.Unlock()
	if update.Next.LogID != v.root.LogID || update.Next.Version != v.root.Version+1 || update.Next.IssuedAtUnixMS <= v.root.IssuedAtUnixMS {
		return ErrInvalidRotation
	}
	oldDigest, err := TrustRootDigest(v.root)
	if err != nil {
		return err
	}
	if update.Next.PreviousDigest != oldDigest {
		return ErrInvalidRotation
	}
	payload, err := rootSigningBytes(update.Next)
	if err != nil {
		return err
	}
	if err := verifyThreshold(update.OldSignatures, v.root, payload, update.Next.IssuedAtUnixMS); err != nil {
		return err
	}
	if err := verifyThreshold(update.NewSignatures, update.Next, payload, update.Next.IssuedAtUnixMS); err != nil {
		return err
	}
	v.root = cloneTrustRoot(update.Next)
	return nil
}

func checkpointSigningKey(root TrustRoot, cp Checkpoint) (LogKey, error) {
	if cp.LogID != root.LogID {
		return LogKey{}, ErrUnknownLogKey
	}
	if cp.TrustRootVersion != root.Version {
		return LogKey{}, ErrTrustRootVersion
	}
	if cp.IssuedAtUnixMS < root.IssuedAtUnixMS {
		return LogKey{}, ErrCheckpointBeforeTrustRoot
	}
	key, ok := lookupLogKey(root, cp.KeyID)
	if !ok {
		return LogKey{}, ErrUnknownLogKey
	}
	if !validTimeWindow(key.NotBeforeMS, key.NotAfterMS, cp.IssuedAtUnixMS) {
		return LogKey{}, ErrKeyOutsideValidity
	}
	return key, nil
}

func WitnessSigningBytes(logID, witnessID string, checkpointDigest [32]byte, observedAt int64) ([]byte, error) {
	if logID == "" || witnessID == "" || observedAt <= 0 {
		return nil, ErrWitnessInvalid
	}
	buf := append([]byte(nil), []byte(witnessDomain)...)
	var err error
	if buf, err = appendString(buf, logID); err != nil {
		return nil, err
	}
	if buf, err = appendString(buf, witnessID); err != nil {
		return nil, err
	}
	buf = append(buf, checkpointDigest[:]...)
	buf = appendU64(buf, uint64(observedAt))
	return buf, nil
}

func SignWitness(s SignedCheckpoint, witnessID string, observedAt time.Time, privateKey ed25519.PrivateKey) (WitnessAttestation, error) {
	digest, err := SignedCheckpointDigest(s)
	if err != nil {
		return WitnessAttestation{}, err
	}
	payload, err := WitnessSigningBytes(s.Checkpoint.LogID, witnessID, digest, observedAt.UnixMilli())
	if err != nil {
		return WitnessAttestation{}, err
	}
	if len(privateKey) != ed25519.PrivateKeySize {
		return WitnessAttestation{}, ErrWitnessInvalid
	}
	return WitnessAttestation{WitnessID: witnessID, ObservedAtUnixMS: observedAt.UnixMilli(), Signature: ed25519.Sign(privateKey, payload)}, nil
}

func cloneTrustRoot(root TrustRoot) TrustRoot {
	root.Keys = append([]LogKey(nil), root.Keys...)
	for i := range root.Keys {
		root.Keys[i].PublicKey = append(ed25519.PublicKey(nil), root.Keys[i].PublicKey...)
	}
	return root
}

func NewVerifier(cfg VerifierConfig) (*Verifier, error) {
	if _, err := CanonicalTrustRootBytes(cfg.TrustRoot); err != nil {
		return nil, err
	}
	if cfg.Bootstrap.LogID != cfg.TrustRoot.LogID || cfg.Bootstrap.TreeSize == 0 {
		return nil, ErrBootstrapMismatch
	}
	if cfg.WitnessThreshold == 0 || int(cfg.WitnessThreshold) > len(cfg.WitnessKeys) {
		return nil, ErrWitnessThreshold
	}
	witnesses := make(map[string]WitnessKey, len(cfg.WitnessKeys))
	domains := make(map[string]struct{})
	for _, key := range cfg.WitnessKeys {
		if key.ID == "" || key.FailureDomain == "" || len(key.PublicKey) != ed25519.PublicKeySize || witnesses[key.ID].ID != "" || (key.NotBeforeMS > 0 && key.NotAfterMS > 0 && key.NotBeforeMS > key.NotAfterMS) {
			return nil, ErrWitnessUnknown
		}
		key.PublicKey = append(ed25519.PublicKey(nil), key.PublicKey...)
		witnesses[key.ID] = key
		domains[key.FailureDomain] = struct{}{}
	}
	if len(domains) < int(cfg.WitnessThreshold) {
		return nil, ErrWitnessThreshold
	}
	if cfg.MaxCheckpointAge <= 0 || cfg.MaxFutureSkew < 0 || cfg.MaxWitnessAge <= 0 {
		return nil, ErrInvalidProfile
	}
	return &Verifier{root: cloneTrustRoot(cfg.TrustRoot), witnesses: witnesses, witnessThreshold: cfg.WitnessThreshold, bootstrap: cfg.Bootstrap, maxAge: cfg.MaxCheckpointAge, maxFutureSkew: cfg.MaxFutureSkew, maxWitnessAge: cfg.MaxWitnessAge, witnessState: make(map[string]WitnessState)}, nil
}

func (v *Verifier) Verify(s SignedCheckpoint, consistencyProof []rfc9162.Hash, attestations []WitnessAttestation, now time.Time) error {
	v.mu.Lock()
	defer v.mu.Unlock()
	cp := s.Checkpoint
	payload, err := CanonicalCheckpointBytes(cp)
	if err != nil {
		return err
	}
	key, err := checkpointSigningKey(v.root, cp)
	if err != nil {
		return err
	}
	if len(s.Signature) != ed25519.SignatureSize || !ed25519.Verify(key.PublicKey, payload, s.Signature) {
		return ErrInvalidSignature
	}
	nowMS := now.UnixMilli()
	if cp.IssuedAtUnixMS > nowMS+v.maxFutureSkew.Milliseconds() {
		return ErrFutureCheckpoint
	}
	if nowMS-cp.IssuedAtUnixMS > v.maxAge.Milliseconds() {
		return ErrStaleCheckpoint
	}
	if v.current == nil {
		if cp.LogID != v.bootstrap.LogID || cp.TreeSize != v.bootstrap.TreeSize || cp.RootHash != v.bootstrap.RootHash {
			return ErrBootstrapMismatch
		}
	} else {
		if cp.TreeSize < v.current.TreeSize {
			return ErrRollback
		}
		if cp.IssuedAtUnixMS < v.current.IssuedAtUnixMS {
			return ErrTimestampRollback
		}
		if cp.PolicyVersion < v.current.PolicyVersion {
			return ErrPolicyRollback
		}
		if cp.PolicyVersion == v.current.PolicyVersion && cp.PolicyDigest != v.current.PolicyDigest {
			return ErrPolicyFork
		}
		if cp.TreeSize == v.current.TreeSize && cp.RootHash != v.current.RootHash {
			return ErrSplitView
		}
		if cp.TreeSize > v.current.TreeSize {
			if len(consistencyProof) == 0 {
				return ErrConsistencyRequired
			}
			if err := rfc9162.VerifyConsistency(v.current.TreeSize, cp.TreeSize, v.current.RootHash, cp.RootHash, consistencyProof); err != nil {
				return fmt.Errorf("%w: %v", ErrConsistencyRequired, err)
			}
		}
	}

	digest, err := SignedCheckpointDigest(s)
	if err != nil {
		return err
	}
	seenIDs := make(map[string]struct{})
	seenDomains := make(map[string]struct{})
	validWitnesses := make([]WitnessAttestation, 0, len(attestations))
	for _, att := range attestations {
		if _, exists := seenIDs[att.WitnessID]; exists {
			return ErrWitnessDuplicate
		}
		seenIDs[att.WitnessID] = struct{}{}
		trusted, ok := v.witnesses[att.WitnessID]
		if !ok || !validTimeWindow(trusted.NotBeforeMS, trusted.NotAfterMS, att.ObservedAtUnixMS) {
			return ErrWitnessUnknown
		}
		if att.ObservedAtUnixMS < cp.IssuedAtUnixMS || att.ObservedAtUnixMS > nowMS+v.maxFutureSkew.Milliseconds() || nowMS-att.ObservedAtUnixMS > v.maxWitnessAge.Milliseconds() {
			return ErrWitnessReplay
		}
		if prior, ok := v.witnessState[att.WitnessID]; ok {
			if cp.TreeSize < prior.TreeSize {
				return ErrRollback
			}
			if cp.TreeSize == prior.TreeSize && cp.RootHash != prior.RootHash {
				return ErrSplitView
			}
			if att.ObservedAtUnixMS < prior.ObservedAtUnixMS {
				return ErrWitnessReplay
			}
			if cp.TreeSize > prior.TreeSize {
				// A witness last seen at the verifier's current head is already
				// covered by the global consistency proof above. Older witness
				// views need their own continuity proof to the new head.
				coveredByGlobal := v.current != nil && prior.TreeSize == v.current.TreeSize && prior.RootHash == v.current.RootHash
				if !coveredByGlobal {
					if len(att.ConsistencyProof) == 0 {
						return ErrWitnessConsistency
					}
					if err := rfc9162.VerifyConsistency(prior.TreeSize, cp.TreeSize, prior.RootHash, cp.RootHash, att.ConsistencyProof); err != nil {
						return fmt.Errorf("%w: %v", ErrWitnessConsistency, err)
					}
				}
			}
		}
		witnessPayload, e := WitnessSigningBytes(cp.LogID, att.WitnessID, digest, att.ObservedAtUnixMS)
		if e != nil || len(att.Signature) != ed25519.SignatureSize || !ed25519.Verify(trusted.PublicKey, witnessPayload, att.Signature) {
			return ErrWitnessInvalid
		}
		validWitnesses = append(validWitnesses, att)
		seenDomains[trusted.FailureDomain] = struct{}{}
	}
	if len(seenDomains) < int(v.witnessThreshold) {
		return ErrWitnessThreshold
	}

	// Commit local monotonic observations only after every verification succeeds.
	state := CheckpointState{TreeSize: cp.TreeSize, RootHash: cp.RootHash, IssuedAtUnixMS: cp.IssuedAtUnixMS, PolicyVersion: cp.PolicyVersion, PolicyDigest: cp.PolicyDigest}
	v.current = &state
	for _, att := range validWitnesses {
		v.witnessState[att.WitnessID] = WitnessState{TreeSize: cp.TreeSize, RootHash: cp.RootHash, ObservedAtUnixMS: att.ObservedAtUnixMS}
	}
	return nil
}

func (v *Verifier) Snapshot() StateSnapshot {
	v.mu.RLock()
	defer v.mu.RUnlock()
	out := StateSnapshot{LogID: v.root.LogID, RootVersion: v.root.Version, Witnesses: make(map[string]WitnessState, len(v.witnessState))}
	out.RootDigest, _ = TrustRootDigest(v.root)
	if v.current != nil {
		cp := *v.current
		out.Current = &cp
	}
	for id, state := range v.witnessState {
		out.Witnesses[id] = state
	}
	return out
}

// RestoreSnapshot restores locally persisted high-water marks only when their
// log and trust-root identity match the active verifier configuration.
func (v *Verifier) RestoreSnapshot(s StateSnapshot) error {
	v.mu.Lock()
	defer v.mu.Unlock()
	rootDigest, err := TrustRootDigest(v.root)
	if err != nil {
		return err
	}
	if s.LogID != v.root.LogID || s.RootVersion != v.root.Version || s.RootDigest != rootDigest {
		return ErrStateLogMismatch
	}
	if s.Current != nil {
		if s.Current.TreeSize < v.bootstrap.TreeSize {
			return ErrStateAhead
		}
		v.current = s.Current
	}
	for id, state := range s.Witnesses {
		if _, ok := v.witnesses[id]; !ok {
			return ErrWitnessUnknown
		}
		v.witnessState[id] = state
	}
	return nil
}

// CompareSnapshots compares independently persisted auditor views of one log.
// The caller supplies a consistency proof from the smaller tree head to the
// larger. A matching root at equal size detects identical views; a mismatch is
// a split view. Root-history reconciliation is deliberately fail-closed: both
// snapshots must name the same trust-root version and digest.
func CompareSnapshots(a, b StateSnapshot, consistencyProof []rfc9162.Hash) error {
	if a.LogID == "" || a.LogID != b.LogID {
		return ErrStateLogMismatch
	}
	if a.RootVersion != b.RootVersion || a.RootDigest != b.RootDigest {
		return ErrTrustRootVersion
	}
	if a.Current == nil || b.Current == nil {
		return ErrInvalidProfile
	}
	if a.Current.PolicyVersion < b.Current.PolicyVersion {
		// The larger policy version must be attached to a non-older tree head.
		if a.Current.TreeSize > b.Current.TreeSize {
			return ErrPolicyRollback
		}
	} else if b.Current.PolicyVersion < a.Current.PolicyVersion {
		if b.Current.TreeSize > a.Current.TreeSize {
			return ErrPolicyRollback
		}
	}
	if a.Current.PolicyVersion == b.Current.PolicyVersion && a.Current.PolicyDigest != b.Current.PolicyDigest {
		return ErrPolicyFork
	}
	if a.Current.TreeSize == b.Current.TreeSize {
		if a.Current.RootHash != b.Current.RootHash {
			return ErrSplitView
		}
		return nil
	}
	smaller, larger := a.Current, b.Current
	if smaller.TreeSize > larger.TreeSize {
		smaller, larger = larger, smaller
	}
	if len(consistencyProof) == 0 {
		return ErrConsistencyRequired
	}
	if err := rfc9162.VerifyConsistency(smaller.TreeSize, larger.TreeSize, smaller.RootHash, larger.RootHash, consistencyProof); err != nil {
		return fmt.Errorf("%w: %v", ErrConsistencyRequired, err)
	}
	return nil
}

// RootUpdateSigningBytes exposes the profile's domain-separated signed bytes
// for independent implementations and fixture generation.
func RootUpdateSigningBytes(root TrustRoot) ([]byte, error) { return rootSigningBytes(root) }

// ExplainError returns a stable, low-cardinality reason code for telemetry.
func ExplainError(err error) string {
	switch {
	case errors.Is(err, ErrUnknownLogKey):
		return "checkpoint:unknown-key"
	case errors.Is(err, ErrKeyOutsideValidity):
		return "checkpoint:key-outside-validity"
	case errors.Is(err, ErrInvalidSignature):
		return "checkpoint:signature-invalid"
	case errors.Is(err, ErrRollback):
		return "checkpoint:rollback"
	case errors.Is(err, ErrSplitView):
		return "checkpoint:split-view"
	case errors.Is(err, ErrStaleCheckpoint):
		return "checkpoint:stale"
	case errors.Is(err, ErrFutureCheckpoint):
		return "checkpoint:future"
	case errors.Is(err, ErrConsistencyRequired):
		return "checkpoint:consistency-invalid-or-missing"
	case errors.Is(err, ErrWitnessThreshold):
		return "checkpoint:witness-threshold"
	case errors.Is(err, ErrWitnessInvalid):
		return "checkpoint:witness-invalid"
	case errors.Is(err, ErrWitnessConsistency):
		return "checkpoint:witness-consistency"
	case errors.Is(err, ErrPolicyRollback):
		return "checkpoint:policy-rollback"
	case errors.Is(err, ErrPolicyFork):
		return "checkpoint:policy-fork"
	case errors.Is(err, ErrTrustRootVersion):
		return "checkpoint:trust-root-version"
	case errors.Is(err, ErrCheckpointBeforeTrustRoot):
		return "checkpoint:before-trust-root"
	default:
		return "checkpoint:rejected"
	}
}
