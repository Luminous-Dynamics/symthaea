# SFEB MON-008 authenticated checkpoint preflight

MON-008 advances MON-007 from Merkle proof relationships to authenticated, monotonic checkpoint observations. It is a research reference implementation, not a production transparency service or a complete SCITT verifier.

## Implemented in this increment

- Ed25519 authentication of domain-separated, deterministic checkpoint bytes.
- Explicit log identity, tree size, root hash, issue time, policy version **and policy digest**, signing key ID, and trust-root version.
- Externally configured bootstrap pin: the first checkpoint must match a separately provisioned `(log ID, tree size, root hash)`; there is no trust-on-first-use path.
- Sequential, hash-linked trust-root rotations. A rotation requires the old root's configured signature threshold and proof-of-possession from the new root's threshold.
- Key validity windows and trust-root version binding for each checkpoint.
- Monotonic tree-size and timestamp checks; rollback and same-size conflicting-root rejection.
- RFC 9162 consistency verification for each accepted tree extension.
- Witness attestations bound to the exact signed checkpoint, with quorum counted by distinct configured failure domains rather than raw key count.
- Per-witness high-water marks. When a witness's prior view is older than the verifier's current head, the incoming witness observation requires its own consistency proof to the new head.
- Monotonic registration-policy version and digest binding. A policy digest cannot silently change under the same version.
- Snapshot export/restore and comparison of independently persisted views; snapshots must be stored outside the log operator's control in rollback-resistant storage. The active verifier keeps the current trust root, while deployments must retain the full root-update chain separately for historical replay.
- Independent Go and Node implementations of the canonical signed checkpoint and witness bytes, with bidirectional Ed25519 differential fixtures.

## Important standards boundary

The binary checkpoint profile in this preflight is **not a COSE encoding** and is not wire-compatible with RFC 9942. It isolates signature and trust-state semantics so they can be tested before an interoperable COSE/CBOR adapter is added. The next standards integration must use RFC 9942 COSE Receipts and RFC 9943 SCITT Signed Statements, registration receipts, and historical policy/trust-anchor collateral. The profile must not replace those formats or the transparency-service implementation.

A valid log signature proves that the configured key signed the checkpoint bytes. A valid Merkle proof proves a relationship to the authenticated root. A witness quorum provides evidence that distinct configured failure domains observed the same signed checkpoint. None of those facts proves that the underlying application statement is true or that the real-world action occurred.

## Reproduce

From the repository root:

```sh
cd benchmarks/frontend/monitoring/sfeb-mon008/go
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
go test -cover ./...
go test -run '^$' -bench 'BenchmarkVerifyCheckpointWitnessQuorum' -benchmem -count=5 ./checkpoint

gofmt -w checkpoint/*.go cmd/checkpoint-vectors/main.go
cd ../js
node generate-vectors.mjs
node --test checkpoint.test.mjs
```

The Go module uses the existing MON-007 RFC 9162 verifier through a local `replace` directive. The Node side uses only `node:crypto` and the built-in test runner. The Go test suite reads the independently generated Node fixture; Node independently verifies the Go fixture.

## Trust and deployment limits

- The genesis trust root, witness registry, failure-domain assignments, and bootstrap pin are supplied out of band. Their authenticity and administrative independence are deployment responsibilities.
- The test profile uses Ed25519 and custom domain-separated binary serialization. It does not parse COSE, CBOR, X.509, RFC 9942 receipts, RFC 9943 Signed Statements, or SCITT policy collateral.
- The local verifier state is in memory. `StateSnapshot` is only safe to restore from storage whose rollback resistance and access control are independently established. The package does not build that storage. The verifier holds the active root only; historical key/root replay needs a separately retained, authenticated root-update chain, which is not yet implemented as an archive verifier.
- Witnesses are configured, not discovered. Domain labels must be audited; two keys under one operator do not become independent because they have different IDs.
- `CompareSnapshots` checks supplied snapshots for consistency but does not authenticate how snapshots were obtained.
- There is no production gossip network, witness discovery, real external sink, sink-side fence, separate-principal readback, key transparency, or offline auditor bundle in this increment.
- A signature or transparency receipt is not proof of an external effect. MON-007's effect/readback predicates remain separate.

## Local results

See `test-report-v1.json` and `benchmark-report-v1.json`. The current local preflight has 18 Go test functions (three fresh full-suite runs), one fresh Go race-detector run, `go vet`, 75.3% Go checkpoint-package statement coverage, and six Node test cases across five fresh runs (30 successful executions). Go and Node independently verify each other's generated Ed25519 checkpoint/witness fixtures.

On the recorded Xeon Platinum 8573C host, the five-run median for verifying one signed checkpoint plus 1, 2, or 3 witness signatures was 132.729, 202.110, and 292.231 microseconds respectively. These are verifier-only microbenchmarks, not end-to-end latency or comparative SOTA results. Full run samples and allocation counts are in `benchmark-report-v1.json`.

These results are local preflight evidence, not GitHub Actions results, production qualification, or a matched industry/SOTA comparison.
