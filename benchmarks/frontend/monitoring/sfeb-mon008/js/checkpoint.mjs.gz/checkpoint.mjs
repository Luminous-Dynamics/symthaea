import { createHash, createPublicKey, verify as verifySignature } from 'node:crypto';

const CHECKPOINT_DOMAIN = Buffer.from('LUMINOUS-SFEB-CHECKPOINT\0V1\0', 'utf8');
const SIGNED_CHECKPOINT_DOMAIN = Buffer.from('LUMINOUS-SFEB-SIGNED-CHECKPOINT\0V1\0', 'utf8');
const WITNESS_DOMAIN = Buffer.from('LUMINOUS-SFEB-WITNESS\0V1\0', 'utf8');
const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

function u16(value) {
  const out = Buffer.alloc(2);
  out.writeUInt16BE(value);
  return out;
}
function u64(value) {
  const n = BigInt(value);
  if (n < 0n || n > 0xffffffffffffffffn) throw new RangeError('uint64 out of range');
  const out = Buffer.alloc(8);
  out.writeBigUInt64BE(n);
  return out;
}
function text(value) {
  if (typeof value !== 'string' || value.length === 0) throw new TypeError('empty profile string');
  const encoded = Buffer.from(value, 'utf8');
  if (encoded.length > 0xffff) throw new RangeError('profile string too long');
  return Buffer.concat([u16(encoded.length), encoded]);
}
function rootBytes(hex) {
  if (typeof hex !== 'string' || !/^[0-9a-f]{64}$/i.test(hex)) throw new TypeError('rootHashHex must be 32-byte hex');
  return Buffer.from(hex, 'hex');
}

export function canonicalCheckpointBytes(cp) {
  if (!cp || cp.version !== 1) throw new TypeError('unsupported checkpoint profile');
  const treeSize = BigInt(cp.treeSize);
  const issuedAt = BigInt(cp.issuedAtUnixMs);
  const policyVersion = BigInt(cp.policyVersion);
  if (BigInt(cp.trustRootVersion) <= 0n || treeSize <= 0n || issuedAt <= 0n || policyVersion <= 0n) throw new RangeError('checkpoint counters and time must be positive');
  return Buffer.concat([
    CHECKPOINT_DOMAIN,
    u16(cp.version),
    u64(cp.trustRootVersion),
    text(cp.logId),
    u64(treeSize),
    rootBytes(cp.rootHashHex),
    u64(issuedAt),
    u64(policyVersion),
    rootBytes(cp.policyDigestHex),
    text(cp.keyId),
  ]);
}

export function signedCheckpointDigest(cp, signature) {
  const sig = Buffer.from(signature);
  if (sig.length !== 64) throw new TypeError('Ed25519 signature must be 64 bytes');
  return createHash('sha256').update(SIGNED_CHECKPOINT_DOMAIN).update(canonicalCheckpointBytes(cp)).update(sig).digest();
}

export function witnessSigningBytes(logId, witnessId, checkpointDigest, observedAtUnixMs) {
  const digest = Buffer.from(checkpointDigest);
  if (digest.length !== 32) throw new TypeError('checkpoint digest must be 32 bytes');
  return Buffer.concat([WITNESS_DOMAIN, text(logId), text(witnessId), digest, u64(observedAtUnixMs)]);
}

export function verifyEd25519Raw(publicKeyRaw, payload, signature) {
  const raw = Buffer.from(publicKeyRaw);
  if (raw.length !== 32) return false;
  const key = createPublicKey({ key: Buffer.concat([ED25519_SPKI_PREFIX, raw]), format: 'der', type: 'spki' });
  return verifySignature(null, Buffer.from(payload), key, Buffer.from(signature));
}

export function verifyCheckpointFixture(fixture) {
  const payload = canonicalCheckpointBytes(fixture.checkpoint);
  if (payload.toString('hex') !== fixture.checkpointPayloadHex) return false;
  if (!verifyEd25519Raw(Buffer.from(fixture.checkpointPublicKeyBase64, 'base64'), payload, Buffer.from(fixture.checkpointSignatureBase64, 'base64'))) return false;
  const digest = signedCheckpointDigest(fixture.checkpoint, Buffer.from(fixture.checkpointSignatureBase64, 'base64'));
  for (const witness of fixture.witnesses) {
    const witnessPayload = witnessSigningBytes(fixture.checkpoint.logId, witness.id, digest, witness.observedAtUnixMs);
    if (witnessPayload.toString('hex') !== witness.signingPayloadHex) return false;
    if (!verifyEd25519Raw(Buffer.from(witness.publicKeyBase64, 'base64'), witnessPayload, Buffer.from(witness.signatureBase64, 'base64'))) return false;
  }
  return true;
}
