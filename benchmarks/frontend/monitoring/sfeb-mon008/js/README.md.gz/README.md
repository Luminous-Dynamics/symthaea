# MON-008 Node verifier and cross-language vectors

This independent implementation uses Node's built-in `node:crypto` and the built-in test runner. It reproduces the canonical checkpoint and witness signing bytes and verifies both Node- and Go-generated Ed25519 fixtures.

The canonical encoder accepts safe integer Numbers, BigInt, or canonical decimal strings for uint64 fields. It rejects unsafe JavaScript Numbers instead of silently rounding values above 2^53-1.

From this directory:

```sh
node generate-vectors.mjs
node --test checkpoint.test.mjs
```

The vector generator is deterministic and writes `testdata/node-generated-v1.json`. The Go fixture is generated from `../go` with `go run ./cmd/checkpoint-vectors` and written to `testdata/go-generated-v1.json`.

This is not an implementation of COSE or RFC 9942. It is an independent check of the custom, domain-separated research profile described by the parent README.
