# MON-008 Node verifier and cross-language vectors

This independent implementation uses Node's built-in `node:crypto` and test runner. It reproduces the canonical checkpoint and witness signing bytes and verifies both Node- and Go-generated Ed25519 fixtures.

From the repository root, extract its source: 

```sh
for f in checkpoint.mjs checkpoint.test.mjs generate-vectors.mjs; do
  gzip -dc "benchmarks/frontend/monitoring/sfeb-mon008/js/${f}.gz" > "benchmarks/frontend/monitoring/sfeb-mon008/js/${f}"
done
cd benchmarks/frontend/monitoring/sfeb-mon008/js
node generate-vectors.mjs
node --test checkpoint.test.mjs
```

The Node vector generator writes `testdata/node-generated-v1.json`. The Go fixture is generated from `../go` using `go run ./cmd/checkpoint-vectors` and written to `testdata/go-generated-v1.json`. This is not a COSE or RFC 9942 implementation; it independently checks the custom research profile described by the parent README.
