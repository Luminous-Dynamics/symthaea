import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { canonicalCheckpointBytes, verifyCheckpointFixture, verifyEd25519Raw, signedCheckpointDigest, witnessSigningBytes } from './checkpoint.mjs';

const load = async (name) => JSON.parse(await readFile(new URL(`./testdata/${name}`, import.meta.url), 'utf8'));

test('Node independently verifies Go-generated checkpoint and witness signatures', async () => {
  const fixture = await load('go-generated-v1.json');
  assert.equal(fixture.schema, 'sfeb-mon008-checkpoint-v1');
  assert.equal(verifyCheckpointFixture(fixture), true);
});

test('Node independently verifies its own vector and exact canonical encoding', async () => {
  const fixture = await load('node-generated-v1.json');
  assert.equal(verifyCheckpointFixture(fixture), true);
  assert.equal(canonicalCheckpointBytes(fixture.checkpoint).toString('hex'), fixture.checkpointPayloadHex);
});

test('checkpoint signature fails closed after a policy-version mutation', async () => {
  const fixture = await load('go-generated-v1.json');
  const mutated = { ...fixture.checkpoint, policyVersion: fixture.checkpoint.policyVersion + 1 };
  assert.equal(verifyEd25519Raw(Buffer.from(fixture.checkpointPublicKeyBase64, 'base64'), canonicalCheckpointBytes(mutated), Buffer.from(fixture.checkpointSignatureBase64, 'base64')), false);
});

test('witness signature fails closed after a checkpoint-digest mutation', async () => {
  const fixture = await load('go-generated-v1.json');
  const witness = fixture.witnesses[0];
  const changed = signedCheckpointDigest(fixture.checkpoint, Buffer.from(fixture.checkpointSignatureBase64, 'base64'));
  changed[0] ^= 0x80;
  const payload = witnessSigningBytes(fixture.checkpoint.logId, witness.id, changed, witness.observedAtUnixMs);
  assert.equal(verifyEd25519Raw(Buffer.from(witness.publicKeyBase64, 'base64'), payload, Buffer.from(witness.signatureBase64, 'base64')), false);
});

test('malformed checkpoint fields and unsupported profile versions are rejected', async () => {
  const fixture = await load('go-generated-v1.json');
  assert.throws(() => canonicalCheckpointBytes({ ...fixture.checkpoint, version: 2 }));
  assert.throws(() => canonicalCheckpointBytes({ ...fixture.checkpoint, rootHashHex: '00' }));
});


test('uint64 fields reject unsafe Numbers and preserve exact BigInt or decimal-string inputs', async () => {
  const fixture = await load('go-generated-v1.json');
  const exact = { ...fixture.checkpoint, treeSize: '9007199254740993' };
  const asBigInt = { ...fixture.checkpoint, treeSize: 9007199254740993n };
  assert.deepEqual(canonicalCheckpointBytes(exact), canonicalCheckpointBytes(asBigInt));
  assert.throws(() => canonicalCheckpointBytes({ ...fixture.checkpoint, treeSize: 9007199254740993 }), /safe integer Number/);
  assert.throws(() => canonicalCheckpointBytes({ ...fixture.checkpoint, policyVersion: '01' }), /canonical decimal string/);
  assert.throws(() => canonicalCheckpointBytes({ ...fixture.checkpoint, trustRootVersion: '18446744073709551616' }), /outside uint64/);
});
