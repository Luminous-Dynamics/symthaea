import { createHash, createPrivateKey, createPublicKey, sign } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { canonicalCheckpointBytes, signedCheckpointDigest, witnessSigningBytes } from './checkpoint.mjs';

const PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');
const seed = (label) => createHash('sha256').update(`sfeb-mon008-vector:${label}`).digest();
const privateKey = (label) => createPrivateKey({ key: Buffer.concat([PKCS8_PREFIX, seed(label)]), format: 'der', type: 'pkcs8' });
const publicRaw = (key) => createPublicKey(key).export({ format: 'der', type: 'spki' }).subarray(-32);
const b64 = (value) => Buffer.from(value).toString('base64');

const logKey = privateKey('node-log-key');
const checkpoint = {
  version: 1,
  trustRootVersion: 1,
  logId: 'mon008.node.example.test',
  treeSize: 11,
  rootHashHex: createHash('sha256').update('node-generated deterministic root').digest('hex'),
  issuedAtUnixMs: 1800000000100,
  policyVersion: 4,
  policyDigestHex: createHash('sha256').update('node registration policy v4').digest('hex'),
  keyId: 'node-log-key-1',
};
const payload = canonicalCheckpointBytes(checkpoint);
const signature = sign(null, payload, logKey);
const digest = signedCheckpointDigest(checkpoint, signature);
const witnesses = [];
for (const [id, domain] of [['node-witness-a', 'failure-domain-a'], ['node-witness-b', 'failure-domain-b']]) {
  const key = privateKey(id);
  const observedAtUnixMs = checkpoint.issuedAtUnixMs + 20;
  const witnessPayload = witnessSigningBytes(checkpoint.logId, id, digest, observedAtUnixMs);
  witnesses.push({
    id, failureDomain: domain, observedAtUnixMs,
    publicKeyBase64: b64(publicRaw(key)),
    signatureBase64: b64(sign(null, witnessPayload, key)),
    signingPayloadHex: witnessPayload.toString('hex'),
  });
}
const fixture = {
  schema: 'sfeb-mon008-checkpoint-v1',
  checkpoint,
  checkpointPayloadHex: payload.toString('hex'),
  checkpointPublicKeyBase64: b64(publicRaw(logKey)),
  checkpointSignatureBase64: b64(signature),
  witnesses,
};
await writeFile(new URL('./testdata/node-generated-v1.json', import.meta.url), `${JSON.stringify(fixture, null, 2)}\n`);
console.log('wrote independent Node checkpoint vector');
