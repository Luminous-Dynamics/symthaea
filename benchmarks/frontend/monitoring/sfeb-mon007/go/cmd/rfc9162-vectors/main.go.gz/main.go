// Command rfc9162-vectors emits deterministic cross-implementation proof vectors.
// The Go package generates the proof paths; the independent Node verifier consumes them.
package main

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"sfeb-mon007/assurance/rfc9162"
)

type inclusionVector struct {
	Leaf     string   `json:"leaf"`
	Index    uint64   `json:"index"`
	TreeSize uint64   `json:"treeSize"`
	LeafHash string   `json:"leafHash"`
	Root     string   `json:"root"`
	Proof    []string `json:"proof"`
}

type consistencyVector struct {
	FirstSize  uint64   `json:"firstSize"`
	SecondSize uint64   `json:"secondSize"`
	FirstRoot  string   `json:"firstRoot"`
	SecondRoot string   `json:"secondRoot"`
	Proof      []string `json:"proof"`
}

type corpus struct {
	Schema      string              `json:"schema"`
	Producer    string              `json:"producer"`
	MaxTreeSize int                 `json:"maxTreeSize"`
	Inclusion   []inclusionVector   `json:"inclusion"`
	Consistency []consistencyVector `json:"consistency"`
}

func makeLeaves(n int) [][]byte {
	leaves := make([][]byte, n)
	for i := range leaves {
		leaves[i] = []byte(fmt.Sprintf("sfeb-differential-leaf-%04d", i))
	}
	return leaves
}

func hashHex(h rfc9162.Hash) string { return hex.EncodeToString(h[:]) }

func proofHex(proof []rfc9162.Hash) []string {
	out := make([]string, len(proof))
	for i, h := range proof {
		out[i] = hashHex(h)
	}
	return out
}

func main() {
	const maxTreeSize = 16
	vectors := corpus{
		Schema:      "rfc9162-sha256-go-generated-v1",
		Producer:    "sfeb-mon007/assurance/rfc9162 Go implementation",
		MaxTreeSize: maxTreeSize,
	}

	for size := 1; size <= maxTreeSize; size++ {
		leaves := makeLeaves(size)
		root := rfc9162.RootFromLeaves(leaves)
		for index, leaf := range leaves {
			proof, err := rfc9162.InclusionProof(leaves, uint64(index))
			if err != nil {
				panic(err)
			}
			vectors.Inclusion = append(vectors.Inclusion, inclusionVector{
				Leaf: string(leaf), Index: uint64(index), TreeSize: uint64(size),
				LeafHash: hashHex(rfc9162.LeafHash(leaf)), Root: hashHex(root), Proof: proofHex(proof),
			})
		}
	}

	for second := 2; second <= maxTreeSize; second++ {
		leaves := makeLeaves(second)
		secondRoot := rfc9162.RootFromLeaves(leaves)
		for first := 1; first < second; first++ {
			firstRoot := rfc9162.RootFromLeaves(leaves[:first])
			proof, err := rfc9162.ConsistencyProof(leaves, uint64(first))
			if err != nil {
				panic(err)
			}
			vectors.Consistency = append(vectors.Consistency, consistencyVector{
				FirstSize: uint64(first), SecondSize: uint64(second),
				FirstRoot: hashHex(firstRoot), SecondRoot: hashHex(secondRoot), Proof: proofHex(proof),
			})
		}
	}

	data, err := json.MarshalIndent(vectors, "", "  ")
	if err != nil {
		panic(err)
	}
	data = append(data, '\n')
	if len(os.Args) == 2 {
		if err := os.WriteFile(os.Args[1], data, 0o644); err != nil {
			panic(err)
		}
		return
	}
	if _, err := os.Stdout.Write(data); err != nil {
		panic(err)
	}
}
