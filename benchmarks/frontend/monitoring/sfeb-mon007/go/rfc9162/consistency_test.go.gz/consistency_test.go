package rfc9162

import (
	"errors"
	"fmt"
	"testing"
)

func TestAllConsistencyPairsForTreeSizesThrough256(t *testing.T) {
	for secondSize := 2; secondSize <= 256; secondSize++ {
		leaves := makeLeaves(secondSize)
		secondRoot := RootFromLeaves(leaves)
		for firstSize := 1; firstSize < secondSize; firstSize++ {
			firstRoot := RootFromLeaves(leaves[:firstSize])
			proof, err := ConsistencyProof(leaves, uint64(firstSize))
			if err != nil {
				t.Fatalf("first=%d second=%d build: %v", firstSize, secondSize, err)
			}
			if err := VerifyConsistency(uint64(firstSize), uint64(secondSize), firstRoot, secondRoot, proof); err != nil {
				t.Fatalf("first=%d second=%d verify: %v", firstSize, secondSize, err)
			}
			if len(proof) > 10 { // ceil(log2(256)) + 1
				t.Fatalf("first=%d second=%d proof unexpectedly long: %d", firstSize, secondSize, len(proof))
			}
		}
	}
}

func TestRejectsInvalidConsistencySizesAndEmptyProof(t *testing.T) {
	var root Hash
	if !errors.Is(VerifyConsistency(0, 1, root, root, []Hash{{}}), ErrInvalidConsistencySizes) {
		t.Fatal("expected zero first tree size to be rejected")
	}
	if !errors.Is(VerifyConsistency(2, 2, root, root, []Hash{{}}), ErrInvalidConsistencySizes) {
		t.Fatal("expected equal tree sizes to be rejected")
	}
	if !errors.Is(VerifyConsistency(3, 2, root, root, []Hash{{}}), ErrInvalidConsistencySizes) {
		t.Fatal("expected decreasing tree sizes to be rejected")
	}
	if !errors.Is(VerifyConsistency(1, 2, root, root, nil), ErrEmptyConsistencyProof) {
		t.Fatal("expected empty proof to be rejected")
	}
}

func TestRejectsTamperedConsistencyProofAndRoots(t *testing.T) {
	leaves := makeLeaves(37)
	firstSize := uint64(13)
	firstRoot := RootFromLeaves(leaves[:firstSize])
	secondRoot := RootFromLeaves(leaves)
	proof, err := ConsistencyProof(leaves, firstSize)
	if err != nil {
		t.Fatal(err)
	}

	mutated := append([]Hash(nil), proof...)
	mutated[0][0] ^= 0x80
	if err := VerifyConsistency(firstSize, uint64(len(leaves)), firstRoot, secondRoot, mutated); err == nil {
		t.Fatal("tampered proof unexpectedly verified")
	}

	wrongFirst := Hash{0x42}
	if !errors.Is(VerifyConsistency(firstSize, uint64(len(leaves)), wrongFirst, secondRoot, proof), ErrFirstRootMismatch) {
		t.Fatal("wrong first root was not rejected")
	}

	wrongSecond := Hash{0x24}
	if !errors.Is(VerifyConsistency(firstSize, uint64(len(leaves)), firstRoot, wrongSecond, proof), ErrSecondRootMismatch) {
		t.Fatal("wrong second root was not rejected")
	}
}

func TestRejectsTruncatedAndExcessConsistencyProofs(t *testing.T) {
	leaves := makeLeaves(97)
	firstSize := uint64(31)
	firstRoot := RootFromLeaves(leaves[:firstSize])
	secondRoot := RootFromLeaves(leaves)
	proof, err := ConsistencyProof(leaves, firstSize)
	if err != nil {
		t.Fatal(err)
	}
	if len(proof) < 2 {
		t.Fatalf("fixture proof too short for mutation test: %d", len(proof))
	}

	if err := VerifyConsistency(firstSize, uint64(len(leaves)), firstRoot, secondRoot, proof[:len(proof)-1]); !errors.Is(err, ErrConsistencyProofShort) {
		t.Fatalf("truncated proof: got %v, want ErrConsistencyProofShort", err)
	}
	extra := append(append([]Hash(nil), proof...), Hash{0x99})
	if err := VerifyConsistency(firstSize, uint64(len(leaves)), firstRoot, secondRoot, extra); !errors.Is(err, ErrConsistencyProofTooLong) {
		t.Fatalf("excess proof: got %v, want ErrConsistencyProofTooLong", err)
	}
}

func TestConsistencyProofPrefixDoesNotDependOnSuffixContent(t *testing.T) {
	prefix := makeLeaves(12)
	a := append(append([][]byte(nil), prefix...), []byte("suffix-a"), []byte("suffix-b"))
	b := append(append([][]byte(nil), prefix...), []byte("different-suffix"), []byte("other"))
	oldRoot := RootFromLeaves(prefix)
	proofA, err := ConsistencyProof(a, uint64(len(prefix)))
	if err != nil {
		t.Fatal(err)
	}
	proofB, err := ConsistencyProof(b, uint64(len(prefix)))
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyConsistency(uint64(len(prefix)), uint64(len(a)), oldRoot, RootFromLeaves(a), proofA); err != nil {
		t.Fatal(err)
	}
	if err := VerifyConsistency(uint64(len(prefix)), uint64(len(b)), oldRoot, RootFromLeaves(b), proofB); err != nil {
		t.Fatal(err)
	}
	if fmt.Sprint(proofA) == fmt.Sprint(proofB) {
		t.Fatal("different appended suffixes unexpectedly produced identical consistency paths")
	}
}

func BenchmarkVerifyConsistency(b *testing.B) {
	for _, sizes := range [][2]int{{16, 256}, {256, 4096}, {4096, 65536}} {
		firstSize, secondSize := sizes[0], sizes[1]
		b.Run(fmt.Sprintf("%d-to-%d", firstSize, secondSize), func(b *testing.B) {
			leaves := makeLeaves(secondSize)
			firstRoot := RootFromLeaves(leaves[:firstSize])
			secondRoot := RootFromLeaves(leaves)
			proof, err := ConsistencyProof(leaves, uint64(firstSize))
			if err != nil {
				b.Fatal(err)
			}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if err := VerifyConsistency(uint64(firstSize), uint64(secondSize), firstRoot, secondRoot, proof); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

func TestRFC9162Section215SevenLeafConsistencyExamples(t *testing.T) {
	leaves := makeLeaves(7)
	firstThree := []Hash{
		LeafHash(leaves[2]),
		LeafHash(leaves[3]),
		RootFromLeaves(leaves[:2]),
		RootFromLeaves(leaves[4:]),
	}
	firstFour := []Hash{RootFromLeaves(leaves[4:])}
	firstSix := []Hash{
		RootFromLeaves(leaves[4:6]),
		LeafHash(leaves[6]),
		RootFromLeaves(leaves[:4]),
	}

	for _, tc := range []struct {
		oldSize uint64
		want    []Hash
	}{
		{oldSize: 3, want: firstThree},
		{oldSize: 4, want: firstFour},
		{oldSize: 6, want: firstSix},
	} {
		got, err := ConsistencyProof(leaves, tc.oldSize)
		if err != nil {
			t.Fatalf("old size %d: %v", tc.oldSize, err)
		}
		if len(got) != len(tc.want) {
			t.Fatalf("old size %d: proof length %d, want %d", tc.oldSize, len(got), len(tc.want))
		}
		for i := range got {
			if got[i] != tc.want[i] {
				t.Fatalf("old size %d node %d differs from RFC 9162 Section 2.1.5 example", tc.oldSize, i)
			}
		}
		if err := VerifyConsistency(tc.oldSize, uint64(len(leaves)), RootFromLeaves(leaves[:tc.oldSize]), RootFromLeaves(leaves), got); err != nil {
			t.Fatalf("old size %d RFC example proof did not verify: %v", tc.oldSize, err)
		}
	}
}
