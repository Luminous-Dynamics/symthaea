package rfc9162

import (
	"bytes"
	"compress/gzip"
	"embed"
	"encoding/hex"
	"encoding/json"
	"io"
	"testing"
)

//go:embed testdata/rfc9162-node-generated-v1.json.gz
var nodeGeneratedCorpus embed.FS

type nodeInclusionVector struct {
	Leaf     string   `json:"leaf"`
	Index    uint64   `json:"index"`
	TreeSize uint64   `json:"treeSize"`
	LeafHash string   `json:"leafHash"`
	Root     string   `json:"root"`
	Proof    []string `json:"proof"`
}

type nodeConsistencyVector struct {
	FirstSize  uint64   `json:"firstSize"`
	SecondSize uint64   `json:"secondSize"`
	FirstRoot  string   `json:"firstRoot"`
	SecondRoot string   `json:"secondRoot"`
	Proof      []string `json:"proof"`
}

type nodeGeneratedVectors struct {
	Schema      string                  `json:"schema"`
	Producer    string                  `json:"producer"`
	MaxTreeSize int                     `json:"maxTreeSize"`
	Inclusion   []nodeInclusionVector   `json:"inclusion"`
	Consistency []nodeConsistencyVector `json:"consistency"`
}

func decodeHashHex(t *testing.T, value string) Hash {
	t.Helper()
	var result Hash
	decoded, err := hex.DecodeString(value)
	if err != nil {
		t.Fatalf("decode SHA-256 hex: %v", err)
	}
	if len(decoded) != len(result) {
		t.Fatalf("decoded hash length %d, want %d", len(decoded), len(result))
	}
	copy(result[:], decoded)
	return result
}

func decodeProofHex(t *testing.T, values []string) []Hash {
	t.Helper()
	proof := make([]Hash, len(values))
	for i, value := range values {
		proof[i] = decodeHashHex(t, value)
	}
	return proof
}

func loadNodeGeneratedVectors(t *testing.T) nodeGeneratedVectors {
	t.Helper()
	compressed, err := nodeGeneratedCorpus.ReadFile("testdata/rfc9162-node-generated-v1.json.gz")
	if err != nil {
		t.Fatalf("read embedded Node vector corpus: %v", err)
	}
	reader, err := gzip.NewReader(bytes.NewReader(compressed))
	if err != nil {
		t.Fatalf("open compressed Node vector corpus: %v", err)
	}
	defer reader.Close()
	data, err := io.ReadAll(reader)
	if err != nil {
		t.Fatalf("read Node vector corpus: %v", err)
	}
	var vectors nodeGeneratedVectors
	if err := json.Unmarshal(data, &vectors); err != nil {
		t.Fatalf("decode Node vector corpus: %v", err)
	}
	return vectors
}

func TestGoIndependentlyVerifiesNodeGeneratedInclusionAndConsistencyVectors(t *testing.T) {
	vectors := loadNodeGeneratedVectors(t)
	if vectors.Schema != "rfc9162-sha256-node-generated-v1" {
		t.Fatalf("unexpected schema %q", vectors.Schema)
	}
	if vectors.MaxTreeSize != 16 {
		t.Fatalf("max tree size %d, want 16", vectors.MaxTreeSize)
	}
	if len(vectors.Inclusion) != 136 || len(vectors.Consistency) != 120 {
		t.Fatalf("unexpected corpus size: inclusion=%d consistency=%d", len(vectors.Inclusion), len(vectors.Consistency))
	}

	for _, vector := range vectors.Inclusion {
		leafHash := decodeHashHex(t, vector.LeafHash)
		root := decodeHashHex(t, vector.Root)
		proof := decodeProofHex(t, vector.Proof)
		if got := LeafHash([]byte(vector.Leaf)); got != leafHash {
			t.Fatalf("Node leaf hash mismatch: tree=%d index=%d", vector.TreeSize, vector.Index)
		}
		if err := VerifyInclusion(leafHash, vector.Index, vector.TreeSize, proof, root); err != nil {
			t.Fatalf("Node inclusion vector rejected: tree=%d index=%d: %v", vector.TreeSize, vector.Index, err)
		}
	}

	for _, vector := range vectors.Consistency {
		firstRoot := decodeHashHex(t, vector.FirstRoot)
		secondRoot := decodeHashHex(t, vector.SecondRoot)
		proof := decodeProofHex(t, vector.Proof)
		if err := VerifyConsistency(vector.FirstSize, vector.SecondSize, firstRoot, secondRoot, proof); err != nil {
			t.Fatalf("Node consistency vector rejected: old=%d new=%d: %v", vector.FirstSize, vector.SecondSize, err)
		}
	}
}
