package rfc9162

import (
	"errors"
	"fmt"
	"testing"
)

func makeLeaves(n int) [][]byte {
	leaves := make([][]byte, n)
	for i := range leaves {
		leaves[i] = []byte(fmt.Sprintf("sfeb-evidence-record-%04d", i))
	}
	return leaves
}

func TestAllLeafPositionsForTreeSizesOneThrough256(t *testing.T) {
	for size := 1; size <= 256; size++ {
		leaves := makeLeaves(size)
		root := RootFromLeaves(leaves)
		for index, leaf := range leaves {
			proof, err := InclusionProof(leaves, uint64(index))
			if err != nil {
				t.Fatalf("size=%d index=%d build proof: %v", size, index, err)
			}
			if err := VerifyInclusion(LeafHash(leaf), uint64(index), uint64(size), proof, root); err != nil {
				t.Fatalf("size=%d index=%d verify: %v", size, index, err)
			}
		}
	}
}

func TestRejectsLeafIndexAndEmptyTree(t *testing.T) {
	if !errors.Is(VerifyInclusion(Hash{}, 0, 0, nil, Hash{}), ErrEmptyTree) {
		t.Fatal("expected empty-tree rejection")
	}
	if !errors.Is(VerifyInclusion(Hash{}, 1, 1, nil, Hash{}), ErrIndexOutOfRange) {
		t.Fatal("expected out-of-range rejection")
	}
}

func TestRejectsTamperedLeafRootAndProofNode(t *testing.T) {
	leaves := makeLeaves(19)
	index := uint64(11)
	root := RootFromLeaves(leaves)
	proof, err := InclusionProof(leaves, index)
	if err != nil {
		t.Fatal(err)
	}
	wrongLeaf := LeafHash([]byte("different evidence"))
	if err := VerifyInclusion(wrongLeaf, index, uint64(len(leaves)), proof, root); !errors.Is(err, ErrRootMismatch) {
		t.Fatalf("tampered leaf: expected root mismatch, got %v", err)
	}
	wrongRoot := Hash{0x42}
	if err := VerifyInclusion(LeafHash(leaves[index]), index, uint64(len(leaves)), proof, wrongRoot); !errors.Is(err, ErrRootMismatch) {
		t.Fatalf("tampered root: expected root mismatch, got %v", err)
	}
	mutated := append([]Hash(nil), proof...)
	mutated[0][0] ^= 0x80
	if err := VerifyInclusion(LeafHash(leaves[index]), index, uint64(len(leaves)), mutated, root); !errors.Is(err, ErrRootMismatch) {
		t.Fatalf("tampered proof: expected root mismatch, got %v", err)
	}
}

func TestRejectsTruncatedAndExcessProofs(t *testing.T) {
	leaves := makeLeaves(33)
	index := uint64(17)
	root := RootFromLeaves(leaves)
	proof, err := InclusionProof(leaves, index)
	if err != nil {
		t.Fatal(err)
	}
	if len(proof) == 0 {
		t.Fatal("fixture must have a non-empty path")
	}
	if err := VerifyInclusion(LeafHash(leaves[index]), index, uint64(len(leaves)), proof[:len(proof)-1], root); !errors.Is(err, ErrProofTooShort) {
		t.Fatalf("truncated path: expected short-proof rejection, got %v", err)
	}
	extra := append(append([]Hash(nil), proof...), Hash{})
	if err := VerifyInclusion(LeafHash(leaves[index]), index, uint64(len(leaves)), extra, root); !errors.Is(err, ErrProofTooLong) {
		t.Fatalf("excess path: expected long-proof rejection, got %v", err)
	}
}

func TestDomainSeparationForLeavesAndNodes(t *testing.T) {
	payload := []byte("same bytes")
	leaf := LeafHash(payload)
	var left, right Hash
	copy(left[:], payload)
	copy(right[:], payload)
	if leaf == NodeHash(left, right) {
		t.Fatal("leaf and interior-node domains must be distinct")
	}
}

func BenchmarkVerifyInclusion(b *testing.B) {
	for _, size := range []int{16, 256, 4096} {
		b.Run(fmt.Sprintf("tree-%d", size), func(b *testing.B) {
			leaves := makeLeaves(size)
			index := uint64(size / 2)
			root := RootFromLeaves(leaves)
			proof, err := InclusionProof(leaves, index)
			if err != nil {
				b.Fatal(err)
			}
			leafHash := LeafHash(leaves[index])
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if err := VerifyInclusion(leafHash, index, uint64(size), proof, root); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
