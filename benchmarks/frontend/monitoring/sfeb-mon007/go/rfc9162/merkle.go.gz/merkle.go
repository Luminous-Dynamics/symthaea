// Package rfc9162 implements the RFC 9162 Merkle Tree Hash and inclusion-proof
// verification primitives needed by the SFEB verifier preflight.
//
// The implementation is intentionally small and uses only the Go standard
// library. It accepts already-decoded 32-byte SHA-256 proof nodes; COSE/CBOR,
// receipt parsing, checkpoint signatures, consistency proofs, and trust policy
// are separate layers and are not implemented here.
package rfc9162

import (
	"crypto/sha256"
	"errors"
	"fmt"
)

// Hash is an RFC 9162 SHA-256 Merkle digest.
type Hash [sha256.Size]byte

var (
	ErrEmptyTree       = errors.New("RFC 9162 inclusion proof cannot target an empty tree")
	ErrIndexOutOfRange = errors.New("RFC 9162 leaf index is outside the tree")
	ErrProofTooShort   = errors.New("RFC 9162 inclusion proof is too short")
	ErrProofTooLong    = errors.New("RFC 9162 inclusion proof has excess nodes")
	ErrRootMismatch    = errors.New("RFC 9162 inclusion proof does not match the trusted root")
)

// LeafHash computes SHA-256(0x00 || leaf) as specified by RFC 9162.
func LeafHash(leaf []byte) Hash {
	buf := make([]byte, 1+len(leaf))
	buf[0] = 0x00
	copy(buf[1:], leaf)
	return sha256.Sum256(buf)
}

// NodeHash computes SHA-256(0x01 || left || right) as specified by RFC 9162.
func NodeHash(left, right Hash) Hash {
	var buf [1 + 2*sha256.Size]byte
	buf[0] = 0x01
	copy(buf[1:1+sha256.Size], left[:])
	copy(buf[1+sha256.Size:], right[:])
	return sha256.Sum256(buf[:])
}

// VerifyInclusion verifies a leaf hash at index in a tree of size treeSize.
// Proof nodes are ordered leaf-to-root. The trusted root must come from a
// separately authenticated checkpoint; this function does not authenticate it.
func VerifyInclusion(leafHash Hash, index, treeSize uint64, proof []Hash, trustedRoot Hash) error {
	if treeSize == 0 {
		return ErrEmptyTree
	}
	if index >= treeSize {
		return ErrIndexOutOfRange
	}

	fn := index
	sn := treeSize - 1
	running := leafHash
	for i, sibling := range proof {
		if sn == 0 {
			return fmt.Errorf("%w: node %d", ErrProofTooLong, i)
		}
		if fn&1 == 1 || fn == sn {
			running = NodeHash(sibling, running)
			for fn&1 == 0 && fn != 0 {
				fn >>= 1
				sn >>= 1
			}
		} else {
			running = NodeHash(running, sibling)
		}
		fn >>= 1
		sn >>= 1
	}

	if sn != 0 {
		return ErrProofTooShort
	}
	if running != trustedRoot {
		return ErrRootMismatch
	}
	return nil
}

// RootFromLeaves computes an RFC 9162 Merkle Tree Hash for test fixtures and
// local proof tooling. Production verifiers should obtain the root from an
// authenticated checkpoint, not trust a root supplied alongside a proof.
func RootFromLeaves(leaves [][]byte) Hash {
	return treeHash(leaves)
}

// InclusionProof builds a leaf-to-root RFC 9162 inclusion path. It is exposed
// for fixture generation only; VerifyInclusion is the verification primitive.
func InclusionProof(leaves [][]byte, index uint64) ([]Hash, error) {
	if len(leaves) == 0 {
		return nil, ErrEmptyTree
	}
	if index >= uint64(len(leaves)) {
		return nil, ErrIndexOutOfRange
	}
	return inclusionPath(leaves, int(index)), nil
}

func treeHash(leaves [][]byte) Hash {
	switch len(leaves) {
	case 0:
		return sha256.Sum256(nil)
	case 1:
		return LeafHash(leaves[0])
	default:
		k := largestPowerOfTwoLessThan(uint64(len(leaves)))
		left := treeHash(leaves[:k])
		right := treeHash(leaves[k:])
		return NodeHash(left, right)
	}
}

func inclusionPath(leaves [][]byte, index int) []Hash {
	if len(leaves) <= 1 {
		return nil
	}
	k := int(largestPowerOfTwoLessThan(uint64(len(leaves))))
	if index < k {
		path := inclusionPath(leaves[:k], index)
		return append(path, treeHash(leaves[k:]))
	}
	path := inclusionPath(leaves[k:], index-k)
	return append(path, treeHash(leaves[:k]))
}

func largestPowerOfTwoLessThan(n uint64) uint64 {
	if n < 2 {
		return 0
	}
	k := uint64(1)
	for (k << 1) < n {
		k <<= 1
	}
	return k
}
