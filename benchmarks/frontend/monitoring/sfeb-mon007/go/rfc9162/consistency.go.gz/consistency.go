package rfc9162

import (
	"errors"
	"fmt"
)

var (
	ErrInvalidConsistencySizes = errors.New("RFC 9162 consistency proof requires 0 < first size < second size")
	ErrEmptyConsistencyProof   = errors.New("RFC 9162 consistency proof must not be empty")
	ErrConsistencyProofTooLong = errors.New("RFC 9162 consistency proof has excess nodes")
	ErrConsistencyProofShort   = errors.New("RFC 9162 consistency proof is too short")
	ErrFirstRootMismatch       = errors.New("RFC 9162 consistency proof does not match the first trusted root")
	ErrSecondRootMismatch      = errors.New("RFC 9162 consistency proof does not match the second trusted root")
)

// VerifyConsistency verifies that the tree identified by (firstSize, firstRoot)
// is an exact prefix of the tree identified by (secondSize, secondRoot).
//
// The proof is ordered as specified by RFC 9162 Section 2.1.4.2. Both tree
// heads (including their sizes and roots) must be authenticated separately.
// This function proves a relationship between the supplied roots; it does not
// authenticate either checkpoint or protect against a log showing split views
// unless callers also compare heads through independent witnesses/gossip.
func VerifyConsistency(firstSize, secondSize uint64, firstRoot, secondRoot Hash, proof []Hash) error {
	if firstSize == 0 || firstSize >= secondSize {
		return ErrInvalidConsistencySizes
	}
	if len(proof) == 0 {
		return ErrEmptyConsistencyProof
	}

	// RFC 9162 Section 2.1.4.2 prepends the known old root when the old
	// tree size is an exact power of two. The proof generator emits the
	// minimal SUBPROOF path, so apply that normalization logically here
	// rather than allocating a copied path.
	fn := firstSize - 1
	sn := secondSize - 1
	if fn&1 == 1 {
		for fn&1 == 1 {
			fn >>= 1
			sn >>= 1
		}
	}

	var fr, sr Hash
	start := 0
	if firstSize&(firstSize-1) == 0 {
		fr, sr = firstRoot, firstRoot
	} else {
		fr, sr = proof[0], proof[0]
		start = 1
	}
	for i, node := range proof[start:] {
		if sn == 0 {
			return fmt.Errorf("%w: node %d", ErrConsistencyProofTooLong, i+1)
		}

		if fn&1 == 1 || fn == sn {
			fr = NodeHash(node, fr)
			sr = NodeHash(node, sr)
			if fn&1 == 0 {
				for fn&1 == 0 && fn != 0 {
					fn >>= 1
					sn >>= 1
				}
			}
		} else {
			sr = NodeHash(sr, node)
		}

		fn >>= 1
		sn >>= 1
	}

	if sn != 0 {
		return ErrConsistencyProofShort
	}
	if fr != firstRoot {
		return ErrFirstRootMismatch
	}
	if sr != secondRoot {
		return ErrSecondRootMismatch
	}
	return nil
}

// ConsistencyProof builds the minimal RFC 9162 consistency path for fixture
// generation. Production clients should obtain this proof from a log and
// validate it against independently authenticated tree heads.
func ConsistencyProof(leaves [][]byte, firstSize uint64) ([]Hash, error) {
	secondSize := uint64(len(leaves))
	if firstSize == 0 || firstSize >= secondSize {
		return nil, ErrInvalidConsistencySizes
	}
	return subProof(leaves, int(firstSize), true), nil
}

// subProof implements RFC 9162 Section 2.1.4.1. The flag indicates whether the
// subtree root for the old tree is already known to the verifier.
func subProof(leaves [][]byte, oldSize int, complete bool) []Hash {
	newSize := len(leaves)
	if oldSize == newSize {
		if complete {
			return nil
		}
		return []Hash{treeHash(leaves)}
	}

	k := int(largestPowerOfTwoLessThan(uint64(newSize)))
	if oldSize <= k {
		path := subProof(leaves[:k], oldSize, complete)
		return append(path, treeHash(leaves[k:]))
	}

	path := subProof(leaves[k:], oldSize-k, false)
	return append(path, treeHash(leaves[:k]))
}
