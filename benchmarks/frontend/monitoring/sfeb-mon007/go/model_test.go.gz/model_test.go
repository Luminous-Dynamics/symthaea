package assurance

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"io"
	"os"
	"reflect"
	"testing"
)

func snapshot(values map[string]any) map[string]any {
	out := make(map[string]any, len(values))
	for k, v := range values {
		out[k] = v
	}
	return out
}

func validBundle() (Bundle, TrustPolicy) {
	a := Action{TenantID: "tenant-a", ResourceID: "resource-7", OperationID: "op-991", ActionType: "reserve", RequestDigest: "sha256:request", ExpectedResourceRevision: 10, ExpectedPostcondition: "sha256:post", SourceID: "urn:source:inventory", SourceEventID: "evt-42", SourceDigest: "sha256:source", ActorPrincipal: "svc:worker"}
	s := &Source{SignatureVerified: true, IssuerTrusted: true, TenantID: a.TenantID, ResourceID: a.ResourceID, SourceID: a.SourceID, EventID: a.SourceEventID, Sequence: 42, Digest: a.SourceDigest}
	s.VerifiedFields = snapshot(map[string]any{"tenantId": s.TenantID, "resourceId": s.ResourceID, "sourceId": s.SourceID, "eventId": s.EventID, "sequence": s.Sequence, "digest": s.Digest, "signatureVerified": s.SignatureVerified, "issuerTrusted": s.IssuerTrusted})
	auth := &Authority{SignatureVerified: true, IssuerTrusted: true, ValidAtCommit: true, NotRevokedAtCommit: true, TenantID: a.TenantID, ResourceID: a.ResourceID, Subject: a.ActorPrincipal, Capability: a.ActionType, Revision: 7}
	auth.VerifiedFields = snapshot(map[string]any{"tenantId": auth.TenantID, "resourceId": auth.ResourceID, "subject": auth.Subject, "capability": auth.Capability, "revision": auth.Revision, "validAtCommit": auth.ValidAtCommit, "notRevokedAtCommit": auth.NotRevokedAtCommit, "signatureVerified": auth.SignatureVerified, "issuerTrusted": auth.IssuerTrusted})
	f := &Fence{ProofVerified: true, EnforcedAtSink: true, TenantID: a.TenantID, ResourceID: a.ResourceID, OperationID: a.OperationID, AuthorityRevision: 7, Token: 11}
	f.VerifiedFields = snapshot(map[string]any{"tenantId": f.TenantID, "resourceId": f.ResourceID, "operationId": f.OperationID, "authorityRevision": f.AuthorityRevision, "token": f.Token, "enforcedAtSink": f.EnforcedAtSink, "proofVerified": f.ProofVerified})
	sink := &Sink{Status: "committed", ReceiptVerified: true, TenantID: a.TenantID, ResourceID: a.ResourceID, OperationID: a.OperationID, SourceID: a.SourceID, SourceEventID: a.SourceEventID, SourceDigest: a.SourceDigest, RequestDigest: a.RequestDigest, AuthorityRevision: 7, EnforcedFenceToken: 11, PreviousResourceRevision: 10, ResultingResourceRevision: 11, TransactionID: "tx-991", ReceiptDigest: "sha256:sink", IdempotencyKey: a.OperationID, IdempotencyEnforcedAtSink: true}
	sink.VerifiedFields = snapshot(map[string]any{"status": sink.Status, "tenantId": sink.TenantID, "resourceId": sink.ResourceID, "operationId": sink.OperationID, "sourceId": sink.SourceID, "sourceEventId": sink.SourceEventID, "sourceDigest": sink.SourceDigest, "requestDigest": sink.RequestDigest, "authorityRevision": sink.AuthorityRevision, "enforcedFenceToken": sink.EnforcedFenceToken, "previousResourceRevision": sink.PreviousResourceRevision, "resultingResourceRevision": sink.ResultingResourceRevision, "transactionId": sink.TransactionID, "receiptDigest": sink.ReceiptDigest, "idempotencyKey": sink.IdempotencyKey, "idempotencyEnforcedAtSink": sink.IdempotencyEnforcedAtSink, "receiptVerified": sink.ReceiptVerified})
	r := &Readback{ObservationVerified: true, TenantID: a.TenantID, ResourceID: a.ResourceID, OperationID: a.OperationID, SinkTransactionID: sink.TransactionID, ReaderPrincipal: "svc:auditor", ResourceRevision: 11, PostconditionDigest: a.ExpectedPostcondition}
	r.VerifiedFields = snapshot(map[string]any{"observationVerified": r.ObservationVerified, "tenantId": r.TenantID, "resourceId": r.ResourceID, "operationId": r.OperationID, "sinkTransactionId": r.SinkTransactionID, "readerPrincipal": r.ReaderPrincipal, "resourceRevision": r.ResourceRevision, "postconditionDigest": r.PostconditionDigest})
	return Bundle{Action: a, Source: s, Authority: auth, Fence: f, Sink: sink, Readback: r}, TrustPolicy{TrustedReadbackPrincipals: []string{"svc:auditor"}, LastFenceTokens: map[string]int64{"tenant-a:resource-7": 10}}
}

func TestValidCoreEffectQualifies(t *testing.T) {
	b, p := validBundle()
	out := EvaluateCore(b, p)
	if out.Status != Verified {
		t.Fatalf("got %s: %+v", out.Status, out.Predicates["effect_verified"])
	}
	if out.Predicates["effect_verified"].Status != Verified {
		t.Fatalf("effect not verified: %+v", out.Predicates["effect_verified"])
	}
}

func TestUnknownSinkRemainsIndeterminate(t *testing.T) {
	b, p := validBundle()
	b.Sink.Status = "unknown"
	out := EvaluateCore(b, p)
	if out.Status != Indeterminate {
		t.Fatalf("expected indeterminate, got %s", out.Status)
	}
	if out.Predicates["sink_accepted"].Status != Indeterminate {
		t.Fatalf("sink status: %+v", out.Predicates["sink_accepted"])
	}
}

func TestAuthorityRevocationRejectsEffect(t *testing.T) {
	b, p := validBundle()
	b.Authority.NotRevokedAtCommit = false
	out := EvaluateCore(b, p)
	if out.Status != Rejected {
		t.Fatalf("expected rejection, got %s", out.Status)
	}
}

func TestStaleFenceRejected(t *testing.T) {
	b, p := validBundle()
	p.LastFenceTokens["tenant-a:resource-7"] = 11
	out := EvaluateCore(b, p)
	if out.Predicates["fence_enforced_at_sink"].Status != Rejected {
		t.Fatalf("fence: %+v", out.Predicates["fence_enforced_at_sink"])
	}
}

func TestSinkReceiptFieldMutationDetected(t *testing.T) {
	b, p := validBundle()
	b.Sink.ReceiptDigest = "sha256:substituted"
	out := EvaluateCore(b, p)
	if out.Predicates["sink_accepted"].Status != Rejected {
		t.Fatalf("sink: %+v", out.Predicates["sink_accepted"])
	}
}

func TestReadbackRequiresDistinctTrustedReader(t *testing.T) {
	b, p := validBundle()
	b.Readback.ReaderPrincipal = b.Action.ActorPrincipal
	out := EvaluateCore(b, p)
	if out.Predicates["postcondition_read_back"].Status != Rejected {
		t.Fatalf("readback: %+v", out.Predicates["postcondition_read_back"])
	}
}

func TestReadbackMustIncludeSinkRevision(t *testing.T) {
	b, p := validBundle()
	b.Readback.ResourceRevision = 10
	out := EvaluateCore(b, p)
	if out.Predicates["postcondition_read_back"].Status != Rejected {
		t.Fatalf("readback: %+v", out.Predicates["postcondition_read_back"])
	}
}

func TestOperationIdentityBoundToSinkIdempotency(t *testing.T) {
	b, p := validBundle()
	b.Sink.IdempotencyKey = "different-operation"
	out := EvaluateCore(b, p)
	if out.Predicates["operation_identity_verified"].Status != Rejected {
		t.Fatalf("operation: %+v", out.Predicates["operation_identity_verified"])
	}
}

func TestSourceTenantSubstitutionRejected(t *testing.T) {
	b, p := validBundle()
	b.Source.TenantID = "tenant-b"
	out := EvaluateCore(b, p)
	if out.Predicates["source_verified"].Status != Rejected {
		t.Fatalf("source: %+v", out.Predicates["source_verified"])
	}
}

func TestCrossSystemTimestampIsNotRequired(t *testing.T) {
	b, p := validBundle()
	out := EvaluateCore(b, p)
	if out.Predicates["causal_relationship_verified"].Status != Verified {
		t.Fatalf("causal: %+v", out.Predicates["causal_relationship_verified"])
	}
}

func TestPrecedenceRejectsOverUnknown(t *testing.T) {
	got := combine(result(Indeterminate, "unknown"), result(Rejected, "tampered"))
	if got.Status != Rejected {
		t.Fatalf("got %+v", got)
	}
}

func TestReasonsAreStableAndDeduplicated(t *testing.T) {
	got := combine(result(Rejected, "z", "a", "a"), result(Rejected, "m"))
	want := []string{"a", "m", "z"}
	if !reflect.DeepEqual(got.Reasons, want) {
		t.Fatalf("got %v want %v", got.Reasons, want)
	}
}

func TestSinkSourceDigestIsBoundToSourceReceipt(t *testing.T) {
	b, p := validBundle()
	b.Sink.SourceDigest = "sha256:substituted-source"
	out := EvaluateCore(b, p)
	if out.Predicates["sink_accepted"].Status != Rejected {
		t.Fatalf("sink: %+v", out.Predicates["sink_accepted"])
	}
	if out.Predicates["causal_relationship_verified"].Status != Rejected {
		t.Fatalf("causal: %+v", out.Predicates["causal_relationship_verified"])
	}
}

func TestSourceIdentityIsBoundToActionAndSink(t *testing.T) {
	b, p := validBundle()
	b.Source.SourceID = "urn:source:other"
	out := EvaluateCore(b, p)
	if out.Predicates["source_verified"].Status != Rejected {
		t.Fatalf("source: %+v", out.Predicates["source_verified"])
	}
}

func TestUnavailableReadbackRemainsIndeterminate(t *testing.T) {
	b, p := validBundle()
	b.Readback.Status = "unavailable"
	out := EvaluateCore(b, p)
	if out.Status != Indeterminate || out.Predicates["postcondition_read_back"].Status != Indeterminate {
		t.Fatalf("expected indeterminate readback, got %+v", out)
	}
}

func TestUntrustedReadbackPrincipalIsRejected(t *testing.T) {
	b, p := validBundle()
	b.Readback.ReaderPrincipal = "svc:untrusted-auditor"
	out := EvaluateCore(b, p)
	if out.Predicates["postcondition_read_back"].Status != Rejected {
		t.Fatalf("readback: %+v", out.Predicates["postcondition_read_back"])
	}
}

func TestMissingEvidenceDoesNotQualify(t *testing.T) {
	b, p := validBundle()
	b.Authority = nil
	out := EvaluateCore(b, p)
	if out.Status != Missing || out.Predicates["authority_verified"].Status != Missing {
		t.Fatalf("expected missing authority, got %+v", out)
	}
}

type sharedCoreVector struct {
	Name        string               `json:"name"`
	Bundle      json.RawMessage      `json:"bundle"`
	TrustPolicy json.RawMessage      `json:"trustPolicy"`
	Expected    map[string]Predicate `json:"expected"`
}

type sharedCoreCorpus struct {
	Schema string             `json:"schema"`
	Cases  []sharedCoreVector `json:"cases"`
}

func decodeJSONUseNumber(data []byte, target any) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.UseNumber()
	return decoder.Decode(target)
}

func TestSharedCoreGoldenVectorsMatchJavaScriptReference(t *testing.T) {
	compressed, err := os.ReadFile("testdata/effect-core-vectors-v1.json.gz")
	if err != nil {
		t.Fatal(err)
	}
	reader, err := gzip.NewReader(bytes.NewReader(compressed))
	if err != nil {
		t.Fatal(err)
	}
	defer reader.Close()
	data, err := io.ReadAll(reader)
	if err != nil {
		t.Fatal(err)
	}
	var corpus sharedCoreCorpus
	if err := decodeJSONUseNumber(data, &corpus); err != nil {
		t.Fatal(err)
	}
	if corpus.Schema != "sfeb.mon007.effect-core-vectors.v1" {
		t.Fatalf("unsupported vector schema: %s", corpus.Schema)
	}
	for _, vector := range corpus.Cases {
		t.Run(vector.Name, func(t *testing.T) {
			var bundle Bundle
			if err := decodeJSONUseNumber(vector.Bundle, &bundle); err != nil {
				t.Fatal(err)
			}
			var policy TrustPolicy
			if err := decodeJSONUseNumber(vector.TrustPolicy, &policy); err != nil {
				t.Fatal(err)
			}
			actual := EvaluateCore(bundle, policy)
			for name, expected := range vector.Expected {
				got, ok := actual.Predicates[name]
				if !ok {
					t.Fatalf("missing predicate %q", name)
				}
				if !reflect.DeepEqual(got, expected) {
					t.Errorf("predicate %s differs\n got: %#v\nwant: %#v", name, got, expected)
				}
			}
			if want := vector.Expected["effect_verified"].Status; actual.Status != want {
				t.Errorf("overall core status got %s, want %s", actual.Status, want)
			}
		})
	}
}
