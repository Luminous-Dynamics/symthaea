// Package assurance implements an independent Go preflight for the core
// external-effect semantics of SFEB MON-007. It deliberately does not verify
// COSE/CBOR, signatures, SCITT receipts, Merkle proofs, or external systems.
package assurance

import (
	"fmt"
	"reflect"
	"sort"
)

const (
	Verified      = "verified"
	Missing       = "missing"
	Indeterminate = "indeterminate"
	Rejected      = "rejected"
)

type Predicate struct {
	Status  string   `json:"status"`
	Reasons []string `json:"reasons"`
}

type Action struct {
	TenantID                 string
	ResourceID               string
	OperationID              string
	ActionType               string
	RequestDigest            string
	ExpectedResourceRevision int64
	ExpectedPostcondition    string
	SourceID                 string
	SourceEventID            string
	SourceDigest             string
	ActorPrincipal           string
}

type Source struct {
	SignatureVerified any
	IssuerTrusted     any
	TenantID          string
	ResourceID        string
	SourceID          string
	EventID           string
	Sequence          int64
	Digest            string
	VerifiedFields    map[string]any
}

type Authority struct {
	SignatureVerified  any
	IssuerTrusted      any
	ValidAtCommit      any
	NotRevokedAtCommit any
	TenantID           string
	ResourceID         string
	Subject            string
	Capability         string
	Revision           int64
	VerifiedFields     map[string]any
}

type Fence struct {
	ProofVerified     any
	EnforcedAtSink    any
	TenantID          string
	ResourceID        string
	OperationID       string
	AuthorityRevision int64
	Token             int64
	VerifiedFields    map[string]any
}

type Sink struct {
	Status                    string
	ReceiptVerified           any
	TenantID                  string
	ResourceID                string
	OperationID               string
	SourceID                  string
	SourceEventID             string
	SourceDigest              string
	RequestDigest             string
	AuthorityRevision         int64
	EnforcedFenceToken        int64
	PreviousResourceRevision  int64
	ResultingResourceRevision int64
	TransactionID             string
	ReceiptDigest             string
	IdempotencyKey            string
	IdempotencyEnforcedAtSink any
	VerifiedFields            map[string]any
}

type Readback struct {
	Status              string
	ObservationVerified any
	TenantID            string
	ResourceID          string
	OperationID         string
	SinkTransactionID   string
	ReaderPrincipal     string
	ResourceRevision    int64
	PostconditionDigest string
	VerifiedFields      map[string]any
}

type TrustPolicy struct {
	TrustedReadbackPrincipals []string
	LastFenceTokens           map[string]int64
}

type Bundle struct {
	Action    Action
	Source    *Source
	Authority *Authority
	Fence     *Fence
	Sink      *Sink
	Readback  *Readback
}

type Evaluation struct {
	Status     string               `json:"status"`
	Predicates map[string]Predicate `json:"predicates"`
}

func result(status string, reasons ...string) Predicate {
	set := make(map[string]struct{}, len(reasons))
	for _, reason := range reasons {
		if reason != "" {
			set[reason] = struct{}{}
		}
	}
	out := make([]string, 0, len(set))
	for reason := range set {
		out = append(out, reason)
	}
	sort.Strings(out)
	return Predicate{Status: status, Reasons: out}
}

func combine(items ...Predicate) Predicate {
	status := Verified
	reasons := make([]string, 0)
	for _, item := range items {
		reasons = append(reasons, item.Reasons...)
		switch item.Status {
		case Rejected:
			status = Rejected
		case Indeterminate:
			if status != Rejected {
				status = Indeterminate
			}
		case Missing:
			if status != Rejected && status != Indeterminate {
				status = Missing
			}
		case Verified:
		default:
			status = Rejected
			reasons = append(reasons, "predicate:invalid-status")
		}
	}
	return result(status, reasons...)
}

func fact(value any, reason string) Predicate {
	switch v := value.(type) {
	case nil:
		return result(Missing, reason+":missing")
	case bool:
		if v {
			return result(Verified)
		}
		return result(Rejected, reason+":failed")
	case string:
		if v == "unknown" || v == "unavailable" {
			return result(Indeterminate, reason+":unknown")
		}
		return result(Rejected, reason+":invalid-value")
	default:
		return result(Rejected, reason+":invalid-value")
	}
}

func snapshotPredicate(snapshot, actual map[string]any, label string) Predicate {
	if snapshot == nil {
		return result(Missing, label+":verified-fields-snapshot-missing")
	}
	checks := make([]Predicate, 0, len(actual))
	for field, value := range actual {
		sealed, ok := snapshot[field]
		if !ok {
			checks = append(checks, result(Missing, fmt.Sprintf("%s:%s-not-in-verified-snapshot", label, field)))
		} else if !reflect.DeepEqual(value, sealed) {
			checks = append(checks, result(Rejected, fmt.Sprintf("%s:%s-differs-from-verified-snapshot", label, field)))
		}
	}
	return combine(checks...)
}

func matchingContext(tenantID, resourceID, operationID string, action Action, label string) Predicate {
	checks := []struct{ got, want, field, reason string }{
		{tenantID, action.TenantID, "tenantId", "tenant-mismatch"},
		{resourceID, action.ResourceID, "resourceId", "resource-mismatch"},
		{operationID, action.OperationID, "operationId", "operation-mismatch"},
	}
	missing := make([]string, 0)
	mismatch := make([]string, 0)
	for _, check := range checks {
		if check.got == "" {
			missing = append(missing, label+":"+check.field+"-missing")
		} else if check.got != check.want {
			mismatch = append(mismatch, label+":"+check.reason)
		}
	}
	if len(mismatch) > 0 {
		return result(Rejected, append(missing, mismatch...)...)
	}
	if len(missing) > 0 {
		return result(Missing, missing...)
	}
	return result(Verified)
}

func sourcePredicate(bundle Bundle) Predicate {
	action, source := bundle.Action, bundle.Source
	if source == nil {
		return result(Missing, "source:missing")
	}
	checks := []Predicate{
		fact(source.SignatureVerified, "source-signature"),
		fact(source.IssuerTrusted, "source-issuer-trust"),
		snapshotPredicate(source.VerifiedFields, map[string]any{
			"tenantId": source.TenantID, "resourceId": source.ResourceID, "sourceId": source.SourceID,
			"eventId": source.EventID, "sequence": source.Sequence, "digest": source.Digest,
			"signatureVerified": source.SignatureVerified, "issuerTrusted": source.IssuerTrusted,
		}, "source"),
	}
	if source.TenantID != action.TenantID {
		checks = append(checks, result(Rejected, "source:tenant-mismatch"))
	}
	if source.ResourceID != action.ResourceID {
		checks = append(checks, result(Rejected, "source:resource-mismatch"))
	}
	if source.SourceID == "" || source.SourceID != action.SourceID {
		checks = append(checks, result(Rejected, "source:source-identity-mismatch"))
	}
	if source.Digest == "" || source.Digest != action.SourceDigest {
		checks = append(checks, result(Rejected, "source:source-digest-mismatch"))
	}
	if source.Sequence < 1 {
		checks = append(checks, result(Rejected, "source:invalid-sequence"))
	}
	if source.EventID != action.SourceEventID {
		reasonStatus := Rejected
		if source.EventID == "" {
			reasonStatus = Missing
		}
		checks = append(checks, result(reasonStatus, "source:event-id-mismatch"))
	}
	return combine(checks...)
}

func authorityPredicate(bundle Bundle) Predicate {
	action, authority := bundle.Action, bundle.Authority
	if authority == nil {
		return result(Missing, "authority:missing")
	}
	checks := []Predicate{
		fact(authority.SignatureVerified, "authority-signature"),
		fact(authority.IssuerTrusted, "authority-issuer-trust"),
		fact(authority.ValidAtCommit, "authority-valid-at-commit"),
		fact(authority.NotRevokedAtCommit, "authority-revocation"),
		snapshotPredicate(authority.VerifiedFields, map[string]any{
			"tenantId": authority.TenantID, "resourceId": authority.ResourceID, "subject": authority.Subject,
			"capability": authority.Capability, "revision": authority.Revision,
			"validAtCommit": authority.ValidAtCommit, "notRevokedAtCommit": authority.NotRevokedAtCommit,
			"signatureVerified": authority.SignatureVerified, "issuerTrusted": authority.IssuerTrusted,
		}, "authority"),
	}
	if authority.TenantID != action.TenantID {
		checks = append(checks, result(Rejected, "authority:tenant-mismatch"))
	}
	if authority.ResourceID != action.ResourceID {
		checks = append(checks, result(Rejected, "authority:resource-mismatch"))
	}
	if authority.Subject != action.ActorPrincipal {
		checks = append(checks, result(Rejected, "authority:subject-mismatch"))
	}
	if authority.Capability != action.ActionType {
		checks = append(checks, result(Rejected, "authority:capability-mismatch"))
	}
	if authority.Revision < 1 {
		checks = append(checks, result(Rejected, "authority:invalid-revision"))
	}
	return combine(checks...)
}

func fencePredicate(bundle Bundle, policy TrustPolicy) Predicate {
	action, fence, sink := bundle.Action, bundle.Fence, bundle.Sink
	if fence == nil {
		return result(Missing, "fence:missing")
	}
	checks := []Predicate{
		fact(fence.ProofVerified, "fence-proof"),
		fact(fence.EnforcedAtSink, "fence-not-enforced-at-sink"),
		matchingContext(fence.TenantID, fence.ResourceID, fence.OperationID, action, "fence"),
		snapshotPredicate(fence.VerifiedFields, map[string]any{
			"tenantId": fence.TenantID, "resourceId": fence.ResourceID, "operationId": fence.OperationID,
			"authorityRevision": fence.AuthorityRevision, "token": fence.Token,
			"enforcedAtSink": fence.EnforcedAtSink, "proofVerified": fence.ProofVerified,
		}, "fence"),
	}
	if fence.Token < 1 {
		checks = append(checks, result(Rejected, "fence:invalid-token"))
	}
	if bundle.Authority == nil {
		checks = append(checks, result(Missing, "fence:authority-revision-unavailable"))
	} else if fence.AuthorityRevision != bundle.Authority.Revision {
		checks = append(checks, result(Rejected, "fence:authority-revision-mismatch"))
	}
	if sink == nil {
		checks = append(checks, result(Missing, "sink:missing-for-fence-check"))
	} else if sink.EnforcedFenceToken != fence.Token {
		checks = append(checks, result(Rejected, "sink:fence-token-mismatch"))
	}
	key := action.TenantID + ":" + action.ResourceID
	if prior, ok := policy.LastFenceTokens[key]; ok && fence.Token <= prior {
		checks = append(checks, result(Rejected, "fence:stale-or-replayed-token"))
	}
	return combine(checks...)
}

func sinkPredicate(bundle Bundle) Predicate {
	action, sink := bundle.Action, bundle.Sink
	if sink == nil {
		return result(Missing, "sink:receipt-missing")
	}
	if sink.Status == "unknown" || sink.Status == "unavailable" {
		return result(Indeterminate, "sink:outcome-unknown")
	}
	if sink.Status != "committed" {
		return result(Rejected, "sink:not-committed")
	}
	checks := []Predicate{
		fact(sink.ReceiptVerified, "sink-receipt"),
		matchingContext(sink.TenantID, sink.ResourceID, sink.OperationID, action, "sink"),
		snapshotPredicate(sink.VerifiedFields, map[string]any{
			"status": sink.Status, "tenantId": sink.TenantID, "resourceId": sink.ResourceID,
			"operationId": sink.OperationID, "sourceId": sink.SourceID,
			"sourceEventId": sink.SourceEventID, "sourceDigest": sink.SourceDigest,
			"requestDigest": sink.RequestDigest, "authorityRevision": sink.AuthorityRevision,
			"enforcedFenceToken": sink.EnforcedFenceToken, "previousResourceRevision": sink.PreviousResourceRevision,
			"resultingResourceRevision": sink.ResultingResourceRevision, "transactionId": sink.TransactionID,
			"receiptDigest": sink.ReceiptDigest, "idempotencyKey": sink.IdempotencyKey,
			"idempotencyEnforcedAtSink": sink.IdempotencyEnforcedAtSink, "receiptVerified": sink.ReceiptVerified,
		}, "sink"),
	}
	if sink.RequestDigest != action.RequestDigest {
		checks = append(checks, result(Rejected, "sink:request-digest-mismatch"))
	}
	if sink.SourceID != action.SourceID {
		checks = append(checks, result(Rejected, "sink:source-identity-mismatch"))
	}
	if sink.SourceEventID != action.SourceEventID {
		checks = append(checks, result(Rejected, "sink:source-event-mismatch"))
	}
	if sink.SourceDigest != action.SourceDigest {
		checks = append(checks, result(Rejected, "sink:source-digest-mismatch"))
	}
	if sink.PreviousResourceRevision != action.ExpectedResourceRevision {
		checks = append(checks, result(Rejected, "sink:precondition-revision-mismatch"))
	}
	if sink.ResultingResourceRevision <= action.ExpectedResourceRevision {
		checks = append(checks, result(Rejected, "sink:invalid-resulting-revision"))
	}
	if sink.TransactionID == "" {
		checks = append(checks, result(Missing, "sink:transaction-id-missing"))
	}
	if bundle.Authority == nil {
		checks = append(checks, result(Missing, "sink:authority-revision-unavailable"))
	} else if sink.AuthorityRevision != bundle.Authority.Revision {
		checks = append(checks, result(Rejected, "sink:authority-revision-mismatch"))
	}
	return combine(checks...)
}

func operationIdentityPredicate(bundle Bundle) Predicate {
	action, sink := bundle.Action, bundle.Sink
	if sink == nil {
		return result(Missing, "operation:sink-receipt-missing")
	}
	if sink.Status == "unknown" || sink.Status == "unavailable" {
		return result(Indeterminate, "operation:outcome-unknown")
	}
	checks := []Predicate{fact(sink.IdempotencyEnforcedAtSink, "operation:idempotency-not-enforced-at-sink")}
	if sink.IdempotencyKey != action.OperationID {
		checks = append(checks, result(Rejected, "operation:idempotency-key-mismatch"))
	}
	if sink.OperationID != action.OperationID {
		checks = append(checks, result(Rejected, "operation:operation-id-mismatch"))
	}
	if sink.RequestDigest != action.RequestDigest {
		checks = append(checks, result(Rejected, "operation:request-digest-mismatch"))
	}
	return combine(checks...)
}

func readbackPredicate(bundle Bundle, policy TrustPolicy) Predicate {
	action, sink, readback := bundle.Action, bundle.Sink, bundle.Readback
	if readback == nil {
		return result(Missing, "readback:missing")
	}
	if readback.Status == "unknown" || readback.Status == "unavailable" {
		return result(Indeterminate, "readback:outcome-unknown")
	}
	checks := []Predicate{
		fact(readback.ObservationVerified, "readback-proof"),
		matchingContext(readback.TenantID, readback.ResourceID, readback.OperationID, action, "readback"),
		snapshotPredicate(readback.VerifiedFields, map[string]any{
			"observationVerified": readback.ObservationVerified, "tenantId": readback.TenantID,
			"resourceId": readback.ResourceID, "operationId": readback.OperationID,
			"sinkTransactionId": readback.SinkTransactionID, "readerPrincipal": readback.ReaderPrincipal,
			"resourceRevision": readback.ResourceRevision, "postconditionDigest": readback.PostconditionDigest,
		}, "readback"),
	}
	if sink == nil {
		checks = append(checks, result(Missing, "readback:sink-receipt-missing"))
	} else {
		if readback.SinkTransactionID != sink.TransactionID {
			checks = append(checks, result(Rejected, "readback:sink-transaction-mismatch"))
		}
		if readback.ResourceRevision < sink.ResultingResourceRevision {
			checks = append(checks, result(Rejected, "readback:revision-does-not-include-sink"))
		}
	}
	if readback.ReaderPrincipal == "" {
		checks = append(checks, result(Missing, "readback:reader-identity-missing"))
	} else if readback.ReaderPrincipal == action.ActorPrincipal {
		checks = append(checks, result(Rejected, "readback:not-independent-reader"))
	} else if !contains(policy.TrustedReadbackPrincipals, readback.ReaderPrincipal) {
		checks = append(checks, result(Rejected, "readback:reader-not-in-verifier-trust-policy"))
	}
	if readback.PostconditionDigest == "" {
		checks = append(checks, result(Missing, "readback:postcondition-digest-missing"))
	} else if action.ExpectedPostcondition != "" && readback.PostconditionDigest != action.ExpectedPostcondition {
		checks = append(checks, result(Rejected, "readback:postcondition-mismatch"))
	}
	return combine(checks...)
}

func causalPredicate(bundle Bundle) Predicate {
	action, source, sink, readback := bundle.Action, bundle.Source, bundle.Sink, bundle.Readback
	if source == nil || sink == nil || readback == nil {
		return result(Missing, "causal:required-observation-missing")
	}
	checks := make([]Predicate, 0, 8)
	if source.EventID != action.SourceEventID {
		checks = append(checks, result(Rejected, "causal:source-event-link-broken"))
	}
	if sink.OperationID != action.OperationID {
		checks = append(checks, result(Rejected, "causal:operation-link-broken"))
	}
	if sink.SourceID != source.SourceID {
		checks = append(checks, result(Rejected, "causal:sink-source-identity-link-broken"))
	}
	if sink.SourceEventID != source.EventID {
		checks = append(checks, result(Rejected, "causal:sink-source-link-broken"))
	}
	if sink.SourceDigest != source.Digest {
		checks = append(checks, result(Rejected, "causal:sink-source-digest-link-broken"))
	}
	if sink.PreviousResourceRevision != action.ExpectedResourceRevision {
		checks = append(checks, result(Rejected, "causal:resource-precondition-link-broken"))
	}
	if sink.ResultingResourceRevision <= sink.PreviousResourceRevision {
		checks = append(checks, result(Rejected, "causal:resource-revision-not-monotonic"))
	}
	if readback.OperationID != action.OperationID {
		checks = append(checks, result(Rejected, "causal:readback-operation-link-broken"))
	}
	if readback.SinkTransactionID != sink.TransactionID {
		checks = append(checks, result(Rejected, "causal:readback-transaction-link-broken"))
	}
	if readback.ResourceRevision < sink.ResultingResourceRevision {
		checks = append(checks, result(Rejected, "causal:readback-before-sink-revision"))
	}
	return combine(checks...)
}

// EvaluateCore evaluates only the external-effect predicate dependency graph.
// Transparency and trust-root predicates are outside this deliberately narrow
// Go preflight and are not implied by a verified core effect.
func EvaluateCore(bundle Bundle, policy TrustPolicy) Evaluation {
	source := sourcePredicate(bundle)
	authority := authorityPredicate(bundle)
	fence := fencePredicate(bundle, policy)
	sink := sinkPredicate(bundle)
	operation := operationIdentityPredicate(bundle)
	readback := readbackPredicate(bundle, policy)
	causal := causalPredicate(bundle)
	effect := combine(source, authority, operation, fence, sink, readback, causal)
	return Evaluation{
		Status: effect.Status,
		Predicates: map[string]Predicate{
			"source_verified":              source,
			"authority_verified":           authority,
			"fence_enforced_at_sink":       fence,
			"sink_accepted":                sink,
			"operation_identity_verified":  operation,
			"postcondition_read_back":      readback,
			"causal_relationship_verified": causal,
			"effect_verified":              effect,
		},
	}
}

func contains(items []string, item string) bool {
	for _, value := range items {
		if value == item {
			return true
		}
	}
	return false
}
