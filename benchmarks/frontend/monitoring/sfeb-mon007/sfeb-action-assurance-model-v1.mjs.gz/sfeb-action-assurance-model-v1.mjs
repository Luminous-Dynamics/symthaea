/**
 * SFEB MON-007 executable semantic assurance model (v1).
 *
 * This module evaluates the relationship between independently verified
 * evidence facts. It does NOT parse or verify COSE/CBOR, signatures, SCITT
 * receipts, Merkle proofs, source credentials, or sink APIs. Those adapters
 * must produce the narrowly-scoped `verified` facts consumed here.
 *
 * The goal is to make claim dependencies and uncertainty explicit, and to
 * prevent a valid transparency receipt from being mistaken for proof that
 * an external action was authorized or actually happened.
 */

export const SCHEMA = 'sfeb.action-evidence.v1';
export const MODEL_VERSION = '1.0.0';

const VALID = 'verified';
const MISSING = 'missing';
const INDETERMINATE = 'indeterminate';
const REJECTED = 'rejected';

const result = (status, ...reasons) => ({
  status,
  reasons: [...new Set(reasons.flat().filter(Boolean))].sort(),
});

function combine(...items) {
  const statuses = items.map((item) => item?.status ?? MISSING);
  const reasons = items.flatMap((item) => item?.reasons ?? []);
  if (statuses.includes(REJECTED)) return result(REJECTED, reasons);
  if (statuses.includes(INDETERMINATE)) return result(INDETERMINATE, reasons);
  if (statuses.includes(MISSING)) return result(MISSING, reasons);
  return result(VALID, reasons);
}

function fact(record, field, reason) {
  if (!record || !(field in record) || record[field] === undefined) {
    return result(MISSING, `${reason}:missing`);
  }
  if (record[field] === true) return result(VALID);
  if (record[field] === false) return result(REJECTED, `${reason}:failed`);
  if (record[field] === 'unknown' || record[field] === 'unavailable') {
    return result(INDETERMINATE, `${reason}:unknown`);
  }
  return result(REJECTED, `${reason}:invalid-value`);
}

function readPath(record, path) {
  return path.split('.').reduce((value, key) => value?.[key], record);
}

// Adapter-produced snapshot binds a verification result to the exact fields
// that were decoded from the authenticated bytes. The snapshot must be
// created by the trusted verifier adapter, never copied from issuer input.
function verifiedFieldsPredicate(record, paths, label) {
  if (!record) return result(MISSING, `${label}:evidence-missing`);
  if (!record.verifiedFields || typeof record.verifiedFields !== 'object') {
    return result(MISSING, `${label}:verified-fields-snapshot-missing`);
  }
  const checks = [];
  for (const path of paths) {
    if (!Object.hasOwn(record.verifiedFields, path)) {
      checks.push(result(MISSING, `${label}:${path}-not-in-verified-snapshot`));
    } else if (readPath(record, path) !== record.verifiedFields[path]) {
      checks.push(result(REJECTED, `${label}:${path}-differs-from-verified-snapshot`));
    }
  }
  return combine(...checks);
}

function matchingContext(record, action, label) {
  if (!record) return result(MISSING, `${label}:missing`);
  const checks = [
    ['tenantId', action.tenantId, 'tenant-mismatch'],
    ['resourceId', action.resourceId, 'resource-mismatch'],
    ['operationId', action.operationId, 'operation-mismatch'],
  ];
  const reasons = [];
  for (const [field, expected, reason] of checks) {
    if (record[field] === undefined || record[field] === null) {
      reasons.push(`${label}:${field}-missing`);
    } else if (record[field] !== expected) {
      reasons.push(`${label}:${reason}`);
    }
  }
  if (reasons.some((x) => x.endsWith('-mismatch'))) return result(REJECTED, reasons);
  if (reasons.length) return result(MISSING, reasons);
  return result(VALID);
}

function sourcePredicate(bundle) {
  const { action, source } = bundle;
  if (!source) return result(MISSING, 'source:missing');
  const checks = [
    fact(source, 'signatureVerified', 'source-signature'),
    fact(source, 'issuerTrusted', 'source-issuer-trust'),
    verifiedFieldsPredicate(source, ['tenantId', 'resourceId', 'eventId', 'sequence', 'digest', 'signatureVerified', 'issuerTrusted'], 'source'),
  ];
  if (source.tenantId !== action.tenantId) checks.push(result(source.tenantId === undefined ? MISSING : REJECTED, 'source:tenant-mismatch'));
  if (source.resourceId !== action.resourceId) checks.push(result(source.resourceId === undefined ? MISSING : REJECTED, 'source:resource-mismatch'));
  if (!Number.isSafeInteger(source.sequence) || source.sequence < 1) {
    checks.push(result(source.sequence === undefined ? MISSING : REJECTED, 'source:invalid-sequence'));
  }
  if (source.eventId !== action.sourceEventId) {
    checks.push(result(source.eventId ? REJECTED : MISSING, 'source:event-id-mismatch'));
  }
  return combine(...checks);
}

function authorityPredicate(bundle) {
  const { action, authority } = bundle;
  if (!authority) return result(MISSING, 'authority:missing');
  const checks = [
    fact(authority, 'signatureVerified', 'authority-signature'),
    fact(authority, 'issuerTrusted', 'authority-issuer-trust'),
    fact(authority, 'validAtCommit', 'authority-valid-at-commit'),
    fact(authority, 'notRevokedAtCommit', 'authority-revocation'),
    verifiedFieldsPredicate(authority, ['tenantId', 'resourceId', 'subject', 'capability', 'revision', 'validAtCommit', 'notRevokedAtCommit', 'signatureVerified', 'issuerTrusted'], 'authority'),
  ];
  if (authority.tenantId !== action.tenantId) checks.push(result(REJECTED, 'authority:tenant-mismatch'));
  if (authority.resourceId !== action.resourceId) checks.push(result(REJECTED, 'authority:resource-mismatch'));
  if (authority.subject !== action.actorPrincipal) checks.push(result(REJECTED, 'authority:subject-mismatch'));
  if (authority.capability !== action.actionType) checks.push(result(REJECTED, 'authority:capability-mismatch'));
  if (!Number.isSafeInteger(authority.revision) || authority.revision < 1) {
    checks.push(result(authority.revision === undefined ? MISSING : REJECTED, 'authority:invalid-revision'));
  }
  return combine(...checks);
}

function fencePredicate(bundle, trustPolicy) {
  const { action, fence, sink } = bundle;
  if (!fence) return result(MISSING, 'fence:missing');
  const checks = [
    fact(fence, 'proofVerified', 'fence-proof'),
    fact(fence, 'enforcedAtSink', 'fence-not-enforced-at-sink'),
    matchingContext(fence, action, 'fence'),
    verifiedFieldsPredicate(fence, ['tenantId', 'resourceId', 'operationId', 'authorityRevision', 'token', 'enforcedAtSink', 'proofVerified'], 'fence'),
  ];
  if (!Number.isSafeInteger(fence.token) || fence.token < 1) {
    checks.push(result(fence.token === undefined ? MISSING : REJECTED, 'fence:invalid-token'));
  }
  if (fence.authorityRevision !== bundle.authority?.revision) {
    checks.push(result(REJECTED, 'fence:authority-revision-mismatch'));
  }
  if (!sink) checks.push(result(MISSING, 'sink:missing-for-fence-check'));
  else if (sink.enforcedFenceToken !== fence.token) checks.push(result(REJECTED, 'sink:fence-token-mismatch'));
  const key = `${action.tenantId}:${action.resourceId}`;
  const lastToken = trustPolicy?.lastFenceTokens?.[key];
  if (lastToken !== undefined && fence.token <= lastToken) {
    checks.push(result(REJECTED, 'fence:stale-or-replayed-token'));
  }
  return combine(...checks);
}

function sinkPredicate(bundle) {
  const { action, sink } = bundle;
  if (!sink) return result(MISSING, 'sink:receipt-missing');
  if (sink.status === 'unknown' || sink.status === 'unavailable') {
    return result(INDETERMINATE, 'sink:outcome-unknown');
  }
  if (sink.status !== 'committed') return result(REJECTED, 'sink:not-committed');
  const checks = [
    fact(sink, 'receiptVerified', 'sink-receipt'),
    matchingContext(sink, action, 'sink'),
    verifiedFieldsPredicate(sink, ['status', 'tenantId', 'resourceId', 'operationId', 'sourceEventId', 'requestDigest', 'authorityRevision', 'enforcedFenceToken', 'previousResourceRevision', 'resultingResourceRevision', 'transactionId', 'receiptDigest', 'idempotencyKey', 'idempotencyEnforcedAtSink', 'receiptVerified'], 'sink'),
  ];
  if (sink.requestDigest !== action.requestDigest) checks.push(result(REJECTED, 'sink:request-digest-mismatch'));
  if (sink.sourceEventId !== action.sourceEventId) checks.push(result(REJECTED, 'sink:source-event-mismatch'));
  if (sink.previousResourceRevision !== action.expectedResourceRevision) {
    checks.push(result(REJECTED, 'sink:precondition-revision-mismatch'));
  }
  if (!Number.isSafeInteger(sink.resultingResourceRevision)
      || sink.resultingResourceRevision <= action.expectedResourceRevision) {
    checks.push(result(sink.resultingResourceRevision === undefined ? MISSING : REJECTED, 'sink:invalid-resulting-revision'));
  }
  if (!sink.transactionId) checks.push(result(MISSING, 'sink:transaction-id-missing'));
  if (sink.authorityRevision !== bundle.authority?.revision) {
    checks.push(result(REJECTED, 'sink:authority-revision-mismatch'));
  }
  return combine(...checks);
}

function readbackPredicate(bundle, trustPolicy) {
  const { action, sink, readback } = bundle;
  if (!readback) return result(MISSING, 'readback:missing');
  if (readback.status === 'unknown' || readback.status === 'unavailable') {
    return result(INDETERMINATE, 'readback:outcome-unknown');
  }
  const checks = [
    fact(readback, 'observationVerified', 'readback-proof'),
    matchingContext(readback, action, 'readback'),
    verifiedFieldsPredicate(readback, ['observationVerified', 'tenantId', 'resourceId', 'operationId', 'sinkTransactionId', 'readerPrincipal', 'resourceRevision', 'postconditionDigest'], 'readback'),
  ];
  if (!sink) checks.push(result(MISSING, 'readback:sink-receipt-missing'));
  else {
    if (readback.sinkTransactionId !== sink.transactionId) checks.push(result(REJECTED, 'readback:sink-transaction-mismatch'));
    if (!Number.isSafeInteger(readback.resourceRevision)
        || readback.resourceRevision < sink.resultingResourceRevision) {
      checks.push(result(readback.resourceRevision === undefined ? MISSING : REJECTED, 'readback:revision-does-not-include-sink'));
    }
  }
  if (!readback.readerPrincipal) checks.push(result(MISSING, 'readback:reader-identity-missing'));
  else if (readback.readerPrincipal === action.actorPrincipal) {
    checks.push(result(REJECTED, 'readback:not-independent-reader'));
  } else if (!(trustPolicy.trustedReadbackPrincipals ?? []).includes(readback.readerPrincipal)) {
    checks.push(result(REJECTED, 'readback:reader-not-in-verifier-trust-policy'));
  }
  if (!readback.postconditionDigest) checks.push(result(MISSING, 'readback:postcondition-digest-missing'));
  else if (action.expectedPostconditionDigest && readback.postconditionDigest !== action.expectedPostconditionDigest) {
    checks.push(result(REJECTED, 'readback:postcondition-mismatch'));
  }
  return combine(...checks);
}

function causalPredicate(bundle) {
  const { action, source, sink, readback } = bundle;
  if (!source || !sink || !readback) return result(MISSING, 'causal:required-observation-missing');
  const checks = [];
  // Cross-system timestamps and sequence numbers are intentionally not compared.
  // Causality is established through explicit event/operation/transaction links
  // and the sink's own resource revision precondition/result.
  if (source.eventId !== action.sourceEventId) checks.push(result(REJECTED, 'causal:source-event-link-broken'));
  if (sink.operationId !== action.operationId) checks.push(result(REJECTED, 'causal:operation-link-broken'));
  if (sink.sourceEventId !== source.eventId) checks.push(result(REJECTED, 'causal:sink-source-link-broken'));
  if (sink.previousResourceRevision !== action.expectedResourceRevision) checks.push(result(REJECTED, 'causal:resource-precondition-link-broken'));
  if (!Number.isSafeInteger(sink.resultingResourceRevision)
      || sink.resultingResourceRevision <= sink.previousResourceRevision) {
    checks.push(result(REJECTED, 'causal:resource-revision-not-monotonic'));
  }
  if (readback.operationId !== action.operationId) checks.push(result(REJECTED, 'causal:readback-operation-link-broken'));
  if (readback.sinkTransactionId !== sink.transactionId) checks.push(result(REJECTED, 'causal:readback-transaction-link-broken'));
  if (readback.resourceRevision < sink.resultingResourceRevision) checks.push(result(REJECTED, 'causal:readback-before-sink-revision'));
  return combine(...checks);
}


function operationIdentityPredicate(bundle) {
  const { action, sink } = bundle;
  if (!sink) return result(MISSING, 'operation:sink-receipt-missing');
  if (sink.status === 'unknown' || sink.status === 'unavailable') {
    return result(INDETERMINATE, 'operation:outcome-unknown');
  }
  const checks = [
    fact(sink, 'idempotencyEnforcedAtSink', 'operation:idempotency-not-enforced-at-sink'),
  ];
  if (sink.idempotencyKey !== action.operationId) {
    checks.push(result(sink.idempotencyKey === undefined ? MISSING : REJECTED, 'operation:idempotency-key-mismatch'));
  }
  if (sink.operationId !== action.operationId) checks.push(result(REJECTED, 'operation:operation-id-mismatch'));
  if (sink.requestDigest !== action.requestDigest) checks.push(result(REJECTED, 'operation:request-digest-mismatch'));
  return combine(...checks);
}

function statementBindingPredicate(bundle) {
  const { action, statement, source, authority, fence, sink, readback } = bundle;
  if (!statement) return result(MISSING, 'statement-binding:statement-missing');
  const expected = [
    ['requestDigest', action.requestDigest, 'request-digest'],
    ['sourceEventId', action.sourceEventId, 'source-event'],
    ['sourceDigest', source?.digest, 'source-digest'],
    ['authorityRevision', authority?.revision, 'authority-revision'],
    ['fenceToken', fence?.token, 'fence-token'],
    ['sinkTransactionId', sink?.transactionId, 'sink-transaction'],
    ['sinkReceiptDigest', sink?.receiptDigest, 'sink-receipt-digest'],
    ['sinkResourceRevision', sink?.resultingResourceRevision, 'sink-resource-revision'],
    ['postconditionDigest', readback?.postconditionDigest, 'postcondition-digest'],
  ];
  const checks = [];
  for (const [field, value, label] of expected) {
    if (value === undefined || value === null) {
      checks.push(result(MISSING, `statement-binding:${label}-evidence-missing`));
    } else if (statement[field] === undefined || statement[field] === null) {
      checks.push(result(MISSING, `statement-binding:${label}-claim-missing`));
    } else if (statement[field] !== value) {
      checks.push(result(REJECTED, `statement-binding:${label}-mismatch`));
    }
  }
  return combine(...checks);
}

function trustRootPredicate(bundle, trustPolicy) {
  const root = bundle.trustRoot;
  const pinned = trustPolicy.pinnedTrustRoot;
  if (!root || !pinned) return result(MISSING, 'trust-root:current-or-pinned-root-missing');
  if (!Number.isSafeInteger(root.version) || root.version < 1
      || !/^sha256:[a-f0-9]{64}$/.test(root.digest ?? '')) {
    return result(REJECTED, 'trust-root:invalid-version-or-digest');
  }
  const rootFields = ['version', 'digest'];
  if (root.transition) rootFields.push('transition.fromVersion', 'transition.fromDigest', 'transition.oldRootThresholdVerified', 'transition.newRootThresholdVerified', 'transition.transitionSignaturesVerified');
  const binding = verifiedFieldsPredicate(root, rootFields, 'trust-root');
  if (root.version < pinned.version) return combine(binding, result(REJECTED, 'trust-root:rollback'));
  if (root.version === pinned.version) {
    return combine(binding, root.digest === pinned.digest
      ? result(VALID)
      : result(REJECTED, 'trust-root:same-version-fork'));
  }
  if (root.version !== pinned.version + 1) {
    return result(REJECTED, 'trust-root:skipped-version-requires-sequential-update');
  }
  const transition = root.transition;
  if (!transition) return result(MISSING, 'trust-root:rotation-proof-missing');
  return combine(
    binding,
    transition.fromVersion === pinned.version && transition.fromDigest === pinned.digest
      ? result(VALID)
      : result(REJECTED, 'trust-root:wrong-transition-predecessor'),
    fact(transition, 'oldRootThresholdVerified', 'trust-root:old-threshold'),
    fact(transition, 'newRootThresholdVerified', 'trust-root:new-threshold'),
    fact(transition, 'transitionSignaturesVerified', 'trust-root:transition-signatures'),
  );
}

function checkpointPredicate(receipt, prior, nowMs, freshnessMs) {
  const cp = receipt.checkpoint;
  if (!cp) return result(MISSING, 'checkpoint:missing');
  const checks = [
    fact(cp, 'signatureVerified', 'checkpoint-signature'),
    fact(cp, 'inclusionProofVerified', 'checkpoint-inclusion-proof'),
  ];
  if (!Number.isSafeInteger(cp.treeSize) || cp.treeSize < 1) {
    checks.push(result(cp.treeSize === undefined ? MISSING : REJECTED, 'checkpoint:invalid-tree-size'));
  }
  if (!/^sha256:[a-f0-9]{64}$/.test(cp.rootHash ?? '')) checks.push(result(REJECTED, 'checkpoint:invalid-root-hash'));
  if (!Number.isFinite(cp.observedAtMs)) checks.push(result(MISSING, 'checkpoint:observation-time-missing'));
  else if (cp.observedAtMs > nowMs) checks.push(result(REJECTED, 'checkpoint:future-observation'));
  else if (nowMs - cp.observedAtMs > freshnessMs) checks.push(result(INDETERMINATE, 'checkpoint:stale'));
  checks.push(verifiedFieldsPredicate(cp, ['treeSize', 'rootHash', 'observedAtMs', 'signatureVerified', 'inclusionProofVerified', 'consistencyProofVerified'], 'checkpoint'));
  if (prior) {
    if (cp.treeSize < prior.treeSize) checks.push(result(REJECTED, 'checkpoint:rollback'));
    else if (cp.treeSize === prior.treeSize && cp.rootHash !== prior.rootHash) {
      checks.push(result(REJECTED, 'checkpoint:same-size-fork'));
    } else if (cp.treeSize > prior.treeSize) {
      checks.push(fact(cp, 'consistencyProofVerified', 'checkpoint:consistency-proof'));
    } else if (cp.rootHash !== prior.rootHash) {
      checks.push(result(REJECTED, 'checkpoint:root-mismatch'));
    }
  } else {
    checks.push(result(MISSING, 'checkpoint:no-pinned-prior-head'));
  }
  return combine(...checks);
}

function evaluateTransparency(bundle, trustPolicy, nowMs) {
  const statement = bundle.statement;
  if (!statement) {
    const missing = result(MISSING, 'statement:missing');
    return { issuer_authenticated: missing, registration_policy_verified: missing,
      transparency_registered: missing, checkpoint_current: missing, externally_anchored: missing,
      acceptedServices: [] };
  }
  const issuer = combine(
    fact(statement, 'signatureVerified', 'issuer-signature'),
    fact(statement, 'issuerTrusted', 'issuer-trust'),
    verifiedFieldsPredicate(statement, ['signatureVerified', 'issuerTrusted', 'tenantId', 'resourceId', 'operationId', 'digest', 'requestDigest', 'sourceEventId', 'sourceDigest', 'authorityRevision', 'fenceToken', 'sinkTransactionId', 'sinkReceiptDigest', 'sinkResourceRevision', 'postconditionDigest'], 'statement'),
    statement.tenantId === bundle.action.tenantId ? result(VALID) : result(REJECTED, 'statement:tenant-mismatch'),
    statement.resourceId === bundle.action.resourceId ? result(VALID) : result(REJECTED, 'statement:resource-mismatch'),
    statement.operationId === bundle.action.operationId ? result(VALID) : result(REJECTED, 'statement:operation-mismatch'),
    statement.digest ? result(VALID) : result(MISSING, 'statement:digest-missing'),
  );

  const receipts = Array.isArray(bundle.transparency?.receipts) ? bundle.transparency.receipts : [];
  const serviceTrust = new Map((trustPolicy?.services ?? []).map((service) => [service.serviceId, service]));
  const byService = new Map();
  const duplicates = new Set();
  for (const receipt of receipts) {
    if (!receipt?.serviceId) continue;
    if (byService.has(receipt.serviceId)) duplicates.add(receipt.serviceId);
    else byService.set(receipt.serviceId, receipt);
  }

  const policyResults = [];
  const registrationResults = [];
  const checkpointResults = [];
  const acceptedServices = [];
  for (const [serviceId, receipt] of byService) {
    const trust = serviceTrust.get(serviceId);
    if (!trust) {
      policyResults.push(result(REJECTED, `ts:${serviceId}:untrusted-service`));
      continue;
    }
    if (duplicates.has(serviceId)) {
      policyResults.push(result(REJECTED, `ts:${serviceId}:duplicate-service-receipt`));
      continue;
    }
    const keyOk = (trust.keyIds ?? []).includes(receipt.keyId);
    const policyOk = (trust.registrationPolicyDigests ?? []).includes(receipt.registrationPolicy?.digest);
    const anchorOk = (trust.trustAnchorDigests ?? []).includes(receipt.trustAnchor?.digest);
    const policy = combine(
      verifiedFieldsPredicate(receipt, ['serviceId', 'keyId', 'statementDigest', 'receiptSignatureVerified', 'inclusionProofVerified', 'registrationPolicyProofVerified', 'policyEffectiveAtRegistration', 'trustAnchorHistoryVerified', 'registrationPolicy.digest', 'trustAnchor.digest'], `ts:${serviceId}`),
      keyOk ? result(VALID) : result(REJECTED, `ts:${serviceId}:untrusted-key`),
      fact(receipt, 'registrationPolicyProofVerified', `ts:${serviceId}:registration-policy-proof`),
      policyOk ? result(VALID) : result(REJECTED, `ts:${serviceId}:unknown-registration-policy`),
      fact(receipt, 'policyEffectiveAtRegistration', `ts:${serviceId}:policy-not-effective-at-registration`),
      anchorOk ? result(VALID) : result(REJECTED, `ts:${serviceId}:unknown-trust-anchor`),
      fact(receipt, 'trustAnchorHistoryVerified', `ts:${serviceId}:trust-anchor-history`),
    );
    policyResults.push(policy);
    if (receipt.statementDigest !== statement.digest) {
      registrationResults.push(result(REJECTED, `ts:${serviceId}:statement-digest-mismatch`));
      continue;
    }
    const registration = combine(
      fact(receipt, 'receiptSignatureVerified', `ts:${serviceId}:receipt-signature`),
      fact(receipt, 'inclusionProofVerified', `ts:${serviceId}:inclusion-proof`),
      policy,
    );
    registrationResults.push(registration);
    const prior = trustPolicy?.pinnedCheckpoints?.[serviceId];
    const freshness = trustPolicy?.maxCheckpointAgeMs;
    const checkpoint = checkpointPredicate(receipt, prior, nowMs, freshness);
    checkpointResults.push(checkpoint);
    if (registration.status === VALID && checkpoint.status === VALID) {
      acceptedServices.push({ serviceId, failureDomain: trust.failureDomain ?? serviceId });
    }
  }

  const requiredServices = trustPolicy?.requiredDistinctServices ?? 2;
  const requiredDomains = trustPolicy?.requiredFailureDomains ?? requiredServices;
  const distinctDomains = new Set(acceptedServices.map((service) => service.failureDomain));
  const duplicateResult = duplicates.size
    ? result(REJECTED, [...duplicates].map((id) => `ts:${id}:duplicate-service-receipt`))
    : result(VALID);
  const thresholdResult = acceptedServices.length >= requiredServices
    ? result(VALID)
    : result(MISSING, `ts:insufficient-distinct-services:${acceptedServices.length}/${requiredServices}`);
  const domainResult = distinctDomains.size >= requiredDomains
    ? result(VALID)
    : result(MISSING, `ts:insufficient-failure-domains:${distinctDomains.size}/${requiredDomains}`);
  const registrationAggregate = combine(duplicateResult, thresholdResult, domainResult,
    ...registrationResults);
  const checkpointAggregate = combine(thresholdResult, domainResult, ...checkpointResults);
  const policyAggregate = combine(thresholdResult, domainResult, ...policyResults);
  const registered = combine(issuer, registrationAggregate);
  const current = combine(issuer, checkpointAggregate);
  const anchored = combine(issuer, policyAggregate, registered, current);
  return {
    issuer_authenticated: issuer,
    registration_policy_verified: policyAggregate,
    transparency_registered: registered,
    checkpoint_current: current,
    externally_anchored: anchored,
    acceptedServices,
  };
}

/**
 * Evaluate the semantic assurance predicates for a portable evidence bundle.
 *
 * `trustPolicy` is verifier-side trust state, not data supplied by the issuer.
 * Any `*Verified` booleans in the evidence bundle must only be set by a
 * separate cryptographic/protocol adapter after validating the underlying
 * signed bytes, proof and identity against that trust state.
 */
export function evaluateActionEvidence(bundle, trustPolicy, nowMs = Date.now()) {
  if (!bundle || typeof bundle !== 'object' || Array.isArray(bundle)) {
    throw new TypeError('bundle must be an object');
  }
  if (!trustPolicy || typeof trustPolicy !== 'object' || Array.isArray(trustPolicy)) {
    throw new TypeError('trustPolicy must be an independently configured object');
  }
  if (!Number.isFinite(nowMs)) throw new TypeError('nowMs must be a finite number');
  if (!Array.isArray(trustPolicy.services) || !Array.isArray(trustPolicy.trustedReadbackPrincipals)
      || !trustPolicy.pinnedCheckpoints || !trustPolicy.pinnedTrustRoot || !Number.isSafeInteger(trustPolicy.maxCheckpointAgeMs)
      || trustPolicy.maxCheckpointAgeMs < 1) {
    throw new TypeError('trustPolicy requires services, trustedReadbackPrincipals, pinnedCheckpoints, pinnedTrustRoot, and positive maxCheckpointAgeMs');
  }
  if (bundle.schema !== SCHEMA) {
    const rejected = result(REJECTED, 'bundle:unsupported-schema');
    return { modelVersion: MODEL_VERSION, status: REJECTED, predicates: { schema: rejected } };
  }
  const action = bundle.action;
  if (!action || !action.tenantId || !action.resourceId || !action.operationId
      || !action.actionType || !action.requestDigest || !action.sourceEventId
      || !action.actorPrincipal || !Number.isSafeInteger(action.expectedResourceRevision)
      || action.expectedResourceRevision < 0) {
    const invalid = result(MISSING, 'action:required-identity-or-precondition-missing');
    return { modelVersion: MODEL_VERSION, status: MISSING, predicates: { action_identity: invalid } };
  }

  const source = sourcePredicate(bundle);
  const authority = authorityPredicate(bundle);
  const sink = sinkPredicate(bundle);
  const operationIdentity = operationIdentityPredicate(bundle);
  const fence = fencePredicate(bundle, trustPolicy);
  const readback = readbackPredicate(bundle, trustPolicy);
  const causal = causalPredicate(bundle);
  const statementBinding = statementBindingPredicate(bundle);
  const rootContinuity = trustRootPredicate(bundle, trustPolicy);
  const transparency = evaluateTransparency(bundle, trustPolicy, nowMs);
  const externalAnchor = combine(transparency.externally_anchored, rootContinuity);
  const actionClaimAnchored = combine(externalAnchor, statementBinding);
  const effect = combine(source, authority, operationIdentity, fence, sink, readback, causal);
  const overall = combine(effect, actionClaimAnchored);
  return {
    modelVersion: MODEL_VERSION,
    status: overall.status,
    predicates: {
      source_verified: source,
      authority_verified: authority,
      fence_enforced_at_sink: fence,
      sink_accepted: sink,
      operation_identity_verified: operationIdentity,
      postcondition_read_back: readback,
      causal_relationship_verified: causal,
      effect_verified: effect,
      issuer_authenticated: transparency.issuer_authenticated,
      registration_policy_verified: transparency.registration_policy_verified,
      transparency_registered: transparency.transparency_registered,
      checkpoint_current: transparency.checkpoint_current,
      externally_anchored: externalAnchor,
      statement_binds_action_evidence: statementBinding,
      action_claim_anchored: actionClaimAnchored,
      trust_root_continuity_verified: rootContinuity,
    },
    acceptedTransparencyServices: transparency.acceptedServices.map((service) => service.serviceId).sort(),
  };
}
