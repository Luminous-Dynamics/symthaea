import assert from 'node:assert/strict';
import { gunzipSync } from 'node:zlib';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import test from 'node:test';
import { leafHash, verifyConsistency, verifyInclusion } from './rfc9162.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const corpusPath = path.join(here, 'testdata', 'rfc9162-go-generated-v1.json.gz');
const corpus = JSON.parse(gunzipSync(readFileSync(corpusPath)).toString('utf8'));
const nodeCorpusPath = path.join(here, 'testdata', 'rfc9162-node-generated-v1.json.gz');
const nodeCorpus = JSON.parse(gunzipSync(readFileSync(nodeCorpusPath)).toString('utf8'));
const fromHex = (value) => Buffer.from(value, 'hex');

test('corpus was generated independently by the Go implementation', () => {
  assert.equal(corpus.schema, 'rfc9162-sha256-go-generated-v1');
  assert.equal(corpus.maxTreeSize, 16);
  assert.equal(corpus.inclusion.length, 136);
  assert.equal(corpus.consistency.length, 120);
});

test('Go and Node independent fixture builders produce identical roots and proof paths', () => {
  assert.equal(nodeCorpus.schema, 'rfc9162-sha256-node-generated-v1');
  assert.deepEqual(nodeCorpus.inclusion, corpus.inclusion);
  assert.deepEqual(nodeCorpus.consistency, corpus.consistency);
});

test('Node independently verifies all Go-generated inclusion proofs', () => {
  for (const vector of corpus.inclusion) {
    const result = verifyInclusion({
      leaf: vector.leaf,
      leafDigest: fromHex(vector.leafHash),
      index: vector.index,
      treeSize: vector.treeSize,
      root: fromHex(vector.root),
      proof: vector.proof.map(fromHex),
    });
    assert.equal(result.verified, true, `tree=${vector.treeSize} index=${vector.index}: ${result.reasonCode} ${result.detail ?? ''}`);
    assert.deepEqual(leafHash(vector.leaf), fromHex(vector.leafHash));
  }
});

test('Node independently verifies all Go-generated consistency proofs', () => {
  for (const vector of corpus.consistency) {
    const result = verifyConsistency({
      firstSize: vector.firstSize,
      secondSize: vector.secondSize,
      firstRoot: fromHex(vector.firstRoot),
      secondRoot: fromHex(vector.secondRoot),
      proof: vector.proof.map(fromHex),
    });
    assert.equal(result.verified, true, `old=${vector.firstSize} new=${vector.secondSize}: ${result.reasonCode} ${result.detail ?? ''}`);
  }
});

test('Node rejects independent mutations of inclusion claims', () => {
  const vector = corpus.inclusion.find((entry) => entry.treeSize === 15 && entry.index === 7);
  const proof = vector.proof.map(fromHex);
  proof[0][0] ^= 0x80;
  const result = verifyInclusion({
    leaf: vector.leaf,
    index: vector.index,
    treeSize: vector.treeSize,
    root: fromHex(vector.root),
    proof,
  });
  assert.equal(result.verified, false);
  assert.equal(result.reasonCode, 'root-mismatch');
});

test('Node rejects independent mutations of consistency claims', () => {
  const vector = corpus.consistency.find((entry) => entry.firstSize === 7 && entry.secondSize === 16);
  const proof = vector.proof.map(fromHex);
  proof[0][0] ^= 0x80;
  const result = verifyConsistency({
    firstSize: vector.firstSize,
    secondSize: vector.secondSize,
    firstRoot: fromHex(vector.firstRoot),
    secondRoot: fromHex(vector.secondRoot),
    proof,
  });
  assert.equal(result.verified, false);
});

test('Node enforces 64-bit sizes, hash lengths, tree bounds, and proof completeness', () => {
  const valid = corpus.inclusion.find((entry) => entry.treeSize === 2 && entry.index === 0);
  const base = {
    leaf: valid.leaf,
    index: valid.index,
    treeSize: valid.treeSize,
    root: fromHex(valid.root),
    proof: valid.proof.map(fromHex),
  };
  assert.equal(verifyInclusion({ ...base, treeSize: 0 }).reasonCode, 'empty-tree');
  assert.equal(verifyInclusion({ ...base, index: 2 }).reasonCode, 'index-out-of-range');
  assert.equal(verifyInclusion({ ...base, proof: [] }).reasonCode, 'proof-too-short');
  assert.equal(verifyInclusion({ ...base, root: Buffer.alloc(31) }).reasonCode, 'malformed-proof');
  assert.equal(verifyConsistency({ firstSize: 0, secondSize: 1, firstRoot: Buffer.alloc(32), secondRoot: Buffer.alloc(32), proof: [Buffer.alloc(32)] }).reasonCode, 'invalid-tree-sizes');
});
