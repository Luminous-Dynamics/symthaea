import { createHash } from 'node:crypto';

const HASH_BYTES = 32;

function asBytes(value, label = 'value') {
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
    return Buffer.from(value);
  }
  if (typeof value === 'string') {
    return Buffer.from(value, 'utf8');
  }
  throw new TypeError(`${label} must be a Buffer, Uint8Array, or string`);
}

function hashBytes(value, label) {
  const bytes = asBytes(value, label);
  if (bytes.length !== HASH_BYTES) {
    throw new TypeError(`${label} must be exactly ${HASH_BYTES} bytes`);
  }
  return bytes;
}

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest();
}

export function leafHash(leaf) {
  return sha256(Buffer.concat([Buffer.from([0x00]), asBytes(leaf, 'leaf')]));
}

export function nodeHash(left, right) {
  return sha256(Buffer.concat([
    Buffer.from([0x01]),
    hashBytes(left, 'left hash'),
    hashBytes(right, 'right hash'),
  ]));
}

function asSize(value, label) {
  let parsed;
  try {
    parsed = typeof value === 'bigint' ? value : BigInt(value);
  } catch {
    throw new TypeError(`${label} must be an integer`);
  }
  if (parsed < 0n || parsed > 0xffff_ffff_ffff_ffffn) {
    throw new RangeError(`${label} must fit an unsigned 64-bit integer`);
  }
  return parsed;
}

function asProof(proof) {
  if (!Array.isArray(proof)) throw new TypeError('proof must be an array');
  return proof.map((node, index) => hashBytes(node, `proof[${index}]`));
}

function fail(reasonCode, detail = undefined) {
  return detail === undefined
    ? { verified: false, reasonCode }
    : { verified: false, reasonCode, detail };
}

export function verifyInclusion({ leaf, leafDigest, index, treeSize, proof, root }) {
  try {
    const size = asSize(treeSize, 'treeSize');
    const position = asSize(index, 'index');
    const trustedRoot = hashBytes(root, 'root');
    const path = asProof(proof);
    const digest = leafDigest === undefined
      ? leafHash(leaf)
      : hashBytes(leafDigest, 'leafDigest');

    if (size === 0n) return fail('empty-tree');
    if (position >= size) return fail('index-out-of-range');

    let fn = position;
    let sn = size - 1n;
    let running = digest;

    for (let i = 0; i < path.length; i += 1) {
      if (sn === 0n) return fail('proof-too-long', `node ${i}`);
      const sibling = path[i];
      if ((fn & 1n) === 1n || fn === sn) {
        running = nodeHash(sibling, running);
        while ((fn & 1n) === 0n && fn !== 0n) {
          fn >>= 1n;
          sn >>= 1n;
        }
      } else {
        running = nodeHash(running, sibling);
      }
      fn >>= 1n;
      sn >>= 1n;
    }

    if (sn !== 0n) return fail('proof-too-short');
    if (!running.equals(trustedRoot)) return fail('root-mismatch');
    return { verified: true, reasonCode: 'verified' };
  } catch (error) {
    return fail('malformed-proof', error.message);
  }
}

export function verifyConsistency({ firstSize, secondSize, firstRoot, secondRoot, proof }) {
  try {
    const oldSize = asSize(firstSize, 'firstSize');
    const newSize = asSize(secondSize, 'secondSize');
    const oldRoot = hashBytes(firstRoot, 'firstRoot');
    const newRoot = hashBytes(secondRoot, 'secondRoot');
    const path = asProof(proof);

    if (oldSize === 0n || oldSize >= newSize) return fail('invalid-tree-sizes');
    if (path.length === 0) return fail('empty-proof');

    let fn = oldSize - 1n;
    let sn = newSize - 1n;
    if ((fn & 1n) === 1n) {
      while ((fn & 1n) === 1n) {
        fn >>= 1n;
        sn >>= 1n;
      }
    }

    let first;
    let second;
    let start;
    if ((oldSize & (oldSize - 1n)) === 0n) {
      // RFC 9162 Section 2.1.4.2: for an exact power-of-two old size,
      // the known old root is logically prepended to the proof.
      first = oldRoot;
      second = oldRoot;
      start = 0;
    } else {
      first = path[0];
      second = path[0];
      start = 1;
    }

    for (let i = start; i < path.length; i += 1) {
      if (sn === 0n) return fail('proof-too-long', `node ${i}`);
      const node = path[i];
      if ((fn & 1n) === 1n || fn === sn) {
        first = nodeHash(node, first);
        second = nodeHash(node, second);
        if ((fn & 1n) === 0n) {
          while ((fn & 1n) === 0n && fn !== 0n) {
            fn >>= 1n;
            sn >>= 1n;
          }
        }
      } else {
        second = nodeHash(second, node);
      }
      fn >>= 1n;
      sn >>= 1n;
    }

    if (sn !== 0n) return fail('proof-too-short');
    if (!first.equals(oldRoot)) return fail('first-root-mismatch');
    if (!second.equals(newRoot)) return fail('second-root-mismatch');
    return { verified: true, reasonCode: 'verified' };
  } catch (error) {
    return fail('malformed-proof', error.message);
  }
}

function largestPowerOfTwoLessThan(size) {
  if (!Number.isSafeInteger(size) || size < 2) return 0;
  let power = 1;
  while (power * 2 < size) power *= 2;
  return power;
}

function treeHash(leaves) {
  if (leaves.length === 0) return sha256(Buffer.alloc(0));
  if (leaves.length === 1) return leafHash(leaves[0]);
  const split = largestPowerOfTwoLessThan(leaves.length);
  return nodeHash(treeHash(leaves.slice(0, split)), treeHash(leaves.slice(split)));
}

export function rootFromLeaves(leaves) {
  if (!Array.isArray(leaves)) throw new TypeError('leaves must be an array');
  return treeHash(leaves);
}

function inclusionPath(leaves, index) {
  if (leaves.length <= 1) return [];
  const split = largestPowerOfTwoLessThan(leaves.length);
  if (index < split) {
    return [...inclusionPath(leaves.slice(0, split), index), treeHash(leaves.slice(split))];
  }
  return [...inclusionPath(leaves.slice(split), index - split), treeHash(leaves.slice(0, split))];
}

export function buildInclusionProof(leaves, index) {
  if (!Array.isArray(leaves) || leaves.length === 0) throw new RangeError('cannot prove inclusion in an empty tree');
  if (!Number.isSafeInteger(index) || index < 0 || index >= leaves.length) throw new RangeError('leaf index is outside the tree');
  return inclusionPath(leaves, index);
}

function subProof(leaves, oldSize, complete) {
  const newSize = leaves.length;
  if (oldSize === newSize) return complete ? [] : [treeHash(leaves)];
  const split = largestPowerOfTwoLessThan(newSize);
  if (oldSize <= split) {
    return [...subProof(leaves.slice(0, split), oldSize, complete), treeHash(leaves.slice(split))];
  }
  return [...subProof(leaves.slice(split), oldSize - split, false), treeHash(leaves.slice(0, split))];
}

export function buildConsistencyProof(leaves, firstSize) {
  if (!Array.isArray(leaves) || !Number.isSafeInteger(firstSize) || firstSize <= 0 || firstSize >= leaves.length) {
    throw new RangeError('consistency proof requires 0 < firstSize < leaves.length');
  }
  return subProof(leaves, firstSize, true);
}
