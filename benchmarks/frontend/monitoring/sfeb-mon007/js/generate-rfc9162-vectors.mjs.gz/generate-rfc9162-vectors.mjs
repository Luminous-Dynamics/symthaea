import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import {
  buildConsistencyProof,
  buildInclusionProof,
  leafHash,
  rootFromLeaves,
} from './rfc9162.mjs';

const maxTreeSize = Number(process.argv[2] ?? 16);
const output = process.argv[3] ?? path.join(path.dirname(fileURLToPath(import.meta.url)), 'testdata', 'rfc9162-node-generated-v1.json');
if (!Number.isSafeInteger(maxTreeSize) || maxTreeSize < 2 || maxTreeSize > 256) {
  throw new RangeError('max tree size must be an integer from 2 to 256');
}
const hex = (value) => Buffer.from(value).toString('hex');
const leavesFor = (size) => Array.from({ length: size }, (_, index) => Buffer.from(`sfeb-differential-leaf-${String(index).padStart(4, '0')}`, 'utf8'));
const corpus = {
  schema: 'rfc9162-sha256-node-generated-v1',
  producer: 'sfeb-mon007/js/rfc9162.mjs using node:crypto SHA-256',
  maxTreeSize,
  inclusion: [],
  consistency: [],
};

for (let size = 1; size <= maxTreeSize; size += 1) {
  const leaves = leavesFor(size);
  const root = rootFromLeaves(leaves);
  for (let index = 0; index < size; index += 1) {
    const leaf = leaves[index];
    corpus.inclusion.push({
      leaf: leaf.toString('utf8'),
      index,
      treeSize: size,
      leafHash: hex(leafHash(leaf)),
      root: hex(root),
      proof: buildInclusionProof(leaves, index).map(hex),
    });
  }
}

for (let secondSize = 2; secondSize <= maxTreeSize; secondSize += 1) {
  const leaves = leavesFor(secondSize);
  const secondRoot = rootFromLeaves(leaves);
  for (let firstSize = 1; firstSize < secondSize; firstSize += 1) {
    corpus.consistency.push({
      firstSize,
      secondSize,
      firstRoot: hex(rootFromLeaves(leaves.slice(0, firstSize))),
      secondRoot: hex(secondRoot),
      proof: buildConsistencyProof(leaves, firstSize).map(hex),
    });
  }
}

await writeFile(output, `${JSON.stringify(corpus, null, 2)}\n`, 'utf8');
process.stdout.write(`${JSON.stringify({ output, inclusionVectors: corpus.inclusion.length, consistencyVectors: corpus.consistency.length, maxTreeSize })}\n`);
