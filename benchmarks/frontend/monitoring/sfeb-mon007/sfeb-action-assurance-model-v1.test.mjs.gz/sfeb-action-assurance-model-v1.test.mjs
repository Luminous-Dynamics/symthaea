import test from 'node:test';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
import { evaluateActionEvidence, SCHEMA } from './sfeb-action-assurance-model-v1.mjs';

const NOW = 1_800_000_000_000;
const hex = (ch) => `sha256:${ch.repeat(64)}`;

function receipt(serviceId, keyId, policyDigest, anchorDigest, treeSize, rootChar, failureDomain) {
  return {
    serviceId,
    keyId,
    statementDigest: hex('f'),
    receiptSignatureVerified: true,
    inclusionProofVerified: true,
    registrationPolicyProofVerified: true,
    policyEffectiveAtRegistration: true,
    trustAnchorHistoryVerified: true,
    registrationPolicy: { version: 3, digest: policyDigest },
    trustAnchor: { version: 2, digest: anchorDigest },
    checkpoint: {
      treeSize,
      rootHash: hex(rootChar),
      observedAtMs: NOW - 500,
      signatureVerified: true,
      inclusionProofVerified: true,
      consistencyProofVerified: true,
    },
    // failureDomain is verifier-side metadata; including it here must not
    // override the independently configured trust policy.
    untrustedFailureDomainHint: failureDomain,
  };
}

function fixture() {
  const bundle = {
    schema: SCHEMA,
    action: {
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      operationId: 'op-991',
      actionType: 'reserve',
      requestDigest: hex('1'),
      expectedResourceRevision: 10,
      expectedPostconditionDigest: hex('2'),
      sourceId: 'urn:source:inventory',
      sourceEventId: 'evt-42',
      sourceDigest: hex('3'),
      actorPrincipal: 'svc:worker',
    },
    source: {
      signatureVerified: true,
      issuerTrusted: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      sourceId: 'urn:source:inventory',
      eventId: 'evt-42',
      sequence: 42,
      digest: hex('3'),
    },
    authority: {
      signatureVerified: true,
      issuerTrusted: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      subject: 'svc:worker',
      capability: 'reserve',
      revision: 7,
      validAtCommit: true,
      notRevokedAtCommit: true,
    },
    fence: {
      proofVerified: true,
      enforcedAtSink: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      operationId: 'op-991',
      authorityRevision: 7,
      token: 11,
    },
    sink: {
      status: 'committed',
      receiptVerified: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      operationId: 'op-991',
      sourceId: 'urn:source:inventory',
      sourceEventId: 'evt-42',
      sourceDigest: hex('3'),
      requestDigest: hex('1'),
      authorityRevision: 7,
      enforcedFenceToken: 11,
      previousResourceRevision: 10,
      resultingResourceRevision: 11,
      transactionId: 'tx-991',
      receiptDigest: hex('4'),
      idempotencyKey: 'op-991',
      idempotencyEnforcedAtSink: true,
    },
    readback: {
      observationVerified: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      operationId: 'op-991',
      sinkTransactionId: 'tx-991',
      readerPrincipal: 'svc:auditor',
      resourceRevision: 11,
      postconditionDigest: hex('2'),
    },
    statement: {
      signatureVerified: true,
      issuerTrusted: true,
      tenantId: 'tenant-a',
      resourceId: 'resource-7',
      operationId: 'op-991',
      digest: hex('f'),
      requestDigest: hex('1'),
      sourceEventId: 'evt-42',
      sourceDigest: hex('3'),
      authorityRevision: 7,
      fenceToken: 11,
      sinkTransactionId: 'tx-991',
      sinkReceiptDigest: hex('4'),
      sinkResourceRevision: 11,
      postconditionDigest: hex('2'),
    },
    transparency: {
      receipts: [
        receipt('ts-a', 'key-a', 'policy-a-v3', 'anchor-a-v2', 20, 'a', 'provider-a/region-1'),
        receipt('ts-b', 'key-b', 'policy-b-v3', 'anchor-b-v2', 20, 'b', 'provider-b/region-2'),
      ],
    },
  };
  bundle.trustRoot = { version: 4, digest: hex('e') };
  seal(bundle.source, ['tenantId', 'resourceId', 'sourceId', 'eventId', 'sequence', 'digest', 'signatureVerified', 'issuerTrusted']);
  seal(bundle.authority, ['tenantId', 'resourceId', 'subject', 'capability', 'revision', 'validAtCommit', 'notRevokedAtCommit', 'signatureVerified', 'issuerTrusted']);
  seal(bundle.fence, ['tenantId', 'resourceId', 'operationId', 'authorityRevision', 'token', 'enforcedAtSink', 'proofVerified']);
  seal(bundle.sink, ['status', 'tenantId', 'resourceId', 'operationId', 'sourceId', 'sourceEventId', 'sourceDigest', 'requestDigest', 'authorityRevision', 'enforcedFenceToken', 'previousResourceRevision', 'resultingResourceRevision', 'transactionId', 'receiptDigest', 'idempotencyKey', 'idempotencyEnforcedAtSink', 'receiptVerified']);
  seal(bundle.readback, ['observationVerified', 'tenantId', 'resourceId', 'operationId', 'sinkTransactionId', 'readerPrincipal', 'resourceRevision', 'postconditionDigest']);
  seal(bundle.statement, ['signatureVerified', 'issuerTrusted', 'tenantId', 'resourceId', 'operationId', 'digest', 'requestDigest', 'sourceEventId', 'sourceDigest', 'authorityRevision', 'fenceToken', 'sinkTransactionId', 'sinkReceiptDigest', 'sinkResourceRevision', 'postconditionDigest']);
  seal(bundle.trustRoot, ['version', 'digest']);
  for (const r of bundle.transparency.receipts) {
    seal(r, ['serviceId', 'keyId', 'statementDigest', 'receiptSignatureVerified', 'inclusionProofVerified', 'registrationPolicyProofVerified', 'policyEffectiveAtRegistration', 'trustAnchorHistoryVerified', 'registrationPolicy.digest', 'trustAnchor.digest']);
    seal(r.checkpoint, ['treeSize', 'rootHash', 'observedAtMs', 'signatureVerified', 'inclusionProofVerified', 'consistencyProofVerified']);
  }
  const trustPolicy = {
    trustedReadbackPrincipals: ['svc:auditor'],
    requiredDistinctServices: 2,
    requiredFailureDomains: 2,
    maxCheckpointAgeMs: 60_000,
    services: [
      { serviceId: 'ts-a', keyIds: ['key-a'], failureDomain: 'provider-a/region-1', registrationPolicyDigests: ['policy-a-v3'], trustAnchorDigests: ['anchor-a-v2'] },
      { serviceId: 'ts-b', keyIds: ['key-b'], failureDomain: 'provider-b/region-2', registrationPolicyDigests: ['policy-b-v3'], trustAnchorDigests: ['anchor-b-v2'] },
    ],
    pinnedTrustRoot: { version: 4, digest: hex('e') },
    pinnedCheckpoints: {
      'ts-a': { treeSize: 19, rootHash: hex('c') },
      'ts-b': { treeSize: 19, rootHash: hex('d') },
    },
    lastFenceTokens: { 'tenant-a:resource-7': 10 },
  };
  return { bundle, trustPolicy };
}

const evaluate = (bundle, trustPolicy) => evaluateActionEvidence(bundle, trustPolicy, NOW);

function seal(record, paths) {
  record.verifiedFields = Object.fromEntries(paths.map((path) => [path, path.split('.').reduce((value, key) => value?.[key], record)]));
}

function setBothReceipts(bundle, fn) {
  bundle.transparency.receipts = bundle.transparency.receipts.map((r, i) => fn(structuredClone(r), i));
}

test('complete action and transparency evidence independently qualify', () => {
  const { bundle, trustPolicy } = fixture();
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.status, 'verified');
  assert.equal(out.predicates.effect_verified.status, 'verified');
  assert.equal(out.predicates.externally_anchored.status, 'verified');
  assert.deepEqual(out.acceptedTransparencyServices, ['ts-a', 'ts-b']);
});

test('a transparent signed claim is not proof that the external effect happened', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.source = undefined;
  bundle.authority = undefined;
  bundle.fence = undefined;
  bundle.sink = undefined;
  bundle.readback = undefined;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.externally_anchored.status, 'verified');
  assert.notEqual(out.predicates.effect_verified.status, 'verified');
});

test('an independently verified effect can remain anchor-pending', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.transparency.receipts = [];
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.effect_verified.status, 'verified');
  assert.equal(out.predicates.externally_anchored.status, 'missing');
});

test('stale or revoked authority blocks effect qualification', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.authority.notRevokedAtCommit = false;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.authority_verified.status, 'rejected');
  assert.equal(out.predicates.effect_verified.status, 'rejected');
  assert.equal(out.predicates.externally_anchored.status, 'verified');
});

test('sink-enforced fencing rejects a replayed or stale token', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.fence.token = 10;
  bundle.sink.enforcedFenceToken = 10;
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.fence_enforced_at_sink.reasons.includes('fence:stale-or-replayed-token'));
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});

test('readback must use a separate principal', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.readback.readerPrincipal = bundle.action.actorPrincipal;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.postcondition_read_back.status, 'rejected');
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});

test('readback must observe the sink revision or a later resource revision', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.readback.resourceRevision = 10;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.postcondition_read_back.status, 'rejected');
});

test('unknown sink outcome remains indeterminate and preserves operation identity', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.sink.status = 'unknown';
  bundle.readback.status = 'unavailable';
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.sink_accepted.status, 'indeterminate');
  assert.equal(out.predicates.postcondition_read_back.status, 'indeterminate');
  assert.equal(out.predicates.effect_verified.status, 'indeterminate');
  assert.equal(bundle.action.operationId, 'op-991');
});

test('cross-tenant source substitution is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.source.tenantId = 'tenant-b';
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.source_verified.status, 'rejected');
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});

test('sink request digest substitution is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.sink.requestDigest = hex('9');
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.sink_accepted.reasons.includes('sink:request-digest-mismatch'));
});

test('checkpoint rollback is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  setBothReceipts(bundle, (r) => ({ ...r, checkpoint: { ...r.checkpoint, treeSize: 18 } }));
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.checkpoint_current.status, 'rejected');
  assert.equal(out.predicates.externally_anchored.status, 'rejected');
});

test('same-size conflicting checkpoint root is a split-view rejection', () => {
  const { bundle, trustPolicy } = fixture();
  setBothReceipts(bundle, (r) => ({ ...r, checkpoint: { ...r.checkpoint, treeSize: 19, rootHash: hex('e') } }));
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.checkpoint_current.reasons.some((x) => x.includes('same-size-fork')));
  assert.equal(out.predicates.externally_anchored.status, 'rejected');
});

test('a valid but stale checkpoint is indeterminate, not current', () => {
  const { bundle, trustPolicy } = fixture();
  setBothReceipts(bundle, (r) => ({ ...r, checkpoint: { ...r.checkpoint, observedAtMs: NOW - 90_000 } }));
  for (const r of bundle.transparency.receipts) seal(r.checkpoint, ['treeSize', 'rootHash', 'observedAtMs', 'signatureVerified', 'inclusionProofVerified', 'consistencyProofVerified']);
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.checkpoint_current.status, 'indeterminate');
  assert.equal(out.predicates.externally_anchored.status, 'indeterminate');
});

test('duplicate receipts from one TS cannot satisfy a two-service requirement', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.transparency.receipts[1] = structuredClone(bundle.transparency.receipts[0]);
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.externally_anchored.status, 'rejected');
  assert.ok(out.predicates.externally_anchored.reasons.some((x) => x.includes('duplicate-service-receipt')));
});

test('two service keys in one failure domain do not satisfy diversity policy', () => {
  const { bundle, trustPolicy } = fixture();
  trustPolicy.services[1].failureDomain = trustPolicy.services[0].failureDomain;
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.externally_anchored.reasons.some((x) => x.includes('insufficient-failure-domains')));
  assert.notEqual(out.predicates.externally_anchored.status, 'verified');
});

test('historical registration policy must match the verifier trust policy', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.transparency.receipts[0].registrationPolicy.digest = 'policy-now-not-policy-at-registration';
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.registration_policy_verified.status, 'rejected');
  assert.notEqual(out.predicates.externally_anchored.status, 'verified');
});

test('a checkpoint extension without a valid consistency proof is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.transparency.receipts[0].checkpoint.consistencyProofVerified = false;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.checkpoint_current.status, 'rejected');
});

test('causality is established by explicit IDs and resource revisions, not cross-system clocks', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.source.occurredAt = '2099-01-01T00:00:00Z';
  bundle.sink.committedAt = '1999-01-01T00:00:00Z';
  bundle.readback.observedAt = '1900-01-01T00:00:00Z';
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.causal_relationship_verified.status, 'verified');
  assert.equal(out.predicates.effect_verified.status, 'verified');
});

test('unsupported profile versions fail closed', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.schema = 'sfeb.action-evidence.v99';
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.status, 'rejected');
  assert.equal(out.predicates.schema.status, 'rejected');
});

test('missing checkpoint pin is not silently treated as a trusted first head', () => {
  const { bundle, trustPolicy } = fixture();
  delete trustPolicy.pinnedCheckpoints['ts-b'];
  const out = evaluate(bundle, trustPolicy);
  assert.notEqual(out.predicates.externally_anchored.status, 'verified');
});


test('sink operation identity must be enforced and stable across retries', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.sink.idempotencyEnforcedAtSink = false;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.operation_identity_verified.status, 'rejected');
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});

test('signed statement must bind exact sink and readback evidence digests', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.statement.sinkReceiptDigest = hex('9');
  seal(bundle.statement, ['signatureVerified', 'issuerTrusted', 'tenantId', 'resourceId', 'operationId', 'digest', 'requestDigest', 'sourceEventId', 'sourceDigest', 'authorityRevision', 'fenceToken', 'sinkTransactionId', 'sinkReceiptDigest', 'sinkResourceRevision', 'postconditionDigest']);
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.externally_anchored.status, 'verified');
  assert.equal(out.predicates.statement_binds_action_evidence.status, 'rejected');
  assert.equal(out.predicates.action_claim_anchored.status, 'rejected');
});

test('trust-root rollback is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.trustRoot = { version: 3, digest: hex('e') };
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.trust_root_continuity_verified.status, 'rejected');
  assert.equal(out.predicates.externally_anchored.status, 'rejected');
});

test('same-version trust-root fork is rejected', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.trustRoot.digest = hex('a');
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.trust_root_continuity_verified.reasons.includes('trust-root:same-version-fork'));
});

test('trust-root rotation requires old and new thresholds and sequential versioning', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.trustRoot = {
    version: 5,
    digest: hex('9'),
    transition: {
      fromVersion: 4,
      fromDigest: hex('e'),
      oldRootThresholdVerified: true,
      newRootThresholdVerified: true,
      transitionSignaturesVerified: true,
    },
  };
  seal(bundle.trustRoot, ['version', 'digest', 'transition.fromVersion', 'transition.fromDigest', 'transition.oldRootThresholdVerified', 'transition.newRootThresholdVerified', 'transition.transitionSignaturesVerified']);
  let out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.trust_root_continuity_verified.status, 'verified');
  bundle.trustRoot.transition.oldRootThresholdVerified = false;
  out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.trust_root_continuity_verified.status, 'rejected');
});

test('trust-root version gaps fail closed until intermediate rotations are verified', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.trustRoot = { version: 7, digest: hex('9') };
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.trust_root_continuity_verified.reasons.includes('trust-root:skipped-version-requires-sequential-update'));
});


test('readback identity must be trusted by verifier policy', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.readback.readerPrincipal = 'svc:unknown';
  const out = evaluate(bundle, trustPolicy);
  assert.ok(out.predicates.postcondition_read_back.reasons.includes('readback:reader-not-in-verifier-trust-policy'));
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});


test('security-critical single-field mutations never preserve full qualification', () => {
  const mutations = [
    (b) => { b.source.signatureVerified = false; },
    (b) => { b.source.issuerTrusted = false; },
    (b) => { b.source.tenantId = 'tenant-b'; },
    (b) => { b.source.eventId = 'evt-other'; },
    (b) => { b.authority.validAtCommit = false; },
    (b) => { b.authority.notRevokedAtCommit = false; },
    (b) => { b.authority.capability = 'delete'; },
    (b) => { b.fence.enforcedAtSink = false; },
    (b) => { b.fence.authorityRevision = 8; },
    (b) => { b.fence.token = 10; },
    (b) => { b.sink.receiptVerified = false; },
    (b) => { b.sink.operationId = 'op-other'; },
    (b) => { b.sink.idempotencyKey = 'op-other'; },
    (b) => { b.sink.idempotencyEnforcedAtSink = false; },
    (b) => { b.sink.requestDigest = hex('9'); },
    (b) => { b.sink.enforcedFenceToken = 10; },
    (b) => { b.sink.authorityRevision = 8; },
    (b) => { b.sink.resultingResourceRevision = 9; },
    (b) => { b.readback.observationVerified = false; },
    (b) => { b.readback.readerPrincipal = 'svc:worker'; },
    (b) => { b.readback.resourceRevision = 10; },
    (b) => { b.readback.postconditionDigest = hex('9'); },
    (b) => { b.statement.signatureVerified = false; },
    (b) => { b.statement.requestDigest = hex('9'); },
    (b) => { b.statement.sinkReceiptDigest = hex('9'); },
    (b) => { b.statement.postconditionDigest = hex('9'); },
    (b) => { b.transparency.receipts[0].receiptSignatureVerified = false; },
    (b) => { b.transparency.receipts[0].inclusionProofVerified = false; },
    (b) => { b.transparency.receipts[0].registrationPolicyProofVerified = false; },
    (b) => { b.transparency.receipts[0].registrationPolicy.digest = 'wrong-policy'; },
    (b) => { b.transparency.receipts[0].trustAnchor.digest = 'wrong-anchor'; },
    (b) => { b.transparency.receipts[0].checkpoint.treeSize = 18; },
    (b) => { b.transparency.receipts[0].checkpoint.rootHash = hex('e'); },
    (b) => { b.transparency.receipts[0].checkpoint.consistencyProofVerified = false; },
    (b) => { b.trustRoot.version = 3; },
    (b) => { b.trustRoot.digest = hex('9'); },
  ];
  for (const [index, mutate] of mutations.entries()) {
    const { bundle, trustPolicy } = fixture();
    mutate(bundle);
    const out = evaluate(bundle, trustPolicy);
    assert.notEqual(out.status, 'verified', `mutation ${index} unexpectedly retained full qualification`);
  }
});


test('source identity and digest are bound across action, source, and sink receipt', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.sink.sourceDigest = hex('9');
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.sink_accepted.status, 'rejected');
  assert.equal(out.predicates.causal_relationship_verified.status, 'rejected');
  assert.equal(out.predicates.effect_verified.status, 'rejected');
});

test('missing authority remains missing rather than being misreported as a mismatch', () => {
  const { bundle, trustPolicy } = fixture();
  bundle.authority = undefined;
  const out = evaluate(bundle, trustPolicy);
  assert.equal(out.predicates.authority_verified.status, 'missing');
  assert.equal(out.predicates.effect_verified.status, 'missing');
});


test('shared Go/JavaScript effect-core golden vectors produce identical predicates', () => {
  const corpusBytes = readFileSync(new URL('./go/testdata/effect-core-vectors-v1.json.gz', import.meta.url));
  const corpus = JSON.parse(gunzipSync(corpusBytes).toString('utf8'));
  assert.equal(corpus.schema, 'sfeb.mon007.effect-core-vectors.v1');
  for (const vector of corpus.cases) {
    const out = evaluate(vector.bundle, vector.trustPolicy);
    const actual = Object.fromEntries(corpus.predicateNames.map((name) => [name, out.predicates[name]]));
    assert.deepEqual(actual, vector.expected, vector.name);
    assert.equal(out.predicates.effect_verified.status, vector.expected.effect_verified.status, vector.name);
  }
});
