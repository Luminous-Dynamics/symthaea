import { performance } from 'node:perf_hooks';
import os from 'node:os';
import { evaluateActionEvidence, SCHEMA } from './sfeb-action-assurance-model-v1.mjs';

const NOW = 1_800_000_000_000;
const sha = (c) => `sha256:${c.repeat(64)}`;
const receipt = (serviceId, keyId, policyDigest, anchorDigest, root, priorRoot) => ({
  serviceId, keyId, statementDigest: sha('f'), receiptSignatureVerified: true,
  inclusionProofVerified: true, registrationPolicyProofVerified: true,
  policyEffectiveAtRegistration: true, trustAnchorHistoryVerified: true,
  registrationPolicy: { version: 3, digest: policyDigest },
  trustAnchor: { version: 2, digest: anchorDigest },
  checkpoint: { treeSize: 20, rootHash: sha(root), observedAtMs: NOW - 500,
    signatureVerified: true, inclusionProofVerified: true, consistencyProofVerified: true },
});

const bundle = {
  schema: SCHEMA,
  action: { tenantId: 'tenant-a', resourceId: 'resource-7', operationId: 'op-991',
    actionType: 'reserve', requestDigest: sha('1'), expectedResourceRevision: 10,
    expectedPostconditionDigest: sha('2'), sourceEventId: 'evt-42', actorPrincipal: 'svc:worker' },
  source: { signatureVerified: true, issuerTrusted: true, tenantId: 'tenant-a',
    resourceId: 'resource-7', eventId: 'evt-42', sequence: 42, digest: sha('3') },
  authority: { signatureVerified: true, issuerTrusted: true, tenantId: 'tenant-a',
    resourceId: 'resource-7', subject: 'svc:worker', capability: 'reserve', revision: 7,
    validAtCommit: true, notRevokedAtCommit: true },
  fence: { proofVerified: true, enforcedAtSink: true, tenantId: 'tenant-a', resourceId: 'resource-7',
    operationId: 'op-991', authorityRevision: 7, token: 11 },
  sink: { status: 'committed', receiptVerified: true, tenantId: 'tenant-a', resourceId: 'resource-7',
    operationId: 'op-991', sourceEventId: 'evt-42', requestDigest: sha('1'), authorityRevision: 7,
    enforcedFenceToken: 11, previousResourceRevision: 10, resultingResourceRevision: 11,
    transactionId: 'tx-991', receiptDigest: sha('4'), idempotencyKey: 'op-991', idempotencyEnforcedAtSink: true },
  readback: { observationVerified: true, tenantId: 'tenant-a', resourceId: 'resource-7',
    operationId: 'op-991', sinkTransactionId: 'tx-991', readerPrincipal: 'svc:auditor',
    resourceRevision: 11, postconditionDigest: sha('2') },
  statement: { signatureVerified: true, issuerTrusted: true, tenantId: 'tenant-a', resourceId: 'resource-7',
    operationId: 'op-991', digest: sha('f'), requestDigest: sha('1'), sourceEventId: 'evt-42', sourceDigest: sha('3'),
    authorityRevision: 7, fenceToken: 11, sinkTransactionId: 'tx-991', sinkReceiptDigest: sha('4'),
    sinkResourceRevision: 11, postconditionDigest: sha('2') },
  trustRoot: { version: 4, digest: sha('e') },
  transparency: { receipts: [
    receipt('ts-a', 'key-a', 'policy-a-v3', 'anchor-a-v2', 'a'),
    receipt('ts-b', 'key-b', 'policy-b-v3', 'anchor-b-v2', 'b'),
  ] },
};
function seal(record, paths) {
  record.verifiedFields = Object.fromEntries(paths.map((path) => [path, path.split('.').reduce((value, key) => value?.[key], record)]));
}
seal(bundle.source, ['tenantId', 'resourceId', 'eventId', 'sequence', 'digest', 'signatureVerified', 'issuerTrusted']);
seal(bundle.authority, ['tenantId', 'resourceId', 'subject', 'capability', 'revision', 'validAtCommit', 'notRevokedAtCommit', 'signatureVerified', 'issuerTrusted']);
seal(bundle.fence, ['tenantId', 'resourceId', 'operationId', 'authorityRevision', 'token', 'enforcedAtSink', 'proofVerified']);
seal(bundle.sink, ['status', 'tenantId', 'resourceId', 'operationId', 'sourceEventId', 'requestDigest', 'authorityRevision', 'enforcedFenceToken', 'previousResourceRevision', 'resultingResourceRevision', 'transactionId', 'receiptDigest', 'idempotencyKey', 'idempotencyEnforcedAtSink', 'receiptVerified']);
seal(bundle.readback, ['observationVerified', 'tenantId', 'resourceId', 'operationId', 'sinkTransactionId', 'readerPrincipal', 'resourceRevision', 'postconditionDigest']);
seal(bundle.statement, ['signatureVerified', 'issuerTrusted', 'tenantId', 'resourceId', 'operationId', 'digest', 'requestDigest', 'sourceEventId', 'sourceDigest', 'authorityRevision', 'fenceToken', 'sinkTransactionId', 'sinkReceiptDigest', 'sinkResourceRevision', 'postconditionDigest']);
seal(bundle.trustRoot, ['version', 'digest']);
for (const r of bundle.transparency.receipts) {
  seal(r, ['serviceId', 'keyId', 'statementDigest', 'receiptSignatureVerified', 'inclusionProofVerified', 'registrationPolicyProofVerified', 'policyEffectiveAtRegistration', 'trustAnchorHistoryVerified', 'registrationPolicy.digest', 'trustAnchor.digest']);
  seal(r.checkpoint, ['treeSize', 'rootHash', 'observedAtMs', 'signatureVerified', 'inclusionProofVerified', 'consistencyProofVerified']);
}

const trustPolicy = {
  trustedReadbackPrincipals: ['svc:auditor'],
  requiredDistinctServices: 2, requiredFailureDomains: 2, maxCheckpointAgeMs: 60_000,
  services: [
    { serviceId: 'ts-a', keyIds: ['key-a'], failureDomain: 'provider-a/region-1',
      registrationPolicyDigests: ['policy-a-v3'], trustAnchorDigests: ['anchor-a-v2'] },
    { serviceId: 'ts-b', keyIds: ['key-b'], failureDomain: 'provider-b/region-2',
      registrationPolicyDigests: ['policy-b-v3'], trustAnchorDigests: ['anchor-b-v2'] },
  ],
  pinnedTrustRoot: { version: 4, digest: sha('e') },
  pinnedCheckpoints: { 'ts-a': { treeSize: 19, rootHash: sha('c') }, 'ts-b': { treeSize: 19, rootHash: sha('d') } },
  lastFenceTokens: { 'tenant-a:resource-7': 10 },
};

const ITERATIONS = Number(process.env.ITERATIONS ?? 30_000);
const SAMPLES = Number(process.env.SAMPLES ?? 30);
const BATCH = Math.max(1, Math.floor(ITERATIONS / SAMPLES));
for (let i = 0; i < 3_000; i++) evaluateActionEvidence(bundle, trustPolicy, NOW);

const latencies = [];
let verified = 0;
const started = performance.now();
for (let sample = 0; sample < SAMPLES; sample++) {
  const sampleStart = performance.now();
  for (let i = 0; i < BATCH; i++) {
    const result = evaluateActionEvidence(bundle, trustPolicy, NOW);
    if (result.status === 'verified') verified++;
  }
  const elapsed = performance.now() - sampleStart;
  latencies.push(elapsed / BATCH);
}
const totalMs = performance.now() - started;
const sorted = [...latencies].sort((a, b) => a - b);
const percentile = (p) => sorted[Math.min(sorted.length - 1, Math.ceil(p * sorted.length) - 1)];
console.log(JSON.stringify({
  benchmark: 'sfeb-mon007-semantic-assurance-model-v1',
  runtime: process.version,
  platform: `${os.platform()}-${os.release()}`,
  architecture: process.arch,
  logicalCpuCount: os.cpus().length,
  iterations: BATCH * SAMPLES,
  samples: SAMPLES,
  warmup: 3000,
  verified: verified,
  wallMs: Number(totalMs.toFixed(3)),
  throughputOpsPerSecond: Math.round((BATCH * SAMPLES * 1000) / totalMs),
  perEvaluationMs: {
    p50: Number(percentile(0.50).toFixed(6)),
    p95: Number(percentile(0.95).toFixed(6)),
    p99: Number(percentile(0.99).toFixed(6)),
  },
  scope: 'pure in-process semantic model only; excludes signatures, CBOR/COSE, Merkle proofs, network, storage, source/sink adapters and external readback; not comparable to product/SOTA throughput',
}, null, 2));
